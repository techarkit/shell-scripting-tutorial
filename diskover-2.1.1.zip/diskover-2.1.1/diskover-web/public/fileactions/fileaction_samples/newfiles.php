<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
example file action to check a directory path for new files/folders, compared to what's in index, local or remote over ssh
uses newfiles.py to get directory list on disk and diskover-web api to get directory list from index
*/


// override debug output in fileactions include file
$fileactions_debug = FALSE;

// override html page title in fileactions header include file
$fileactions_pagetitle = 'New Files File Action';

include 'includes/fileactions.php';

// add css to header inc
//$fileactions_header_inc = '';

include 'includes/fileactions_header.php';


// in this example we are listing all selected items on search results page
// you can set fileactions_debug to TRUE above for debug info to print out fileinfo array

// use ssh to get remote directory
$use_ssh = false;
// ssh user and host
//$ssh_host = "user@hostname";
//$ssh_port = 22;
//$ssh_verbose = false;
// path to ssh identity key file
//$ssh_identity_file = "../../src/diskover/ssh_key.pem";

// url to diskover-web api
$url = "http://localhost:8001";

// full path of python or python if in PATH
$python = "python3";
// python flags
$flags = "";


function api_search_path($index, $path) {
    // search web api for path and return all files and directories in the directory path
    global $url;
    global $api_url;

    $path_escaped = escape_chars($path);
    $query = urlencode("parent_path:$path_escaped AND type:(file OR directory)");
    $api_url = "$url/api.php/$index/search?query=$query";
    
    $json = file_get_contents($api_url);

    return json_decode($json, true);
}


function get_items($data) {
    $index_items = array();
    foreach ($data['message']['data'] as $val) {
        $name = $val['_source']['name'];
        if ($val['_source']['type'] == 'directory') {
            $pathsep = '/';
        } else {
            $pathsep = '';
        }
        $index_items[$name . $pathsep] = array($val['_source']['mtime'], $val['_source']['size']);
    }
    
    return $index_items;
}


foreach ($fileinfo as $file) {
    if ($file['type'] != 'directory') {
		echo "Not a directory";
		break;
	}
    
    $fullpath = $file['fullpath'];
    // uncomment below and set to translate paths
    //$path_translations = array(
    //    '/^\//' => '/mnt/'
    //);
    //$fullpath = translate_path($fullpath, $path_translations);

    $index = $file['index'];

    // script to run or code to run
    $script = "newfiles.py";

    // run command using python
    $cmd = $python . ' ' . $flags . ' ' . $script . ' "' . $fullpath . '" 2>&1';

    // use ssh to get remote directory
    if ($use_ssh) {
        $verbose = ($ssh_verbose) ? "-v" : "";
        $cmd = 'ssh -x "-o StrictHostKeyChecking=no" ' . $verbose .' -p '.$ssh_port.' -i '.$ssh_identity_file.' '.$ssh_host.' "' . $cmd . '"';
    }

    // run exec and get output and return value
    $output = $retval = null;
    exec($cmd, $output, $retval);

    // convert cmd output json to array
    $output_arr = json_decode($output[0], true);
    ksort($output_arr);
    $output_json = json_encode($output_arr);

    // get directory items from api
    $apires = api_search_path($index, $fullpath);
    $index_files = get_items($apires);
    ksort($index_files);
    $index_files_json = json_encode($index_files);

    // compare output of pathdiff.py file list with file list from api
    $diffs_ba = array_diff_assoc($output_arr, $index_files);

    if (!$diffs_ba) {
        $diffs = "No new items.";
    } else {
        $diffs = "";
        foreach ($diffs_ba as $filename => $fileprop) {
            $diffs .= formatBytes($fileprop[1]) . "\t" . utcTimeToLocal($fileprop[0]) . "\t" . $filename . "\n";
        }
    }

    // print html output
    echo '
    <div class="container-fluid cmd-output">
    Command: ' . $cmd . '<br>
    API URL: <a href="' . $api_url . '" style="text-decoration:underline" target="_blank">' . $api_url . '</a><br>
    Status:<br>
    <pre>' . $retval .'</pre>
    CMD Output:<br>
    <pre>' . $output_json . '</pre>
    API Output:<br>
    <pre>' . $index_files_json . '</pre>
    New files/directories:<br>
    <pre>' . $diffs . '</pre>
    </div>
    ';
}

// add js files to footer
//$fileactions_footer_inc = '';

include 'includes/fileactions_footer.php';