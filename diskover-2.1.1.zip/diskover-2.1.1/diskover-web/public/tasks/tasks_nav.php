<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../vendor/autoload.php';
require '../../src/diskover/config_inc.php';
error_reporting(E_ALL ^ E_NOTICE);

?>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapsible">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#"><img class="pull-left" title="diskover-web v<?php echo $VERSION ?>" alt="diskover-web logo" style="position:absolute;left:13px;top:9px;" src="../images/diskovernav.png" /><span style="margin-left:45px;"> </span>Task Panel</a>
        </div>

        <div class="collapse navbar-collapse" id="navbar-collapsible">
            <ul class="nav navbar-nav">
                <li><a href="index.php" title="task list"><i class="fas fa-tasks"></i> Task List</a></li>
                <li><a href="tasks_history.php" title="task history"><i class="fas fa-history"></i> Task History</a></li>
                <li><a href="tasks_templates.php" title="templates"><i class="far fa-clone"></i> Templates</a></li>
                <li><a href="tasks_workers.php" title="workers"><i class="fas fa-desktop"></i> Workers</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php $homepage = ($config->LOGINPAGE == 'dashboard') ? 'index.php' : 'search.php?submitted=true&p=1&q=' ?>
                <li><a href="../<?php echo $homepage ?>" title="Back to Home"><i class="fas fa-home"></i> Back to Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="glyphicon glyphicon-cog"></i> <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="../settings.php"><i class="fas fa-user-cog"></i> Settings</a></li>
                        <li><a href="../selectindices.php"><i class="glyphicon glyphicon-list-alt"></i> Indices</a></li>
                        <li><a href="../help.php" title="Help"><i class="glyphicon glyphicon-question-sign"></i> Help</a></li>
                        <?php if ($config->LOGIN_REQUIRED) { ?>
                            <li class="divider"></li>
                            <li title="Logout"><a href="../logout.php"><i class="glyphicon glyphicon-log-out"></i> Logout</a></li>
                        <?php } ?>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
