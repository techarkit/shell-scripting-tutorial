<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../vendor/autoload.php';
require "../../src/diskover/Auth.php";
require "../../src/diskover/Diskover.php";
require "tasks_inc.php";

if (!isset($_GET['id']) || !isset($_GET['action'])) exit;

$taskid = $_GET['id'];
$action = $_GET['action'];

$filename = 'tasks.json';
// read tasks json file
$tasks_json = readTasksFile($filename);
$tasks_arr = json_decode($tasks_json, true);
$tasks = $tasks_arr['tasks'];
$newtasks = ['tasks' => []];

// update tasks json file
foreach ($tasks as $task) {
    if ($taskid === $task['id']) {
        if ($action === 'remove') {
            continue;
        } elseif ($action === 'disable') {
            $task['disabled'] = true;
        } elseif ($action === 'enable') {
            $task['disabled'] = false;
        } elseif ($action === 'resetstatus') {
            $task['last_start_time'] = null;
            $task['last_finish_time'] = null;
            $task['last_update_time'] = null;
            $task['last_status'] = null;
            $task['run_now'] = null;
            $task['stop_task'] = null;
            $task['stop_task_force'] = null;
        } elseif ($action === 'runnow') {
            $task['run_now'] = true;
            $task['last_status'] = 'waiting';
        } elseif ($action === 'stoptask') {
            $task['stop_task'] = true;
            $task['last_status'] = 'stopping';
        } elseif ($action === 'stoptaskforce') {
            $task['stop_task_force'] = true;
            $task['last_status'] = 'stopping';
        }
    }
    $newtasks['tasks'][] = $task;
}

// write tasks json file
$tasks_json = json_encode($newtasks, JSON_PRETTY_PRINT);
writeToTasksFile($filename, $tasks_json);

header('Location: index.php');
exit;

?>