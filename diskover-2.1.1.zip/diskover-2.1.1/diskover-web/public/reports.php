<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';
require "../src/diskover/Auth.php";
require "d3_inc.php";

// license check
// DO NOT ALTER, REMOVE THIS CODE OR COMMENT IT OUT.
// REMOVING THE LICENSE CHECK VIOLATES THE LICENSE AGREEMENT AND IS AN ILLEGAL OFFENCE.
$lic->feature_check();
// end license check

// Grab all the reports from file
$reports = get_reports();

// Determine which report to show
if (!isset($_GET['report']) || empty($_GET['report'])) {
    $report = getCookie('reportsactivereport');
    if (empty($report)) {
        $report = $reports[0][0];
    }
} else {
    $report = $_GET['report'];
}
// check report exists
$reportexists = false;
foreach ($reports as $r) {
    if ($r[0] == $report) {
        $reportexists = true;
        break;
    }
}
if (!$reportexists) {
    $report = $reports[0][0];
}
createCookie('reportsactivereport', $report);

// Determine how many results to show
if (!isset($_GET['topsize']) || empty($_GET['topsize'])) {
    $topsize = getCookie('reportstopsize');
    if (empty($topsize)) {
        $topsize = 10;
    }
} else {
    $topsize = $_GET['topsize'];
    createCookie('reportstopsize', $topsize);
}

// determine if sort by size should be used
if (!isset($_GET['sortbysize'])) {
    if (getCookie('reportssortbysize') == 'true') {
        $sortbysize = true;
    } else {
        $sortbysize = false;
    }
} else {
    if ($_GET['sortbysize'] === "true") {
        $sortbysize = true;
        createCookie('reportssortbysize', 'true');
    } else {
        $sortbysize = false;
        createCookie('reportssortbysize', 'false');
    }
}

$totalCount = 0;
$totalSize = 0;
$totalFilesizeReports = [];
$totalCountReports = [];
$reportsQueries = [];

foreach ($reports as $key => $value) {
    if ($value[0] !== $report) continue;
    $totalFilesizeReports[$value[0]] = 0;
    $totalCountReports[$value[0]] = 0;
    $reportsQueries[$value[0]] = [$value[1], $value[2]];
}

// determine doc type based on toggle switches and cookies
if (!isset($_GET['toggleonly'])) {
    if (getCookie('tagsshowdirectories') == 'true') {
        $doctype = $doctype_href = 'directory';
    } else if (getCookie('tagsshowfiles') == 'true') {
        $doctype = $doctype_href = 'file';
    } else {
        $doctype = '(file OR directory)';
        $doctype_href = '';
    }
} else {
    if ($_GET['toggleonly'] === "showdirectories") {
        $doctype = $doctype_href = 'directory';
        createCookie('tagsshowdirectories', 'true');
        createCookie('tagsshowfiles', 'false');
        createCookie('tagsshowall', 'false');
    } else if ($_GET['toggleonly'] === "showfiles") {
        $doctype = $doctype_href = 'file';
        createCookie('tagsshowfiles', 'true');
        createCookie('tagsshowdirectories', 'false');
        createCookie('tagsshowall', 'false');
    } else if ($_GET['toggleonly'] === "showall") {
        $doctype = '(file OR directory)';
        $doctype_href = '';
        createCookie('tagsshowall', 'true');
        createCookie('tagsshowfiles', 'false');
        createCookie('tagsshowdirectories', 'false');
    }
}

// determine if only current top path should be used
if (!isset($_GET['toggletoppath'])) {
    if (getCookie('tagsshowtoppath') == 'true') {
        $toppathonly = true;
    } else {
        $toppathonly = false;
    }
} else {
    if ($_GET['toggletoppath'] === "showtoppath") {
        $toppathonly = true;
        createCookie('tagsshowtoppath', 'true');
    } else {
        $toppathonly = false;
        createCookie('tagsshowtoppath', 'false');
    }
}

// determine if only current directory should be used
if (!isset($_GET['togglecurrentdir'])) {
    if (getCookie('tagsshowcurrentdir') == 'true') {
        $currentdironly = true;
    } else {
        $currentdironly = false;
    }
} else {
    if ($_GET['togglecurrentdir'] === "showcurrentdir") {
        $currentdironly = true;
        createCookie('tagsshowcurrentdir', 'true');
    } else {
        $currentdironly = false;
        createCookie('tagsshowcurrentdir', 'false');
    }
}

// determine if directory no recursive field should be used
if (!isset($_GET['toggledirnorecurs'])) {
    if (getCookie('tagsshowdirnorecurs') == 'true') {
        $dirnorecurs = true;
    } else {
        $dirnorecurs = false;
    }
} else {
    if ($_GET['toggledirnorecurs'] === "showdirnorecurs") {
        $dirnorecurs = true;
        createCookie('tagsshowdirnorecurs', 'true');
    } else {
        $dirnorecurs = false;
        createCookie('tagsshowdirnorecurs', 'false');
    }
}

// Get search results from Elasticsearch for reports
$searchParams = [];

$searchParams['index'] = $mnclient->getSearchIndex($esIndex);

// Execute the search
foreach ($reportsQueries as $key => $value) {
    $query = $value[0] . ' AND type:' . $doctype;
    if ($toppathonly) {
        $query = $query . ' AND parent_path:(' . escape_chars($_SESSION['rootpath']) . ' OR ' . escape_chars($_SESSION['rootpath']) . '\/*)';
    }
    if ($currentdironly) {
        $query = $query . ' AND parent_path:(' . escape_chars($path) . ' OR ' . escape_chars($path) . '\/*)';
    }
    if ($dirnorecurs && $doctype == 'directory') {
        if (getCookie('sizefield') == 'size_du') {
            $sizefield = 'size_du_norecurs';
        } else {
            $sizefield = 'size_norecurs';
        }
    } else {
        if (getCookie('sizefield') == 'size_du') {
            $sizefield = 'size_du';
        } else {
            $sizefield = 'size';
        }
    }

    // search top values sorted by count

    $searchParams['body'] = [
        'size' => 0,
        'query' => [
            'query_string' => [
                'query' => $query
            ]
        ],
        'aggs' => [
            'top_values' => [
                'terms' => [
                    'field' => $value[1],
                    'size' => $topsize
                ],
                'aggs' => [
                    'size' => [
                        'sum' => [
                            'field' => $sizefield
                        ]
                    ]
                ]
            ]
        ]
    ];

    if ($sortbysize) {
        $searchParams['body']['aggs']['top_values']['terms']['order'] = ['size' => 'desc'];
    }

    // check if we need to apply any filters to search
    $searchParams = filterIndexMappingPaths($searchParams);
    $searchParams = filterLDAPGroups($searchParams);

    try {
        // Send search query to Elasticsearch
        $queryResponse = $client->search($searchParams);
    } catch (Exception $e) {
        header('Location: editreports.php?error='.$e->getMessage());
        exit;
    }

    // Get top values
    $topValues = $queryResponse['aggregations']['top_values']['buckets'];

    // Add top values results to top values array
    $ReportsTopValuesByCount[$key] = array();
    foreach ($topValues as $result) {
        $ReportsTopValuesByCount[$key][] = [
                    "name" => $result['key'],
                    "count" => $result['doc_count'],
                    "field" => $value[1]
                    ];
        $totalCount += $result['doc_count'];
    }

    // search top values sorted by size

    $searchParams['body'] = [
        'size' => 0,
        'query' => [
            'query_string' => [
                'query' => $query
            ]
        ],
        'aggs' => [
            'top_values' => [
                'terms' => [
                    'field' => $value[1],
                    'order' => [
                        'size' => 'desc'
                    ],
                    'size' => $topsize
                ],
                'aggs' => [
                    'size' => [
                        'sum' => [
                            'field' => $sizefield
                        ]
                    ]
                ]
            ]
        ]
    ];

    // check if we need to apply any filters to search
    $searchParams = filterIndexMappingPaths($searchParams);
    $searchParams = filterLDAPGroups($searchParams);

    try {
        // Send search query to Elasticsearch
        $queryResponse = $client->search($searchParams);
    } catch (Exception $e) {
        header('Location: editreports.php?error='.$e->getMessage());
        exit;
    }

    // Get top values
    $topValues = $queryResponse['aggregations']['top_values']['buckets'];

    // Add top values results to top values array
    $ReportsTopValuesBySize[$key] = array();
    foreach ($topValues as $result) {
        $ReportsTopValuesBySize[$key][] = [
                    "name" => $result['key'],
                    "size" => $result['size']['value'],
                    "field" => $value[1]
                    ];
        $totalSize += $result['size']['value'];
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>diskover &mdash; Reports</title>
    <link rel="stylesheet" href="css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="css/diskover.css" media="screen" />
    <link rel="stylesheet" href="css/diskover-reports.css" media="screen" />
    <link rel="icon" type="image/png" href="images/diskoverfavico.png" />
</head>

<body>
    <?php include "nav.php"; ?>
    <?php if (empty($reports)) { ?>
    <div class="container" id="notags" style="display:block; margin-top:70px;">
        <div class="row">
            <div class="alert alert-dismissible alert-info col-xs-8">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <i class="glyphicon glyphicon-exclamation-sign"></i> <strong>Sorry, there doesn't appear to be any reports.</strong> Please <a href="editreports.php" target="_blank">add some reports</a> and then reload this page.
            </div>
        </div>
    </div> 
    <?php } else { ?>
    <div class="container" id="mainwindow" style="margin-top: 70px;">
        <h1 class="page-header text-center"><i class="glyphicon glyphicon-stats"></i> Reports</h1>
        <div class="row">
            <div class="col-lg-12 text-right">
                <form class="form-inline" style="display:inline" name="reportsform_options" id="reportsform_options" method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <span style="position:relative">
                        <select name="report" id="report" onchange="$('#reportsform_options').submit();" style="width:150px; max-width:150px">
                            <option value="">Select report...</option>
                            <?php foreach ($reports as $key => $val) {
                                if ($val[0] == $report) {
                                    echo '<option value="'.$val[0].'" selected>'.$val[0].'</option>';
                                } else {
                                    echo '<option value="'.$val[0].'">'.$val[0].'</option>';
                                }
                            } ?>
                        </select>
                    </span>
                    &nbsp;
                    <span style="position:relative">
                        <select name="topsize" id="topsize" onchange="$('#reportsform_options').submit();" style="width:50px; max-width:50px">
                            <option value="">Result size...</option>
                            <option value="5" <?php if ($topsize == 5) echo "selected" ?>>5</option>
                            <option value="10" <?php if ($topsize == 10) echo "selected" ?>>10</option>
                            <option value="25" <?php if ($topsize == 25) echo "selected" ?>>25</option>
                            <option value="50" <?php if ($topsize == 50) echo "selected" ?>>50</option>
                            <option value="100" <?php if ($topsize == 100) echo "selected" ?>>100</option>
                        </select>
                    </span>
                </form>
                <form class="form-inline" style="display:inline" name="toggleform_sortbysize" id="toggleform_sortbysize" method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">   
                    <span style="font-size:11px; color:gray;">Sort by size </span><span style="position:relative; top:8px;"><label class="switch" title="Sort count by size"><input onchange="setCookie('reportssortbysize', document.getElementById('sortbysize').checked); $('#toggleform_sortbysize').submit();" id="sortbysize" name="togglesortbysize" value="sortbysize" type="checkbox"><span class="slider round"></span></label></span>
                </form>
                <form class="form-inline" style="display:inline" name="toggleform" id="toggleform" method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <span style="font-size:11px; color:gray;">Show files only </span><span style="position:relative; top:8px;"><label class="switch"><input onchange="setCookie('tagsshowfiles', document.getElementById('showfiles').checked); $('#toggleform').submit();" id="showfiles" name="toggleonly" value="showfiles" type="radio"><span class="slider round"></span></label></span>
                    &nbsp;
                    <span style="font-size:11px; color:gray;">Show directories only </span><span style="position:relative; top:8px;"><label class="switch"><input onchange="setCookie('tagsshowdirectories', document.getElementById('showdirectories').checked); $('#toggleform').submit();" id="showdirectories" name="toggleonly" value="showdirectories" type="radio"><span class="slider round"></span></label></span>
                    &nbsp;
                    <span style="font-size:11px; color:gray;">Show all </span><span style="position:relative; top:8px;"><label class="switch"><input onchange="setCookie('tagsshowall', document.getElementById('showall').checked); $('#toggleform').submit();" id="showall" name="toggleonly" value="showall" type="radio"><span class="slider round"></span></label></span>
                </form>
                <form class="form-inline" style="display:inline" name="toggleform_dirnorecurs" id="toggleform_dirnorecurs" method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <span style="font-size:11px; color:gray;">Dir size no recurs </span><span style="position:relative; top:8px;"><label class="switch" title="Directories size not recursive"><input onchange="setCookie('tagsshowdirnorecurs', document.getElementById('showdirnorecurs').checked); $('#toggleform_dirnorecurs').submit();" id="showdirnorecurs" name="toggledirnorecurs" value="showdirnorecurs" type="checkbox"><span class="slider round"></span></label></span>
                </form>
                <?php if (sizeof($toppaths) > 1) { ?>
                <form class="form-inline" style="display:inline" name="toggleform_toppath" id="toggleform_toppath" method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <span style="font-size:11px; color:gray;">Current top path only </span><span style="position:relative; top:8px;"><label class="switch"><input onchange="setCookie('tagsshowtoppath', document.getElementById('showtoppath').checked); $('#toggleform_toppath').submit();" id="showtoppath" name="toggletoppath" value="showtoppath" type="checkbox"><span class="slider round"></span></label></span>
                </form>
                <?php } ?>
                <form class="form-inline" style="display:inline" name="toggleform_currentdir" id="toggleform_currentdir" method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <span style="font-size:11px; color:gray;">Current dir only </span><span style="position:relative; top:8px;"><label class="switch"><input onchange="setCookie('tagsshowcurrentdir', document.getElementById('showcurrentdir').checked); $('#toggleform_currentdir').submit();" id="showcurrentdir" name="togglecurrentdir" value="showcurrentdir" type="checkbox"><span class="slider round"></span></label></span>
                </form>
                &nbsp;&nbsp;&nbsp;&nbsp;<span><a href="editreports.php" target="_blank" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-edit"></i> Edit reports</a> <a href="#" onclick="location.reload()" class="btn btn-default btn-sm"><i class="glyphicon glyphicon-refresh"></i> Reload</a></span>
            </div>
        </div>
        <?php if ($currentdironly || $toppathonly) { ?>
        <div class="row">
            <div class="col-lg-12">
                <?php if ($currentdironly) {
                    echo '<span class="small" style="font-weight:bold;">' . $path . '</span>';
                } elseif ($toppathonly) {
                    echo '<span class="small" style="font-weight:bold;">' . $_SESSION['rootpath'] . '</span>';
                } ?>
            </div>
        </div>
        <?php } ?>
        <div class="row">
            <div class="col-xs-12 text-center">
                <h5><?php echo $report ?></h5>
                <h6>total: <?php echo number_format($totalCount) ?></h6>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6">
                <div id="reportstopcountchart" class="text-center"></div>
            </div>
            <div class="col-xs-6">
                <div class="chartbox" style="margin-top:60px; line-height:2.1em;">
                    <?php foreach ($ReportsTopValuesByCount as $key => $value) { 
                        foreach ($value as $val) {
                            $query = $reportsQueries[$key][0] . ' AND ' . $val['field'] . ': "' . $val['name'] . '" AND type:' . $doctype;
                            if ($toppathonly) {
                                $query = $query . ' AND parent_path:(' . escape_chars($_SESSION['rootpath']) . ' OR ' . escape_chars($_SESSION['rootpath']) . '\/*)';
                            }
                            if ($currentdironly) {
                                $query = $query . ' AND parent_path:(' . escape_chars($path) . ' OR ' . escape_chars($path) . '\/*)';
                            }
                            ?>
                        <span class="label label-default" style="font-size:12px"><a href="search.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;submitted=true&amp;p=1&amp;q=<?php echo rawurlencode($query) ?>&amp;doctype=<?php echo $doctype_href ?>" target="_blank"><i class="glyphicon glyphicon-stop" id="<?php echo $val['name'] . '_count' ?>"></i> <?php echo $val['name']; ?> (<?php echo number_format($val['count']); ?></a>)</span>
                    <?php } } ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 text-center">
                <h6>total: <?php echo formatBytes($totalSize) ?></h6>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6">
                <div id="reportstopsizechart" class="text-center"></div>
            </div>
            <div class="col-xs-6">
                <div class="chartbox" style="margin-top:60px; line-height:2.1em;">
                    <?php foreach ($ReportsTopValuesBySize as $key => $value) { 
                        foreach ($value as $val) {
                            $query = $reportsQueries[$key][0] . ' AND ' . $val['field'] . ': "' . $val['name'] . '" AND type:' . $doctype;
                            if ($toppathonly) {
                                $query = $query . ' AND parent_path:(' . escape_chars($_SESSION['rootpath']) . ' OR ' . escape_chars($_SESSION['rootpath']) . '\/*)';
                            }
                            if ($currentdironly) {
                                $query = $query . ' AND parent_path:(' . escape_chars($path) . ' OR ' . escape_chars($path) . '\/*)';
                            }
                            ?>
                        <span class="label label-default" style="font-size:12px"><a href="search.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;submitted=true&amp;p=1&amp;q=<?php echo rawurlencode($query) ?>&amp;doctype=<?php echo $doctype_href ?>" target="_blank"><i class="glyphicon glyphicon-stop" id="<?php echo $val['name'] . '_size' ?>"></i> <?php echo $val['name']; ?> (<?php echo formatBytes($val['size']); ?></a>)</span>
                    <?php } } ?>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
    
    <script language="javascript" src="js/jquery.min.js"></script>
    <script language="javascript" src="js/bootstrap.min.js"></script>
    <script language="javascript" src="js/diskover.js"></script>
    <script language="javascript" src="js/d3.v3.min.js"></script>
    <script language="javascript" src="js/d3.tip.v0.6.3.js"></script>

    <!-- button toggle script -->
    <script>
        if (getCookie('tagsshowfiles') === "true" || getCookie('tagsshowfiles') == "") {
            $('#showfiles').prop('checked', true);
        } else {
            $('#showfiles').prop('checked', false);
        }
        if (getCookie('tagsshowdirectories') === "true") {
            $('#showdirectories').prop('checked', true);
        } else {
            $('#showdirectories').prop('checked', false);
        }
        if (getCookie('tagsshowall') === "true") {
            $('#showall').prop('checked', true);
        } else {
            $('#showall').prop('checked', false);
        }
        if (getCookie('tagsshowtoppath') === "true") {
            $('#showtoppath').prop('checked', true);
        } else {
            $('#showtoppath').prop('checked', false);
        }
        if (getCookie('tagsshowcurrentdir') === "true") {
            $('#showcurrentdir').prop('checked', true);
        } else {
            $('#showcurrentdir').prop('checked', false);
        }
        if (getCookie('tagsshowdirnorecurs') === "true") {
            $('#showdirnorecurs').prop('checked', true);
        } else {
            $('#showdirnorecurs').prop('checked', false);
        }
        if (getCookie('reportssortbysize') === "true" || getCookie('reportssortbysize') == "") {
            $('#sortbysize').prop('checked', true);
        } else {
            $('#sortbysize').prop('checked', false);
        }
    </script>

    <!-- d3 charts -->
    <script>
        // Bar chart (reports top values by count)
        var dataset = [];

        dataset.push(
            <?php foreach ($ReportsTopValuesByCount as $key => $value) {
                foreach ($value as $val) {
                    $percent = round($val["count"] / $totalCount * 100, 3);
                    if ($percent > 0.9) {
            ?> {
                    label: '<?php echo $val["name"] ?>',
                    count: <?php echo $val["count"] ?>
               },
            <?php } } } ?>
        );

        var totalcount = d3.sum(dataset, function(d) {
            return d.count;
        });

        var width = 450;
        var height = 450;
        var margin = 40;
        var radius = Math.min(width, height) / 2 - margin;

        var color = d3.scale.category20c();

        var svg = d3.select("#reportstopcountchart")
            .append('svg')
            .attr('width', width)
            .attr('height', height)
            .append('g')
            .attr('transform', 'translate(' + width / 2 + ',' + height / 2 + ')');

        var tip = d3.tip()
            .attr('class', 'd3-tip')
            .html(function(d) {
                var percent = (d.value / totalcount * 100).toFixed(1) + '%';
                return "<span style='font-size:12px;color:white;'>" + d.data.label + "</span><br><span style='font-size:12px; color:red;'>" + numberWithCommas(d.value) + " (" + percent + ")</span>";
            });

        svg.call(tip);

        d3.select("#reportstopcountchart").append("div")
            .attr("class", "tooltip")
            .style("opacity", 0);

        var pie = d3.layout.pie()
            //.sort(null);
            .sort(function(a, b) { return d3.descending(a.count, b.count); })
            .value(function(d) {
                return d.count;
            });

        var path = d3.svg.arc()
            .outerRadius(radius * 0.8)
            .innerRadius(radius * 0.5);

        var label = d3.svg.arc()
            .outerRadius(radius * 1.0)
            .innerRadius(radius * 1.0);

        var arc = svg.selectAll('.arc')
            .data(pie(dataset))
            .enter().append('g')
            .attr('class', 'arc');

        arc.append('path')
            .attr('d', path)
            .attr('class', path)
            .attr('fill', function(d) {
                var fgcolor = color(d.data.label);
                document.getElementById(d.data.label + '_count').style.color = fgcolor;
                return fgcolor;
            })
            .on("mouseover", function(d) {
                tip.show(d);
            })
            .on("mouseout", function(d) {
                tip.hide(d);
            })
            .on('mousemove', function() {
                return tip
                    .style("top", (d3.event.pageY - 10) + "px")
                    .style("left", (d3.event.pageX + 10) + "px");
            });

        arc.append('text')
            .attr("transform", function(d) {
                return "translate(" + label.centroid(d) + ")";
            })
            .attr("dy", "0.35em")
            .style("font-size", "11px")
            .text(function(d) {
                if (d.value > 0) {
                    return d.data.label
                };
            });
    </script>

    <script>
        // Bar chart (reports top values by size)
        var dataset = [];

        dataset.push(
            <?php foreach ($ReportsTopValuesBySize as $key => $value) {
                foreach ($value as $val) {
            ?> {
                    label: '<?php echo $val["name"] ?>',
                    size: <?php echo $val["size"] ?>
                },
            <?php } } ?>
        );

        var valueLabelWidth = 40; // space reserved for value labels (right)
        var barHeight = 15; // height of one bar
        var barLabelWidth = 100; // space reserved for bar labels
        var barLabelPadding = 10; // padding between bar and bar labels (left)
        var gridChartOffset = 0; // space between start of grid and first bar
        var maxBarWidth = 300; // width of the bar with the max value

        var totalsize = d3.sum(dataset, function(d) {
            return d.size;
        });

        // svg container element
        var height = barHeight * dataset.length;
        var svg = d3.select('#reportstopsizechart').append("svg")
            .attr('width', maxBarWidth + barLabelWidth + valueLabelWidth + barLabelPadding)
            .attr('height', height);

        svg.append("g")
            .attr("class", "bars");
        svg.append("g")
            .attr("class", "barvaluelabel");
        svg.append("g")
            .attr("class", "barlabel");

        /* ------- TOOLTIP -------*/

        var tip2 = d3.tip()
            .attr('class', 'd3-tip')
            .html(function(d) {
                var percent = (d.size / totalsize * 100).toFixed(1) + '%';
                return "<span style='font-size:12px;color:white;'>" + d.label + "</span><br><span style='font-size:12px; color:red;'>size: " + format(d.size) + " (" + percent + ")</span>";
            });

        svg.call(tip2);

        d3.select("reportstopsizechart").append("div")
            .attr("class", "tooltip")
            .style("opacity", 0);

        /* ------- BARS -------*/

        // accessor functions
        var barLabel = function(d) {
            return d['label'];
        };
        var barValue = function(d) {
            return d['size'];
        };

        // scales
        var yScale = d3.scale.ordinal().domain(d3.range(0, dataset.length)).rangeBands([0, dataset.length * barHeight]);
        var y = function(d, i) {
            return yScale(i);
        };
        var yText = function(d, i) {
            return y(d, i) + yScale.rangeBand() / 2;
        };
        var x = d3.scale.linear().domain([0, d3.max(dataset, barValue)]).range([0, maxBarWidth]);

        // bars
        var bar = svg.select(".bars").selectAll("rect")
            //.data(dataset);
            .data(dataset.sort(function(x, y) { return d3.descending(x.size, y.size); }));

        bar.enter().append("rect")
            .attr('transform', 'translate(' + barLabelWidth + ',' + gridChartOffset + ')')
            .attr('height', yScale.rangeBand())
            .attr('y', y)
            .attr('class', 'bars')
            .style('fill', function(d) {
                var fgcolor = color(d.label);
                document.getElementById(d.label + '_size').style.color = fgcolor;
                return fgcolor;
            })
            .attr('width', function(d) {
                return x(barValue(d));
            })
            .on("mouseover", function(d) {
                tip2.show(d);
            })
            .on('mouseout', function(d) {
                tip2.hide(d)
            })
            .on('mousemove', function() {
                return tip2
                    .style("top", (d3.event.pageY - 10) + "px")
                    .style("left", (d3.event.pageX + 10) + "px");
            });


        bar
            .transition().duration(750)
            .attr("width", function(d) {
                return x(barValue(d));
            });

        bar.exit().remove();

        // bar labels
        var barlabel = svg.select(".barlabel").selectAll('text').data(dataset);

        barlabel.enter().append('text')
            .attr('transform', 'translate(' + (barLabelWidth - barLabelPadding) + ',' + gridChartOffset + ')')
            .attr('y', yText)
            .attr("dy", ".35em") // vertical-align: middle
            .attr("class", "barlabel")
            .text(barLabel);

        barlabel.exit().remove();

        // bar value labels
        var barvaluelabel = svg.select(".barvaluelabel").selectAll('text').data(dataset);

        barvaluelabel.enter().append("text")
            .attr('transform', 'translate(' + barLabelWidth + ',' + gridChartOffset + ')')
            .attr("dx", 3) // padding-left
            .attr("dy", ".35em") // vertical-align: middle
            .attr("class", "barvaluelabel");

        barvaluelabel
            .attr("x", function(d) {
                return x(barValue(d));
            })
            .attr("y", yText)
            .text(function(d) {
                return format(barValue(d));
            });

        barvaluelabel.exit().remove();
    </script>
</body>

</html>