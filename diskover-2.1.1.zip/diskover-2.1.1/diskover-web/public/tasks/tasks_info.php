<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../vendor/autoload.php';
require "../../src/diskover/Auth.php";
require "../../src/diskover/Diskover.php";
require "tasks_inc.php";

// read tasks json file
$tasks_json = readTasksFile("tasks.json");
$tasks_arr = json_decode($tasks_json, true);
$tasklist = $tasks_arr['tasks'];
// get task matching id
$id = $_GET['id'];
$taskinfo = [];
foreach ($tasklist as $key => $value) {
    if ($value['id'] === $id) {
        $taskinfo = $tasklist[$key];
        break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>diskover &mdash; Task Info</title>
    <link rel="stylesheet" href="../css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="../css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="../css/diskover-tasks.css" media="screen" />
    <link rel="icon" type="image/png" href="../images/diskoverfavico.png" />
</head>

<body>
    <?php include "tasks_nav.php"; ?>

    <div class="container-fluid" id="mainwindow" style="margin-top:70px">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2">
            <h1 class="page-header">Task Info</h1>
                <div class="panel panel-default">
                    <div class="panel-heading">ID</div>
                    <div class="panel-body">
                        <?php echo $taskinfo['id'] ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Type</div>
                    <div class="panel-body">
                        <?php echo $taskinfo['type'] ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Name</div>
                    <div class="panel-body">
                        <?php echo $taskinfo['name'] ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Description</div>
                    <div class="panel-body">
                        <?php echo $taskinfo['description'] ?>
                    </div>
                </div>
                <?php if ($taskinfo['type'] === 'index') { ?>
                <div class="panel panel-default">
                    <div class="panel-heading">Crawl Directory(s)</div>
                    <div class="panel-body">
                        <?php echo $taskinfo['crawl_paths'] ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Alt Scanner</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['alt_scanner'])) ? $taskinfo['alt_scanner'] : '-' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">CLI Options/Flags</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['cli_options'])) ? $taskinfo['cli_options'] : '-' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Auto Index Name</div>
                    <div class="panel-body">
                        <?php echo ($taskinfo['auto_index_name']) ? 'Yes' :  'No' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Custom Index Name</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['custom_index_name'])) ? $taskinfo['custom_index_name'] :  '-' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Overwrite Existing</div>
                    <div class="panel-body">
                        <?php echo ($taskinfo['overwrite_existing']) ? 'Yes' :  'No' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Add To Index</div>
                    <div class="panel-body">
                        <?php echo ($taskinfo['add_to_index']) ? 'Yes' :  'No' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Use Default Config</div>
                    <div class="panel-body">
                        <?php echo ($taskinfo['use_default_config']) ? 'Yes' :  'No' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Alternate Config File Directory</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['alt_config_file'])) ? $taskinfo['alt_config_file'] :  '-' ?>
                    </div>
                </div>
                <?php } ?>
                <div class="panel panel-default">
                    <div class="panel-heading">Schedule</div>
                    <div class="panel-body">
                        <?php
                        $schedule = $taskinfo['run_min'] . " " . $taskinfo['run_hour'] . " " . $taskinfo['run_day_month'] .
                            " " . $taskinfo['run_month'] . " " . $taskinfo['run_day_week'];
                        echo $schedule;
                        ?>
                    </div>
                    <div class="panel-footer">
<pre>
┌───────────── minute (0 - 59)
│ ┌───────────── hour (0 - 23)
│ │ ┌───────────── day of the month (1 - 31)
│ │ │ ┌───────────── month (1 - 12)
│ │ │ │ ┌───────────── day of the week (0 - 6) (Sunday to Saturday)
│ │ │ │ │ 
│ │ │ │ │
│ │ │ │ │
* * * * *</pre>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Environment Vars</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['env_vars'])) ? $taskinfo['env_vars'] :  '-' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Pre-Command</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['pre_command'])) ? $taskinfo['pre_command'] :  '-' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Pre-Command Args</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['pre_command_args'])) ? $taskinfo['pre_command_args'] :  '-' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Post-Command</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['post_command'])) ? $taskinfo['post_command'] :  '-' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Post-Command Args</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['post_command_args'])) ? $taskinfo['post_command_args'] :  '-' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Retries</div>
                    <div class="panel-body">
                        <?php echo $taskinfo['retries'] ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Retry Delay (sec)</div>
                    <div class="panel-body">
                        <?php echo $taskinfo['retry_delay'] ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Timeout (sec)</div>
                    <div class="panel-body">
                        <?php echo $taskinfo['timeout'] ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Last Start Time</div>
                    <div class="panel-body">
                        <?php echo utcTimeToLocal($taskinfo['last_start_time']) ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Last Finish Time</div>
                    <div class="panel-body">
                        <?php echo utcTimeToLocal($taskinfo['last_finish_time']) ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Task Time</div>
                    <div class="panel-body">
                    <?php
                    $date = new DateTime($taskinfo['last_start_time']);
                    $date2 = new DateTime($taskinfo['last_finish_time']);
                    $diffInSeconds = $date2->getTimestamp() - $date->getTimestamp();
                    echo secondsToTime($diffInSeconds);
                    ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Last Success Finish Time</div>
                    <div class="panel-body">
                        <?php echo utcTimeToLocal($taskinfo['last_success_finish_time']) ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Last Update Time</div>
                    <div class="panel-body">
                        <?php echo utcTimeToLocal($taskinfo['last_update_time']) ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Last Status</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['last_status'])) ? $taskinfo['last_status'] :  '-' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Last Worker</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['last_worker'])) ? $taskinfo['last_worker'] :  '-' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Assigned Worker</div>
                    <div class="panel-body">
                        <?php echo $taskinfo['assigned_worker'] ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Email</div>
                    <div class="panel-body">
                        <?php echo (!empty($taskinfo['email'])) ? $taskinfo['email'] : 'none' ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Disabled</div>
                    <div class="panel-body">
                        <?php echo ($taskinfo['disabled']) ? 'Yes' : 'No' ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script language="javascript" src="../js/jquery.min.js"></script>
    <script language="javascript" src="../js/bootstrap.min.js"></script>
    <script language="javascript" src="../js/diskover.js"></script>

</body>

</html>