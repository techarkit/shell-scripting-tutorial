<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';
require "../src/diskover/Diskover.php";

error_reporting(E_ALL ^ E_NOTICE);

ini_set('memory_limit', '256M');
set_time_limit(600);
// es search size
$searchsize = 1000;
// es scroll time
$scrolltime = '1m';


// search query
$q = $_GET['q'];
// curent page
$p = $_GET['p'];
// result size of search results
$resultsize = $_GET['resultsize'];
// type of export
$export = $_GET['export'];
// doctype of export
$export_type = $_GET['export_type'];


// date of export
$dt = new DateTime('now', new DateTimeZone('UTC'));
$dt->setTimezone(new DateTimeZone($config->TIMEZONE));
$export_date = $dt->format('ymd_his');

// output results
// disable caching
$now = gmdate("D, d M Y H:i:s");
header("Expires: Tue, 03 Jul 2001 06:00:00 GMT");
header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
header("Last-Modified: {$now} GMT");
// force download
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
// disposition / encoding on response body
header("Content-Disposition: attachment;filename=diskover_export_{$export_type}_{$export_date}.{$export}");
header("Content-Transfer-Encoding: binary");

// Get search results from Elasticsearch
$results = [];
$searchParams = [];

// Setup search query
$searchParams['index'] = $mnclient->getSearchIndex($esIndex);

// Scroll parameter alive time
$searchParams['scroll'] = $scrolltime;


// search size (number of results to return per page)
if ((string)$p === "all") {
    // scroll size
    $searchParams['size'] = $searchsize;
} else {
    if (!empty($resultsize)) {
        $searchParams['size'] = $resultsize;
    } elseif (getCookie("resultsize") != "") {
        $searchParams['size'] = getCookie("resultsize");
    } else {
        $searchParams['size'] = $config->SEARCH_RESULTS;
    }
}

// match all if search field empty
if (empty($q)) {
    $searchParams['body'] = [
        'query' => [
            'query_string' => [
                'query' => 'type:(file OR directory)'
            ]
        ]
    ];
    // match what's in the search field
} else {
    // get request string from predict_search
    $request = predict_search($q);
    $searchParams['body'] = [
        'query' => [
            'query_string' => [
                'query' => '(' . $request . ') AND type:(file OR directory)',
                'analyze_wildcard' => 'true',
                'fields' => ['name^5', 'name.text', 'parent_path', 'parent_path.text', 'extension'],
                'default_operator' => 'AND'
            ]
        ]
    ];
}

// check if we need to apply any filters to search
$searchParams = filterIndexMappingPaths($searchParams);
$searchParams = filterLDAPGroups($searchParams);
$searchParams = filterSearchResults($searchParams);

// Sort search results
$searchParams = sortSearchResults($_GET, $searchParams);

try {
    // Send search query to Elasticsearch and get scroll id and first page of results
    $queryResponse_fields = $client->search($searchParams);
} catch (Exception $e) {
    handleError('ES Error: ' . $e->getMessage(), false);
}

try {
    // Send search query to Elasticsearch and get scroll id and first page of results
    $queryResponse = $client->search($searchParams);
} catch (Exception $e) {
    handleError('ES Error: ' . $e->getMessage(), false);
}

// set total hits
$total = $queryResponse['hits']['total']['value'];

$output_title = true;
$fields = array();


if ((string)$p === "all") {
    // Loop through all the pages of results and get all field names and column titles
    while (count($queryResponse_fields['hits']['hits']) > 0) {
        
        // Get fields
        foreach ($queryResponse_fields['hits']['hits'] as $hit) {
            // skip if not export type (file or directory)
            if ($hit['_source']['type'] !== $export_type) continue;

            foreach ($hit['_source'] as $key => $val) {
                if (!array_key_exists($key, $fields)) {
                    $fields[$key] = array();
                }
                if (is_array($val)) {
                    foreach ($val as $v_key => $v_val) {
                        $v = $key . '.' . $v_key;
                        if (!in_array($v, $fields[$key])) {
                            $fields[$key][] = $v;
                        }
                    }
                }
            }
        }

        $scroll_id = $queryResponse_fields['_scroll_id'];

        $queryResponse_fields = $client->scroll([
            "body" => [
                "scroll_id" => $scroll_id,
                "scroll" => $scrolltime
            ]
        ]);
    }

    // clear current scroll window
    if (!empty($scroll_id)) {
        $client->clearScroll(array('scroll_id' => $scroll_id));
        $scroll_id = null;
    }

    // Loop through all the pages of results
    while (count($queryResponse['hits']['hits']) > 0) {

        // Get results
        foreach ($queryResponse['hits']['hits'] as $hit) {
            // skip if not export type (file or directory)
            if ($hit['_source']['type'] !== $export_type) continue;

            $results[] = $hit['_source'];
            if (sizeof($results) >= $searchsize) {
                export($results);
                unset($results);
                $output_title = false;
            }
        }

        $scroll_id = $queryResponse['_scroll_id'];

        $queryResponse = $client->scroll([
            "body" => [
                "scroll_id" => $scroll_id,
                "scroll" => $scrolltime
            ]
        ]);
    }

    // clear current scroll window
    if (!empty($scroll_id)) {
        $client->clearScroll(array('scroll_id' => $scroll_id));
        $scroll_id = null;
    }

} else {
    $i = 1;
    // Loop through all the pages of results and get field names and column titles
    while ($i <= ceil($total/$searchParams['size'])) {

        // check if we have the results for the page we are on
        if ($i == $p) {
            // Get fields
            foreach ($queryResponse_fields['hits']['hits'] as $hit) {
                // skip if not export type (file or directory)
                if ($hit['_source']['type'] !== $export_type) continue;

                foreach ($hit['_source'] as $key => $val) {
                    if (!array_key_exists($key, $fields)) {
                        $fields[$key] = array();
                    }
                    if (is_array($val)) {
                        foreach ($val as $v_key => $v_val) {
                            $v = $key . '.' . $v_key;
                            if (!in_array($v, $fields[$key])) {
                                $fields[$key][] = $v;
                            }
                        }
                    }
                }
            }
            // end loop
            break;
        }

        $scroll_id = $queryResponse_fields['_scroll_id'];

        $queryResponse_fields = $client->scroll([
            "body" => [
                "scroll_id" => $scroll_id,
                "scroll" => $scrolltime
            ]
        ]);

        $i += 1;
    }

    // clear current scroll window
    if (!empty($scroll_id)) {
        $client->clearScroll(array('scroll_id' => $scroll_id));
        $scroll_id = null;
    }

    $i = 1;
    // Loop through all the pages of results
    while ($i <= ceil($total/$searchParams['size'])) {

    // check if we have the results for the page we are on
        if ($i == $p) {
            // Get results
            foreach ($queryResponse['hits']['hits'] as $hit) {
                // skip if not export type (file or directory)
                if ($hit['_source']['type'] !== $export_type) continue;

                $results[] = $hit['_source'];
                if (sizeof($results) >= $searchsize) {
                    export($results);
                    unset($results);
                    $output_title = false;
                }
            }
            // end loop
            break;
        }

        $scroll_id = $queryResponse['_scroll_id'];

        $queryResponse = $client->scroll([
            "body" => [
                "scroll_id" => $scroll_id,
                "scroll" => $scrolltime
            ]
        ]);

        $i += 1;
    }

    // clear current scroll window
    if (!empty($scroll_id)) {
        $client->clearScroll(array('scroll_id' => $scroll_id));
        $scroll_id = null;
    }
}


// export any remaining docs
export($results);
unset($results);


function array2csv($arr) {
    global $fields, $output_title;

    if (count($arr) == 0) {
     return null;
    }

    // clean output buffer
    ob_end_clean();
    $df = fopen("php://output", 'w');
    // write column titles row
    if ($output_title) {
        $line = array();
        foreach ($fields as $key => $value) {
            if (count($value) > 0) {
                foreach ($value as $v) {
                    $line[] = $v;
                }
            } else {
                $line[] = $key;
            }
        }
        fputcsv($df, $line);
    }
    // write rows
    foreach ($arr as $value) {
        $line = array();

        foreach ($fields as $fieldname => $fieldsubnames) {
            // add empty column(s) and continue if doc source does not contain matching field
            if (!array_key_exists($fieldname, $value)) {
                if (count($fieldsubnames) === 0) {
                    $line[] = '';
                } else {
                    $i = 0;
                    while ($i < count($fieldsubnames)) {
                        $line[] = '';
                        $i++;
                    }
                }
                continue;
            }
            $val = $value[$fieldname];
            if (is_array($val)) {
                foreach ($val as $v_val) {
                    if (is_bool($v_val)) {
                        $v_val = ($v_val) ? 'true' : 'false';
                    }
                    $line[] = (isset($v_val)) ? $v_val : '';
                }
                // add empty column(s) if size of doc field array does not equal column titles
                if (count($val) !== count($fieldsubnames)) {
                    $i = count($val);
                    while ($i < count($fieldsubnames)) {
                        $line[] = '';
                        $i++;
                    }
                }
            } else {
                if (is_bool($val)) {
                    $val = ($val) ? 'true' : 'false';
                }
                $line[] = (isset($val)) ? $val : '';
            }
        }
        fputcsv($df, $line);
    }
    fclose($df);
    // flush buffer
    ob_flush();
}

function export($results_source) {
    global $export;

    if (count($results_source) == 0) {
        return null;
    }
    if ($export == "json") {
        echo json_encode($results_source);
    } elseif ($export == "csv") {
        echo array2csv($results_source);
    }
}
