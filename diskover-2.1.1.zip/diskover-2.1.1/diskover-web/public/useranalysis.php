<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';
require "../src/diskover/Auth.php";
require "d3_inc.php";


$topconsumers_users = [];
$topconsumers_groups = [];

// determine if only current top path should be used
if (!isset($_GET['toggletoppath'])) {
    if (getCookie('tagsshowtoppath') == 'true') {
        $toppathonly = true;
    } else {
        $toppathonly = false;
    }
} else {
    if ($_GET['toggletoppath'] === "showtoppath") {
        $toppathonly = true;
        createCookie('tagsshowtoppath', 'true');
    } else {
        $toppathonly = false;
        createCookie('tagsshowtoppath', 'false');
    }
}

// determine if only current directory should be used
if (!isset($_GET['togglecurrentdir'])) {
    if (getCookie('tagsshowcurrentdir') == 'true') {
        $currentdironly = true;
    } else {
        $currentdironly = false;
    }
} else {
    if ($_GET['togglecurrentdir'] === "showcurrentdir") {
        $currentdironly = true;
        createCookie('tagsshowcurrentdir', 'true');
    } else {
        $currentdironly = false;
        createCookie('tagsshowcurrentdir', 'false');
    }
}

// number of users and groups to show
$num_users_groups = getCookie('userssearchsize') !== '' ? getCookie('userssearchsize') : 50;

$searchParams = [];

$searchParams['index'] = $mnclient->getSearchIndex($esIndex);

foreach (['owner', 'group'] as $key => $value) {
    $results = [];

    $query = 'type:file';
    if ($toppathonly) {
        $query = $query . ' AND parent_path:(' . escape_chars($_SESSION['rootpath']) . ' OR ' . escape_chars($_SESSION['rootpath']) . '\/*)';
    }
    if ($currentdironly) {
        $query = $query . ' AND parent_path:(' . escape_chars($path) . ' OR ' . escape_chars($path) . '\/*)';
    }

    $searchParams['body'] = [
        'size' => 0,
        'query' => [
            'query_string' => [
                'query' => $query,
                'analyze_wildcard' => 'true'
            ]
        ],
        'aggs' => [
            'top_consumers' => [
                'terms' => [
                    'field' => $value,
                    'order' => [
                        'file_size' => 'desc'
                    ],
                    'size' => $num_users_groups
                ],
                'aggs' => [
                    'file_size' => [
                        'sum' => [
                            'field' => 'size'
                        ]
                    ],
                    'file_size_du' => [
                        'sum' => [
                            'field' => 'size_du'
                        ]
                    ]
                ]
            ]
        ]
    ];
    if ($showcostpergb) {
        $searchParams['body']['aggs']['top_consumers']['aggs'] += [  
            'avg_cost_per_gb' => [
                'avg' => [
                    'field' => 'costpergb'
                ]
            ],
            'cost_per_gb' => [
                'sum' => [
                    'field' => 'costpergb'
                ]
            ]
        ];
    }

    // check if we need to apply any filters to search
    $searchParams = filterIndexMappingPaths($searchParams);
    $searchParams = filterLDAPGroups($searchParams);

    try {
        // Send search query to Elasticsearch and get scroll id and first page of results
        $queryResponse = $client->search($searchParams);
    } catch (Exception $e) {
        handleError('ES error: ' . $e->getMessage());
    }

    $results = $queryResponse['aggregations']['top_consumers']['buckets'];

    $arr = [];
    foreach ($results as $result) {
        $arr_result = [
            "name" => $result['key'],
            "filecount" => $result['doc_count'],
            "filesize" => $result['file_size']['value'],
            "filesize_du" => $result['file_size_du']['value']
        ];
        if ($showcostpergb) {
            $arr_result += [
                "avgcostpergb" => $result['avg_cost_per_gb']['value'],
                "costpergb" => $result['cost_per_gb']['value']
            ];
        }
        $arr[] = $arr_result;
        if ($key == "owner") {
            $topconsumers_users = $arr;
        } else {
            $topconsumers_groups = $arr;
        }
    }
}

// calculate total file size and count
$totalusersize = 0;
$totalusercount = 0;
$totalgroupsize = 0;
$totalgroupcount = 0;
foreach ($topconsumers_users as $key => $value) {
    $totalusersize += $value['filesize'];
    $totalusercount += $value['filecount'];
}
foreach ($topconsumers_groups as $key => $value) {
    $totalgroupsize += $value['filesize'];
    $totalgroupcount += $value['filecount'];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>diskover &mdash; User Analysis</title>
    <link rel="stylesheet" href="css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="css/diskover.css" media="screen" />
    <link rel="stylesheet" href="css/diskover-tags.css" media="screen" />
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css" media="screen" />
    <link rel="icon" type="image/png" href="images/diskoverfavico.png" />
</head>

<body>
    <?php include "nav.php"; ?>
    <div class="container" id="mainwindow" style="margin-top:70px;">
        <h1 class="page-header text-center"><i class="glyphicon glyphicon-user"></i> User Analysis</h1>
        <h5 class="text-center">Top <?php echo number_format($num_users_groups) ?> users/groups</h5>
        <div class="row">
            <div class="col-lg-12 text-right">
            <?php if (sizeof($toppaths) > 1) { ?>
                <form class="form-inline" style="display:inline" name="toggleform_toppath" id="toggleform_toppath" method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <span style="font-size:11px; color:gray;">Current top path only </span><span style="position:relative; top:8px;"><label class="switch"><input onchange="setCookie('tagsshowtoppath', document.getElementById('showtoppath').checked); $('#toggleform_toppath').submit();" id="showtoppath" name="toggletoppath" value="showtoppath" type="checkbox"><span class="slider round"></span></label></span>
                </form>
            <?php } ?>
                <form class="form-inline" style="display:inline" name="toggleform_currentdir" id="toggleform_currentdir" method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <span style="font-size:11px; color:gray;">Current dir only </span><span style="position:relative; top:8px;"><label class="switch"><input onchange="setCookie('tagsshowcurrentdir', document.getElementById('showcurrentdir').checked); $('#toggleform_currentdir').submit();" id="showcurrentdir" name="togglecurrentdir" value="showcurrentdir" type="checkbox"><span class="slider round"></span></label></span>
                </form>
                <div class="btn-group">
                    <button class="btn btn-default dropdown-toggle btn-sm" type="button" data-toggle="dropdown" title="Number of users/groups to show">Show top <?php echo $num_users_groups ?>
                        <span class="caret"></span></button>
                    <ul id="numusers" class="dropdown-menu">
                        <li><a href="#" onclick="setCookie('userssearchsize', 10); location.reload();">10</a></li>
                        <li><a href="#" onclick="setCookie('userssearchsize', 25); location.reload();">25</a></li>
                        <li><a href="#" onclick="setCookie('userssearchsize', 50); location.reload();">50 (default)</a></li>
                        <li><a href="#" onclick="setCookie('userssearchsize', 100); location.reload();">100</a></li>
                        <li><a href="#" onclick="setCookie('userssearchsize', 200); location.reload();">200</a></li>
                        <li><a href="#" onclick="setCookie('userssearchsize', 500); location.reload();">500</a></li>
                        <li><a href="#" onclick="setCookie('userssearchsize', 1000); location.reload();">1,000</a></li>
                        <li><a href="#" onclick="setCookie('userssearchsize', 10000); location.reload();">10,000</a></li>
                    </ul>
                </div>
                <a href="#" onclick="location.reload()" class="btn btn-default btn-sm"><i class="glyphicon glyphicon-refresh"></i> Reload</a></span>
            </div>
        </div>
        <?php if ($currentdironly || $toppathonly) { ?>
        <div class="row">
            <div class="col-lg-12">
                <?php if ($currentdironly) {
                    echo '<span class="small" style="font-weight:bold;">' . $path . '</span>';
                } elseif ($toppathonly) {
                    echo '<span class="small" style="font-weight:bold;">' . $_SESSION['rootpath'] . '</span>';
                } ?>
            </div>
        </div>
        <?php } ?>
        <div class="row">
            <div class="col-lg-12">
                <br>
                <?php
                foreach (['owner', 'group'] as $key => $value) { ?>
                    <table class="table table-striped table-hover" id="users-table-<?php echo $value ?>" data-order='[[ 1, "desc" ]]' style="width:100%">
                        <thead>
                            <tr>
                                <th><?php echo ucfirst($value); ?></th>
                                <th>Size</th>
                                <th>Allocated</th>
                                <th>%</th>
                                <?php if ($showcostpergb) { ?>
                                    <th>Cost per GB</th>
                                    <th>Avg Cost per GB</th>
                                <?php } ?>
                                <th>Files</th>
                                <th>%</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($value == "owner") {
                                $arr = $topconsumers_users;
                                $totalsize = $totalusersize;
                                $totalcount = $totalusercount;
                            } else {
                                $arr = $topconsumers_groups;
                                $totalsize = $totalgroupsize;
                                $totalcount = $totalgroupcount;
                            }
                            foreach ($arr as $k => $v) {  
                                $query = $value . ":\"" . $v['name'] ."\"";
                                if ($toppathonly) {
                                    $query = $query . ' AND parent_path:(' . escape_chars($_SESSION['rootpath']) . ' OR ' . escape_chars($_SESSION['rootpath']) . '\/*)';
                                }
                                if ($currentdironly) {
                                    $query = $query . ' AND parent_path:(' . escape_chars($path) . ' OR ' . escape_chars($path) . '\/*)';
                                }
                                ?>
                                <tr>
                                    <td><a href="search.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;submitted=true&amp;p=1&q=<?php echo rawurlencode($query); ?>" target="_blank"><i class="glyphicon glyphicon-user" style="color:#D19866; padding-right:3px;"></i> <?php echo $v['name']; ?></a></td>
                                    <td><?php echo formatBytes($v['filesize']); ?></td>
                                    <td><?php echo formatBytes($v['filesize_du']); ?></td>
                                    <td width="15%">
                                        <div class="progress" style="position:relative; top: 6px; height: 8px">
                                            <div title="<?php echo number_format(($v['filesize'] / $totalsize) * 100, 2); ?>%" class="progress-bar progress-bar-info" style="width:<?php echo number_format(($v['filesize'] / $totalsize) * 100, 2); ?>%;"></div>
                                        </div>
                                    </td>
                                    <?php if ($showcostpergb) { ?>
                                        <td class="text-nowrap darken">$ <?php echo number_format(round($v['costpergb'], 2), 2); ?></td>
                                        <td class="text-nowrap darken">$ <?php echo number_format(round($v['avgcostpergb'], 2), 2); ?></td>
                                    <?php } ?>
                                    <td><?php echo number_format($v['filecount']); ?></td>
                                    <td width="15%">
                                        <div class="progress" style="position:relative; top: 6px; height: 8px">
                                            <div title="<?php echo number_format(($v['filecount'] / $totalcount) * 100, 2); ?>%" class="progress-bar progress-bar-info" style="width:<?php echo number_format(($v['filecount'] / $totalcount) * 100, 2); ?>%;"></div>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                <?php } ?>
            </div>
        </div>
    </div>
    
    <script language="javascript" src="js/jquery.min.js"></script>
    <script language="javascript" src="js/bootstrap.min.js"></script>
    <script language="javascript" src="js/diskover.js"></script>
    <script language="javascript" src="js/jquery.dataTables.min.js"></script>
    <script language="javascript" src="js/dataTables.bootstrap.min.js"></script>
    <script language="javascript" src="js/file-size.js"></script>
    <script language="javascript" src="js/natural.js"></script>

    <!-- button toggle script -->
    <script>
        $(document).ready(function() {
            var num_users_groups = <?php echo $num_users_groups ?>;
            var showcostpergb = <?php echo (isset($showcostpergb) && $showcostpergb) ? 'true' : 'false' ?>;
            if (showcostpergb) {
                var targets = [3,7]
            } else {
                var targets = [3,5]
            }

            // make data table
            $("#users-table-owner").DataTable({
                "stateSave": true,
                "lengthChange": false,
                "pageLength": num_users_groups,
                "columnDefs": [
                    {
                        "type": "natural",
                        targets: 0
                    },
                    {
                        "type": "file-size",
                        targets: [1,2]
                    },
                    {
                        "orderable": false,
                        targets: targets
                    }
                ]
            });
            $("#users-table-group").DataTable({
                "stateSave": true,
                "lengthChange": false,
                "pageLength": num_users_groups,
                "columnDefs": [
                    {
                        "type": "natural",
                        targets: 0
                    },
                    {
                        "type": "file-size",
                        targets: [1,2]
                    },
                    {
                        "orderable": false,
                        targets: targets
                    }
                ]
            });

            if (getCookie('tagsshowtoppath') === "true") {
                $('#showtoppath').prop('checked', true);
            } else {
                $('#showtoppath').prop('checked', false);
            }

            if (getCookie('tagsshowcurrentdir') === "true") {
                $('#showcurrentdir').prop('checked', true);
            } else {
                $('#showcurrentdir').prop('checked', false);
            }
        });
    </script>
</body>

</html>