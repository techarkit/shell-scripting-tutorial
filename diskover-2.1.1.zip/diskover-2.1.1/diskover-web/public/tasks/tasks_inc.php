<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../src/diskover/config_inc.php';

// check task panel user is logged in
if ($config->LOGIN_REQUIRED) {
    if (!$taskpaneluser) {
        echo '<script>alert("Task panel user required"); window.history.back();</script>';
        exit();
    }
}

function readTasksFile($file) {
    try {
        if (!file_exists($file)) {
            handleError("File " . $file . " not found.");
        }
        try {
            // get the contents of the file
            // lock the file before getting contents
            $fh = fopen($file, 'r');
            flock($fh, LOCK_SH);
            $filecontents = file_get_contents($file);
            // unlock the file after getting contents
            flock($fh, LOCK_UN);
        } catch (Exception $e) {
            handleError("File ".$file." open failed. " . $e->getMessage());
        }
    } catch (Exception $e) {
        handleError("Error opening " . $file . " " . $e->getMessage());
    }
    return $filecontents;
}

function writeToTasksFile($file, $data) {
    try {
        if (!file_exists($file)) {
            handleError("File " . $file . " not found.");
        }
        try {
            file_put_contents($file, $data, LOCK_EX);
        } catch (Exception $e) {
            handleError("File ".$file." write failed. " . $e->getMessage());
        }
    } catch (Exception $e) {
        handleError("Error writing to " . $file . " " . $e->getMessage());
    }
}