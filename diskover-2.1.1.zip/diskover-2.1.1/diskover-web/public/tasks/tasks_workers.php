<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../vendor/autoload.php';
require "../../src/diskover/Auth.php";
require "../../src/diskover/Diskover.php";
require "tasks_inc.php";


// read workers json file
$workers_json = readTasksFile("workers.json");
$workers_arr = json_decode($workers_json, true);
$workers_sorted = $workers_arr['workers'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>diskover &mdash; Task Workers</title>
    <link rel="stylesheet" href="../css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="../css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="../css/diskover-tasks.css" media="screen" />
    <link rel="stylesheet" href="../css/dataTables.bootstrap.min.css" media="screen" />
    <link rel="icon" type="image/png" href="../images/diskoverfavico.png" />
</head>

<body>
    <?php include "tasks_nav.php"; ?>

    <div class="container-fluid" id="mainwindow" style="margin-top:70px">
        <h1 class="page-header">Task Workers</h1>
        <div class="row">
            <div class="col-lg-6">
                <div class="alert alert-dismissible alert-info">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <i class="glyphicon glyphicon-info-sign"></i> If there are no workers found, start a worker task daemon using <b>diskoverd.py</b>. A worker is considered offline (unknown state) after no hearbeat for more than 10 min or if shutdown.
                </div>
            </div>
            <div class="col-lg-6">
                <div class="alert alert-dismissible alert-success">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <i class="glyphicon glyphicon-info-sign"></i> PRO tip: Workers can be named using <b>diskoverd.py -n workername</b>. By default, workers are named using hostname + unique id.
                </div>
            </div>
        </div>
        <?php if (empty($workers_sorted)) { ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="alert alert-dismissible alert-warning">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <i class="glyphicon glyphicon-exclamation-sign"></i> No workers found.
                    </div>
                </div>
            </div>
        <?php } else { ?>
            <div class="row">
                <div class="col-lg-12">
                <p class="pull-right"><?php echo count($workers_sorted) . " workers found (last updated <script>document.write(new Date().toLocaleString());</script> <a href=\"tasks_workers.php\">update</a>)"; ?></p>
                    <table class="table table-striped table-hover table-condensed" id="task-workers-table" data-order='[[ 0, "asc" ]]' style="width:100%">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Hostname</th>
                                <th>PID</th>
                                <th>User</th>
                                <th>State</th>
                                <th>Current Tasks</th>
                                <th>Last Heartbeat</th>
                                <th>Status</th>
                                <th>Birth Date</th>
                                <th>Successful Tasks</th>
                                <th>Failed Tasks</th>
                                <th>Working Time</th>
                                <th>Running Time</th>
                                <th>System Load</th>
                                <th>Worker Pools</th>
                                <th>Versions</th>
                                <th>Disabled</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($workers_sorted as $key => $val) {
                                // determine if worker is online or offline by looking at last heartbeat,
                                // if > 10 min since last heartbeat, consider worker offline
                                // worker is also offline if state is shutdown
                                $UTC = new DateTimeZone('UTC');
                                $dtNow = new DateTime(gmdate('Y-m-d\TH:i:s'), $UTC);
                                $dtToCompare = new DateTime($val['last_heartbeat'], $UTC);
                                $diff = $dtNow->diff($dtToCompare);
                                $diffMin = (($diff->days * 24 * 60) + ($diff->h * 60) + $diff->i);
                                if ($diffMin > 10) {
                                    $status = 'offline';
                                    if ($val['state'] !== 'shutdown') {
                                        $state = 'unknown';
                                    }
                                } elseif ($val['state'] === 'shutdown') {
                                    $status = 'offline';
                                    $state = 'shutdown';
                                } else {
                                    $status = 'online';
                                    $state = (isset($val['state'])) ? $val['state'] : 'unknown';
                                }
                                if (!empty($val['current_tasks'])) {
                                    $num_current_tasks = sizeof($val['current_tasks']);
                                    $current_tasks = $num_current_tasks . ' tasks, ids: ';
                                    $current_tasks .= '(';
                                    $current_tasks .= implode(", ", $val['current_tasks']);
                                    $current_tasks .= ')';
                                } else {
                                    $current_tasks = 'none';
                                }
                                if (!empty($val['worker_pools'])) {
                                    $worker_pools = implode(', ', $val['worker_pools']);
                                } else {
                                    $worker_pools = 'none';
                                }
                                if (!empty($val['diskover_ver']) && !empty($val['diskoverd_ver'])) {
                                    $version = 'diskover: v' . $val['diskover_ver'] . ', diskoverd: v' . $val['diskoverd_ver'];
                                } else {
                                    $version = 'unknown';
                                }
                            ?>
                                <tr>
                                    <td><i class="fas fa-laptop"></i> <?php echo $val['name'] ?></td>
                                    <td><?php echo $val['hostname'] ?></td>
                                    <td><?php echo $val['pid'] ?></td>
                                    <td><?php echo $val['user'] ?></td>
                                    <td><?php echo $state ?></td>
                                    <td><?php echo $current_tasks ?></td>
                                    <td><?php echo utcTimeToLocal($val['last_heartbeat']) ?></td>
                                    <td><?php echo ($status === 'online') ? '<i class="fas fa-circle" style="color:#59B370"></i> online' : '<i class="fas fa-circle" style="color:#F28B24"></i> offline' ?></td>
                                    <td><?php echo utcTimeToLocal($val['birth_date']) ?></td>
                                    <td><?php echo $val['successful_task_count'] ?></td>
                                    <td><?php echo $val['failed_task_count'] ?></td>
                                    <td><?php echo secondsToTime($val['total_working_time']) ?></td>
                                    <td><?php echo secondsToTime($val['total_running_time']) ?></td>
                                    <td><?php echo number_format($val['load_avg'], 2) ?></td>
                                    <td><?php echo $worker_pools ?></td>
                                    <td><?php echo $version ?></td>
                                    <td><?php echo ($val['disabled']) ? 'Yes' : 'No' ?></td>
                                    <td class="pull-right">
                                        <?php if ($val['disabled']) { ?>
                                        <a href="#" onclick="confirmWorker('enable', '<?php echo $val['name'] ?>')" class="btn btn-default btn-sm"><i class="fas fa-check-circle"></i> Enable</a>
                                        <?php } else { ?>
                                        <a href="#" onclick="confirmWorker('disable', '<?php echo $val['name'] ?>')" class="btn btn-default btn-sm"><i class="fas fa-ban"></i> Disable</a>
                                        <?php } ?>
                                        <a href="#" onclick="confirmWorker('remove', '<?php echo $val['name'] ?>')" class="btn btn-default btn-sm"><i class="fas fa-times-circle"></i> Remove</a>
                                    </td>
                                </tr>
                            <?php }
                            ?>
                        </tbody>
                    </table>
                    <p class="pull-right"><?php echo count($workers_sorted) . " workers found (last updated <script>document.write(new Date().toLocaleString());</script> <a href=\"tasks_workers.php\">update</a>)"; ?></p>
                </div>
            </div>

        <?php } ?>
    </div>

    <script language="javascript" src="../js/jquery.min.js"></script>
    <script language="javascript" src="../js/bootstrap.min.js"></script>
    <script language="javascript" src="../js/diskover.js"></script>
    <script language="javascript" src="../js/jquery.dataTables.min.js"></script>
    <script language="javascript" src="../js/dataTables.bootstrap.min.js"></script>
    <script language="javascript" src="../js/time-elapsed-dhms.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            // make data table
            $("#task-workers-table").DataTable({
                "stateSave": true,
                "lengthMenu": [10, 25, 50, 75, 100],
                "pageLength": 25,
                "columnDefs": [{
                        "type": "time-elapsed-dhms",
                        targets: [11, 12]
                    },
                    {
                        "orderable": false,
                        targets: [17]
                    }
                ]
            });
        });
    </script>

</body>

</html>