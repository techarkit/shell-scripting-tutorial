<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
example file action to copy files using rclone
*/


// override debug output in fileactions include file
//$fileactions_debug = FALSE;

include 'includes/fileactions.php';
include 'includes/fileactions_header.php';


// in this example we are copying all selected items on search results page
// you can set fileactions_debug to TRUE above for debug info to print out fileinfo array

// full path of rclone or rclone if in PATH
$rclone = "rclone";
// rclone flags
$flags = $_GET['flags'];
// rclone destination
$dest = $_GET['dest'];
// run in background, set to true or false
$background = true;


foreach ($fileinfo as $file) {
    $fullpath = $file['fullpath'];
    // uncomment below and set to translate paths
    //$path_translations = array(
    //    '/^\//' => '/mnt/'
    //);
    //$fullpath = translate_path($fullpath, $path_translations);

    // run command to copy fullpath to dest
    $cmd = $rclone . ' ' . $flags . ' "' . $fullpath . '" "' . $dest . '"';
    if ($background) {
        // log directory
        $logdir = './logs/';
        // log file name
        $logfile = $logdir . 'rclone_' . uniqid(rand(), true) . '.log';
        // background args
        $background_args = " > " . $logfile . " 2>&1 & echo \"rclone started (pid \$!)\"";
        $cmd = $cmd . " " . $background_args;
    }

    // run exec and get output and return value
    $output = $retval = null;
    exec($cmd, $output, $retval);

    // print html output
    // print log file every 1 sec
    echo '
    <div class="container-fluid cmd-output">
    Command: ' . $cmd . '<br>
    Status:<br>
    <pre>' . $retval .'</pre>
    Output:<br>
    <pre>' . implode("\n", $output) . '</pre>
    </div>
    <div class="container-fluid cmd-output" id="log-wrapper">
    Log output (updated every 1 sec):<br>
    <pre id="log" style="overflow-y:auto; height:400px; max-height:400px"></pre>
    </div>
    <script language="javascript" src="../js/jquery.min.js"></script>
    <script type="text/javascript">
    setInterval(function() {
        $(\'#log\').load(\'' . $logfile . '\');
        $(\'#log\').scrollTop($(\'#log\')[0].scrollHeight);
    }, 1000);
    </script>
    ';
}


include 'includes/fileactions_footer.php';