<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';

error_reporting(E_ALL ^ E_NOTICE);
require "../src/diskover/Auth.php";
require "../src/diskover/Diskover.php";


// smart searches text file
$file_smartsearches = 'smartsearches.txt';

// check if form has been submitted
if (isset($_POST['smartsearchtext'])) {
    // save the text contents
    $smartsearchtext = $_POST['smartsearchtext'];
    $smartsearch_arr = explode("\n", $smartsearchtext);
    // check smartsearch format
    $dataerror = false;
    foreach ($smartsearch_arr as $ss) {
        if ($ss !== "" && (strpos($ss, '|') === false || $ss[0] !== '!')) {
            $dataerror = true;
            break;
        }
    }
    if ($dataerror) {
        $formerrormsg = "Incorrect smart search format, use: !name|es query string";
    } else {
        // update file
        // check for newline at end
        if (substr($smartsearchtext, -1) != PHP_EOL) {
            // add newline
            $smartsearchtext .= PHP_EOL;
        }
        file_put_contents($file_smartsearches, $smartsearchtext);
        $formsuccessmsg = "Smart searches saved. You may now close the window or go to <a href=\"smartsearches.php\">smart searches</a>.";
    }
}

// read the textfile
$smartsearchtext = file_get_contents($file_smartsearches);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>diskover &mdash; Edit Smart Searches</title>
    <link rel="stylesheet" href="css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="css/diskover.css" media="screen" />
    <link rel="icon" type="image/png" href="images/diskoverfavico.png" />
</head>

<body>
    <div class="container" id="mainwindow" style="margin-top:70px;">
        <?php if (isset($_GET['error'])) { ?>
        <div class="row">
            <div class="col-xs-8">
                <div class="alert alert-dismissible alert-danger">
                    <i class="fas fa-exclamation-circle"></i> There is an error in one or more of you smart search ES query strings.<br>
                    <a href="#" onclick="$('#errormsg').show();">show error</a>
                </div>
                <div class="alert alert-dismissible alert-danger" id="errormsg" style="display:none">
                    <?php echo $_GET['error'] ?>
                </div>
            </div>
        </div>
        <?php } ?>
        <h1 class="page-header"><img src="images/diskoversmall.png" width="62" height="47" style="display:inline-block; position:relative; top:-5px"> <i class="glyphicon glyphicon-cog"></i> Edit Smart Searches</h1>
        <?php echo (!$adminuser) ? "<p><i class=\"fas fa-users-cog\"></i> <i><b>Admin user required</b></i></p>" : "" ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="form-group">
                    <span class="text-info">
                        <ul>
                            <li>Format: !name|es query string</li>
                            <li>Start smart search name with a ! (exclamation) character</li>
                            <li>Separate smartsearch name and es query with a | (pipe) character</li>
                            <li>Separate queries with new line</li>
                            <li>Use uppercase AND, OR, NOT</li>
                            <li>OR is used by default when searching multiple words</li>
                            <li>Case-sensitive when using field names (e.g. name) except for name.text and parent_path.text</li>
                            <li>To use wildcards use * or ? (e.g. parent_path:\/directory_name*)</li>
                            <li>More info on <a href="https://www.elastic.co/guide/en/elasticsearch/reference/7.17/query-dsl-query-string-query.html#query-string-syntax" target="_blank">Elasticsearch query string syntax</a></li>
                        </ul>
                    </span>
                    <form name="editsmartsearch" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="form-horizontal" autocorrect="off" spellcheck="false" autocapitalize="off">
                        <fieldset>
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <textarea class="form-control" rows="25" name="smartsearchtext" style="background-color:#1C1E21;color:darkgray;" <?php echo (!$adminuser) ? "disabled" : "" ?>><?php echo htmlspecialchars($smartsearchtext) ?></textarea>
                                    <?php if (isset($formerrormsg)) { ?>
                                        <span class="text-danger"><?php echo $formerrormsg ?></span>
                                    <?php } elseif (isset($formsuccessmsg)) { ?>
                                        <span class="text-success"><?php echo $formsuccessmsg ?></span>
                                    <?php } ?>
                                </div>
                                <div class="form-group">
                                    <button type="reset" class="btn btn-default" onclick="location.reload()" <?php echo (!$adminuser) ? "disabled" : "" ?>>Reset Changes</button>
                                    <button type="submit" class="btn btn-primary" <?php echo (!$adminuser) ? "disabled" : "" ?>>Save Smart Searches</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>

        <script language="javascript" src="js/jquery.min.js"></script>
        <script language="javascript" src="js/bootstrap.min.js"></script>
        <script language="javascript" src="js/diskover.js"></script>
</body>

</html>