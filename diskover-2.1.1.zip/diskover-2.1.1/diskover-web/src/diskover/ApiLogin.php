<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

// diskover-web api login handling

namespace diskover;

class ApiLogin
{
    public $user;

    public function checkApiLogin(): bool
    {
        // Check server login data.
        if (!$this->validateLogin()) {
            // Unsuccessful login.
            return false;
        }

        return true;
    }

    public function validateLogin(): bool
    {
        $username = $_SERVER['PHP_AUTH_USER'];
        $password = $_SERVER['PHP_AUTH_PW'];

        // Load database and find user.
        $db = new ApiUserDatabase();
        $db->connect();
        $user = $db->findUser($username);

        if (!$user->isValid) {
            return false;
        }

        if (!$user->validatePassword($password)) {
            return false;
        }

        // Valid user!
        $this->user = $user;
        return true;
    }
}
