<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../vendor/autoload.php';
require "../../src/diskover/Auth.php";
require "../../src/diskover/Diskover.php";
require "tasks_inc.php";


// read task templates json file
$templates_json = readTasksFile("templates.json");
$templates_arr = json_decode($templates_json, true);
$templates_sorted = $templates_arr['templates'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>diskover &mdash; Task Templates</title>
    <link rel="stylesheet" href="../css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="../css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="../css/diskover-tasks.css" media="screen" />
    <link rel="icon" type="image/png" href="../images/diskoverfavico.png" />
</head>

<body>
    <?php include "tasks_nav.php"; ?>

    <div class="container-fluid" id="mainwindow" style="margin-top:70px">
        <h1 class="page-header">Task Templates</h1>
        <?php if (empty($templates_sorted)) { ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="alert alert-dismissible alert-info">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <i class="glyphicon glyphicon-exclamation-sign"></i> No templates found.
                    </div>
                </div>
            </div>
        <?php } else { ?>
            <div class="row">
                <div class="col-lg-12">
                    <table class="table table-striped table-hover table-condensed">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Task Type</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($templates_sorted as $key => $val) {
                                $schedule = $val['run_min'] . " " . $val['run_hour'] . " " . $val['run_day_month'] .
                                    " " . $val['run_month'] . " " . $val['run_day_week'];
                            ?>
                                <tr>
                                    <td><?php echo $val['name'] ?></td>
                                    <td><?php echo $val['description'] ?></td>
                                    <td><?php echo $val['type'] ?></td>
                                    <td class="pull-right"><a href="#" onclick="confirmTemplate('<?php echo $val['id'] ?>')" class="btn btn-default btn-sm"><i class="fas fa-times-circle"></i> Remove</a></td>
                                </tr>
                            <?php }
                            ?>
                        </tbody>
                    </table>
                    <p class="pull-right"><?php echo count($templates_sorted) . " templates found (last updated <script>document.write(new Date().toLocaleString());</script> <a href=\"tasks_templates.php\">update</a>)"; ?></p>
                </div>
            </div>

        <?php } ?>
    </div>

    <script language="javascript" src="../js/jquery.min.js"></script>
    <script language="javascript" src="../js/bootstrap.min.js"></script>
    <script language="javascript" src="../js/diskover.js"></script>

</body>

</html>