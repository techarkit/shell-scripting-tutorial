<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

session_start();
use Elasticsearch\ClientBuilder;
use Elasticsearch\Common\Exceptions\Missing404Exception;
require 'version.php';
require 'config_inc.php';

error_reporting(E_ALL ^ E_NOTICE);

/* Start Globals */

$adminuser = $taskpaneluser = $esIndex = $esIndex2 = $indices = $path = $toppaths = $toppaths_index_map =
    $es_index_info = $all_index_info = $completed_indices = $latest_completed_indices =
    $latest_completed_index = $index_aliases = $fields = $indexinfo_updatetime = $index_starttimes =
    $index_costpergb = $index_spaceinfo = $es_responsetime = $showcostpergb = $filter = $time = $timefield = 
    $use_count = $show_files = $maxdepth = $sizefield = null;

// file type groups
$fileGroups_extensions = $config->FILE_TYPES;

// create ES client connection
$mnclient = new ESClient;
$mnclient->createClients();
$client = $mnclient->getClient();

// Set d3 vars
setd3Vars();

// Pages to not redirect to select indices
$selectindex_noredirect = array('selectindices.php', 'settings.php', 'help.php');

// get txt file data
if (strpos($_SERVER['REQUEST_URI'], 'd3_data') === false && 
    strpos($_SERVER['REQUEST_URI'], 'api.php') === false &&
    strpos($_SERVER['REQUEST_URI'], 'tagfiles.php') === false &&
    strpos($_SERVER['REQUEST_URI'], 'tagfiles_process.php') === false &&
    strpos($_SERVER['REQUEST_URI'], 'tasks/') === false && 
    strpos($_SERVER['REQUEST_URI'], 'fileactions/') === false) {
    // Grab all the custom tags from file
    $customtags = get_custom_tags();
    // Grab all the smart searches from file
    $smartsearches = get_smartsearches();
    // Tag color array
    $customtagscolors = array();
    // Get index mappings
    get_indexmappings();
}

/* End Globals */


// get/set index info
if (strpos($_SERVER['REQUEST_URI'], 'd3_data') === false && 
    strpos($_SERVER['REQUEST_URI'], 'api.php') === false &&
    strpos($_SERVER['REQUEST_URI'], 'tagfiles.php') === false &&
    strpos($_SERVER['REQUEST_URI'], 'tagfiles_process.php') === false) {
    userType();
    // don't get index info if task panel, search key press or file actions pages
    if (strpos($_SERVER['REQUEST_URI'], 'tasks/') === false &&
        strpos($_SERVER['REQUEST_URI'], 'searchkeypress.php') === false &&
        strpos($_SERVER['REQUEST_URI'], 'fileactions/') === false) {
        indexInfo();

        // hide share user data popup
        if ($GLOBALS['config']->HIDE_SHAREDATA) {
            createCookie('sendanondata', 0);
        }
    }
}


// ES Client
class ESClient
{
    public $clients;
    public $remote_cluster_aliases;

    function createClients()
    {
        // Sets clients property
        $clients = array();

        foreach ($GLOBALS['config']->ES_HOSTS as $eshost) {
            // Check if remote cluster set to offline and skip check
            if (array_key_exists('offline', $eshost) && $eshost['offline'] === true) {
                continue;
            }

            // Check connection to Elasticsearch using curl
            $res = curl_es($eshost, '/', null, false);

            // Create ES client connection to each node
            $hosts = array();
            foreach ($eshost['hosts'] as $esnode) {
                $host = [
                    'host' => $esnode, 'port' => $eshost['port'],
                    'user' => $eshost['user'], 'pass' => $eshost['pass']
                ];
                if ($eshost['https']) {
                    $host['scheme'] = 'https';
                }
                $hosts[] = $host;
            }
            if (!$GLOBALS['config']->ES_SSLVERIFICATION) {
                $client = ClientBuilder::create()->setHosts($hosts)->setSSLVerification(false)->build();
            } else {
                $client = ClientBuilder::create()->setHosts($hosts)->build();
            }
            $key = $hosts[0]['host'] . ":" . $hosts[0]['port'];
            $clients[$key] = $client;
            unset($hosts);
            if (array_key_exists('remote_cluster_alias', $eshost)) {
                $this->remote_cluster_aliases[$key] = $eshost['remote_cluster_alias'];
            }
        }
        $this->clients = $clients;
    }

    function getClient()
    {
        // Return first cluster client
        return $this->clients[$GLOBALS['config']->ES_HOSTS[0]['hosts'][0] . ":" . $GLOBALS['config']->ES_HOSTS[0]['port']];
    }

    function getClientByNode($esnode)
    {
        if ($client = $this->clients[$esnode]) {
            return $client;
        } else {
            handleError('Elasticsearch remote cluster is offline, please logout and log back in.');
        }
    }

    function getClientByIndex($index)
    {
        foreach ($this->getClients() as $client) {
            $exists = $client->indices()->exists(array('index' => $index));
            if ($exists) return $client;
        }
        return null;
    }

    function getIndexNode($index)
    {
        foreach ($_SESSION['cluster_indices'] as $esnode => $indices) {
            if (in_array($index, $indices)) {
                return $esnode;
            }
        }
        return null;
    }

    function getClients()
    {
        // Return es clients
        return $this->clients;
    }

    function getRemoteClusterAlias($esnode)
    {
        // Return remote cluster alias name or null if not found
        if (isset($this->remote_cluster_aliases) && array_key_exists($esnode, $this->remote_cluster_aliases)) {
            return $this->remote_cluster_aliases[$esnode];
        } else {
            return null;
        }
    }

    function addIndex($esnode, $index) {
        if (!isset($_SESSION['cluster_indices']) || empty($_SESSION['cluster_indices'][$esnode])) {
            $_SESSION['cluster_indices'][$esnode][] = $index;
        } elseif (!in_array($index, $_SESSION['cluster_indices'][$esnode])) {
            $_SESSION['cluster_indices'][$esnode][] = $index;
        }
    }

    function getSearchIndex($index) {
        // Return search index string for es search

        // check for multiple index names
        if (strpos($index, ',')) {
            $searchindices = array();
            $multiple_index = explode(',', $index);
            foreach ($multiple_index as $index) {
                // Return search index name
                foreach ($_SESSION['cluster_indices'] as $esnode => $indices) {
                    if (array_search($index, $indices) !== false) { 
                        break;
                    }
                }
                $remote_cluster_alias = $this->getRemoteClusterAlias($esnode);
                if (!is_null($remote_cluster_alias)) {
                    $searchindices[] = $remote_cluster_alias . ":" . $index;
                } else {
                    $searchindices[] = $index;
                }
            }
            $searchindex = implode(',', $searchindices);
        // single index name
        } else {
            // Return search index name
            foreach ($_SESSION['cluster_indices'] as $esnode => $indices) {
                if (array_search($index, $indices) !== false) { 
                    break;
                }
            }
            $remote_cluster_alias = $this->getRemoteClusterAlias($esnode);
            if (!is_null($remote_cluster_alias)) {
                $searchindex = $remote_cluster_alias . ":" . $index;
            } else {
                $searchindex = $index;
            }
        }
        return $searchindex;
    }

    function getIndexNoCluster($index)
    {   
        // Return index name wihtout any cluster alias name clusteralias:index
        if (strpos($index, ':')) {
            $index = explode(":", $index)[1];
        }
        return $index;
    }

    function getIndicesInfoCurl()
    {
        // Get index info using curl

        // fields to not display
        $field_exclusions = [
            'path',
            'total',
            'used',
            'free',
            'free_percent',
            'available',
            'available_percent',
            'start_at',
            'end_at',
            'crawl_time',
            'diskover_ver'
        ];
        
        $indices_curl_info_all = array();
        foreach ($GLOBALS['config']->ES_HOSTS as $eshost) {
            // Check if remote cluster set to offline and skip check
            if (array_key_exists('offline', $eshost) && $eshost['offline'] === true) {
                continue;
            }
            $indices_curl_info = curl_es($eshost, '/diskover-*?pretty');
            $indices_curl_info_data = array();
            // get the data we care about
            foreach ($indices_curl_info as $key => $val) {
                $fields = array();
                foreach ($val['mappings']['properties'] as $fieldname => $fieldtype) {
                    if (!in_array($fieldname, $field_exclusions)) {
                        $fields[] = $fieldname;
                    }
                    // check for multi-field add add additional sub-fields fieldname.subfield
                    if (array_key_exists('properties', $val['mappings']['properties'][$fieldname])) {
                        foreach ($val['mappings']['properties'][$fieldname]['properties'] as $k => $v) {
                            $field = $fieldname . '.' . $k;
                            if (!in_array($field, $field_exclusions)) {
                                $fields[] = $field;
                            }
                        }
                    }
                }
                $indices_curl_info_data[$key] = [
                    'uuid' => $val['settings']['index']['uuid'],
                    'aliases' => $val['aliases'],
                    'creation_date' => $val['settings']['index']['creation_date'],
                    'fields' => $fields
                ];
            }
            $key = $eshost['hosts'][0] . ":" . $eshost['port'];
            $indices_curl_info_all[$key] = $indices_curl_info_data;
        }
        return $indices_curl_info_all;
    }

    function getIndicesInfoCat()
    {
        // Get index info using ES cat indices
        $indices_cat_info_all = array();
        $indices_cat_info_limited = array();

        // Set maxindex
        $maxindex = getCookie('maxindex');
        if ($maxindex == '' || $maxindex < $GLOBALS['config']->MAX_INDEX) {
            $maxindex = $GLOBALS['config']->MAX_INDEX;
            createCookie('maxindex', $maxindex);
        }

        // Get all diskover indices from ES using cat and sort by creation date
        foreach ($this->getClients() as $esnode => $client) {
            $indexcount = 0;
            $params = array(
                'index' => 'diskover-*',
                's' => 'creation.date'
            );
            $indices_cat_info = $client->cat()->indices($params);
            // reverse the array since cat indices has the newest at the end
            $indices_cat_info = array_reverse($indices_cat_info);
            if ($indices_cat_info) {
                $_SESSION['total_indices'] = sizeof($indices_cat_info);
                foreach ($indices_cat_info as $i) {
                    $indices_cat_info_all[$esnode][$i['index']] = [
                        'pri_shards' => $i['pri'],
                        'rep_shards' => $i['rep'],
                        'docs_count' => $i['docs.count'],
                        'store_size' => $i['store.size'],
                        'pri_store_size' => $i['pri.store.size']
                    ];
                    $this->addIndex($esnode, $i['index']);
                    if ($indexcount < $maxindex) {
                        $indices_cat_info_limited[$esnode][$i['index']] = [
                            'pri_shards' => $i['pri'],
                            'rep_shards' => $i['rep'],
                            'docs_count' => $i['docs.count'],
                            'store_size' => $i['store.size'],
                            'pri_store_size' => $i['pri.store.size']
                        ];
                        $indexcount++;
                    }
                }
            } else {
                $indices_cat_info_all[$esnode] = array();
            }
             // Add any aliases to cluster_indices session var
            $aliases = $client->indices()->getAliases();
            foreach ($aliases as $index => $alias_mapping) {
                foreach ($alias_mapping['aliases'] as $aliasname => $indexarr) {
                    $this->addIndex($esnode, $aliasname);
                }
            }
        }

        // Check if use latest index enabled is set
        if (!$GLOBALS['config']->LATEST_INDEX_ENABLED || 
        (isset($_COOKIE['uselatestindices']) && $_COOKIE['uselatestindices'] == 0)) {
            return $indices_cat_info_limited;
        } else {
            $indices_cat_info_all_unique = array();
            $index_unique = array();
            // Find all similiar index names and use the most recent index
            foreach ($indices_cat_info_all as $esnode => $indices) {
                foreach ($indices as $index => $indexinfo) {
                    // remove diskover-
                    $index_rep = str_replace('diskover-', '', $index);
                    // remove any date or datetime stamps
                    $patterns = array(
                        '/[\.\-_]\d{4}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}$/',
                        '/[\.\-_]\d{4}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}$/',
                        '/[\.\-_]\d{4}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}$/',
                        '/[\.\-_]\d{2}[\.\-_]?\d{2}[\.\-_]?\d{4}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}$/',
                        '/[\.\-_]\d{2}[\.\-_]?\d{2}[\.\-_]?\d{4}[\.\-_]?\d{2}[\.\-_]?\d{2}$/',
                        '/[\.\-_]\d{2}[\.\-_]?\d{2}[\.\-_]?\d{4}[\.\-_]?\d{2}$/',
                        '/[\.\-_]\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}$/',
                        '/[\.\-_]\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}$/',
                        '/[\.\-_]\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}[\.\-_]?\d{2}$/',
                    );
                    $index_rep = preg_replace($patterns, '', $index_rep);
                    $counts = array_count_values($index_unique);
                    if ($counts[$index_rep] < 2) {
                        $index_unique[] = $index_rep;
                        $indices_cat_info_all_unique[$esnode][$index] = $indexinfo;
                    }
                }
            }
            return $indices_cat_info_all_unique;
        }
    }

    function refreshIndices()
    {
        // Refresh diskover indices
        foreach ($this->getClients() as $client) {
            $client->indices()->refresh(array('index' => 'diskover-*'));
        }
    }

    function getIndexInfo()
    {
        // get index info from ES
        // only get new index info every NEWINDEX_CHECKTIME or reloadindices set
        if (isset($_GET['reloadindices']) || isset($_POST['reloadindices']) || 
        !isset($_SESSION['es_index_info_time']) || 
        time() - $_SESSION['es_index_info_time'] > $GLOBALS['config']->NEWINDEX_CHECKTIME) {
            $this->refreshIndices();
            $indices_info_curl = $this->getIndicesInfoCurl();
            $indices_info_cat = $this->getIndicesInfoCat();
            $es_index_info = array();
            foreach ($indices_info_cat as $esnode => $indices) {
                foreach ($indices as $index => $val) {
                    $val2 = $indices_info_curl[$esnode][$index];
                    $es_index_info[$esnode][$index] = $val + $val2;
                }
            }
            $_SESSION['es_index_info'] = $es_index_info;
            $_SESSION['es_index_info_time'] = time();
        } else {
            $es_index_info = $_SESSION['es_index_info'];
        }
        return $es_index_info;
    }

    function getTotalIndices()
    {
        // Return total number of indices
        return $_SESSION['total_indices'];
    }
}


function indexInfo()
{
    global $mnclient, $client, $esIndex, $esIndex2, $es_index_info, $indices, $all_index_info, 
        $completed_indices, $latest_completed_indices, $latest_completed_index, $index_aliases, $fields, 
        $indexinfo_updatetime, $index_starttimes, $index_costpergb, $index_spaceinfo, $selectindex_noredirect;

    $es_index_info = $mnclient->getIndexInfo();
    
    // Set latest index info if force reload or set index session info time expired
    if (isset($_GET['reloadindices']) || isset($_POST['reloadindices']) || !isset($_SESSION['indexinfo']) ||
        (isset($_SESSION['indexinfo']) && microtime(true) - $_SESSION['indexinfo']['update_time_ms'] > $GLOBALS['config']->INDEXINFO_CACHETIME)) {

        $disabled_indices = array();
        $completed_indices = array();
        $latest_completed_index = null;
        $latest_completed_indices = array();
        $index_toppaths = array();
        $index_starttimes = array();
        $index_costpergb = array();
        $all_index_info = array();
        $index_aliases = array();
        $fields = array();
        $index_spaceinfo = array();

        if (!isset($_SESSION['indices_uuids'])) {
            $_SESSION['indices_uuids'] = array();
        }
    
        if (!isset($_SESSION['indices_doccount'])) {
            $_SESSION['indices_doccount'] = array();
        }
    
        if (!isset($_SESSION['indices_aliases'])) {
            $_SESSION['indices_aliases'] = array();
        }

        foreach ($es_index_info as $esnode => $esindices) {
            foreach ($esindices as $key => $val) {
                // index uuid
                $uuid = $val['uuid'];

                // filter indices based on user/group index mappings
                if ($GLOBALS['config']->INDEX_MAPPINGS_ENABLED) {
                    if (!filterIndex($esnode, $key, $uuid)) continue;
                }
 
                // skip index which we already have index uuid and doc count has not changed and aliases have not changed
                if (!isset($_POST['reloadindices']) &&
                    array_key_exists($uuid, $_SESSION['indices_uuids']) &&
                    $_SESSION['indices_doccount'][$key] == $val['docs_count'] &&
                    $_SESSION['indices_aliases'][$key] == $val['aliases']) {
                    continue;
                } else {
                    $_SESSION['indices_uuids'][$uuid] = ['index'=>$key, 'esnode'=>$esnode];
                    $_SESSION['indices_doccount'][$key] = $val['docs_count'];
                    $_SESSION['indices_aliases'][$key] = $val['aliases'];
                    unset($_SESSION['toppaths']);
                    unset($_SESSION['toppaths_index_map']);
                }

                $searchindex = $mnclient->getSearchIndex($key);
                $searchParams['index'] = $searchindex;
                $searchParams['body'] = [
                    'size' => 100,
                    'query' => [
                        'match' => ['type' => 'indexinfo']

                    ],
                    'sort' => ['start_at' => 'asc']
                ];

                // catch any errors searching doc in indices which might be corrupt or deleted
                try {
                    $queryResponse = $client->search($searchParams);
                } catch (Exception $e) {
                    handleError('ES error (index not found/ index error): ' . $e->getMessage(), false, false, false);
                    removeIndex($esnode, $key, $uuid);
                    continue;
                }

                // if no indexinfo docs, remove it from indices array
                if (sizeof($queryResponse['hits']['hits']) == 0) {
                    removeIndex($esnode, $key, $uuid);
                    continue;
                }

                $startcount = 0;
                $endcount = 0;
                foreach ($queryResponse['hits']['hits'] as $hit) {
                    $source = $hit['_source'];
                    // add to index_starttimes list
                    if (array_key_exists('start_at', $source)) {
                        $index_starttimes[$key][$source['path']] = $source['start_at'];
                        $startcount += 1;
                    }
                    if (array_key_exists('end_at', $source)) {
                        $endcount += 1;
                    }
                    // add to index_toppaths list
                    if (array_key_exists($key, $index_toppaths) && !in_array($source['path'], $index_toppaths[$key])) {
                        $index_toppaths[$key][] = $source['path'];
                    } else {
                        $index_toppaths[$key] = array($source['path']);
                    }
                    // add to all_index_info list
                    $all_index_info[$key][$source['path']] = [
                        'start_at' => array_key_exists('start_at', $source) ? $source['start_at'] : $all_index_info[$key][$source['path']]['start_at'],
                        'end_at' => $source['end_at'],
                        'crawl_time' => $source['crawl_time'],
                        'file_count' => $source['file_count'],
                        'dir_count' => $source['dir_count'],
                        'file_size' => $source['file_size']
                    ];
                    $all_index_info[$key]['totals'] = [
                        'filecount' => $all_index_info[$key]['totals']['filecount'] + $source['file_count'],
                        'filesize' => $all_index_info[$key]['totals']['filesize'] + $source['file_size'],
                        'dircount' => $all_index_info[$key]['totals']['dircount'] + $source['dir_count'],
                        'crawltime' => $all_index_info[$key]['totals']['crawltime'] + $source['crawl_time']
                    ];
                    $all_index_info[$key]['latest_start_at'] = array_key_exists('start_at', $source) ? $source['start_at'] : $all_index_info[$key]['latest_start_at'];
                }

                // add to disabled_indices list if still being indexed (end_at docs less than start_at docs)
                if ($endcount < $startcount) {
                    $disabled_indices[] = $key;
                }

                // Get size of index
                // convert to bytes
                $indexsize = $val['store_size'];
                if (strpos($indexsize, 'gb')) {
                    $indexsize = str_replace('gb', '', $indexsize);
                    $indexsize = $indexsize * 1024 * 1024 * 1024;
                } elseif (strpos($indexsize, 'mb')) {
                    $indexsize = str_replace('mb', '', $indexsize);
                    $indexsize = $indexsize * 1024 * 1024;
                } elseif (strpos($indexsize, 'kb')) {
                    $indexsize = str_replace('kb', '', $indexsize);
                    $indexsize = $indexsize * 1024;
                } else {
                    $indexsize = str_replace('b', '', $indexsize);
                }
                $all_index_info[$key]['totals']['indexsize'] = $indexsize;

                // Check for cost data in the index and if there is cost data add to index_costpergb list
                $searchParams = [];
                $searchParams['index'] = $searchindex;
                $searchParams['body'] = [
                    'query' => [
                        'query_string' => [
                            'query' => 'costpergb:>0'
                        ]
                    ]
                ];

                try {
                    $queryResponse = $client->search($searchParams);
                } catch (Missing404Exception $e) {
                    deleteCookie('index');
                    deleteCookie('index2');
                    clearPaths();
                    handleError("Selected indices are no longer available. Please select a different index.");
                } catch (Exception $e) {
                    handleError('ES error: ' . $e->getMessage(), true);
                }

                if (sizeof($queryResponse['hits']['hits']) > 0) {
                    $index_costpergb[] = $key;
                }

                // get disk space for each index
                $searchParams['body'] = [
                    'size' => 100,
                    'query' => [
                        'match' => [
                            'type' => 'spaceinfo'
                        ]
                    ]
                ];

                try {
                    $queryResponse = $client->search($searchParams);
                } catch (Missing404Exception $e) {
                    deleteCookie('index');
                    deleteCookie('index2');
                    clearPaths();
                    handleError("Selected indices are no longer available. Please select a different index.");
                } catch (Exception $e) {
                    handleError('ES error: ' . $e->getMessage(), true);
                }

                foreach ($queryResponse['hits']['hits'] as $hit) {
                    $index_spaceinfo[$key][$hit['_source']['path']] = $hit['_source'];
                }

                // check if index is in any alias and add to index_aliases array
                if (!empty($val['aliases'])) {
                    if (is_null($index_aliases)) {
                        $index_aliases = array();
                    }
                    foreach ($val['aliases'] as $k => $v) {
                        if (!array_key_exists($key, $index_aliases)) {
                            $index_aliases[$key] = array($k);
                        } else {
                            $index_aliases[$key][] = $k;
                        }
                    }
                }

                // add all fields from index mappings to fields array
                foreach ($val['fields'] as $field) {
                    if (!in_array($field, $fields)) {
                        $fields[] = $field;
                    }
                }
            }
        }

        // get all latest completed indices based on index's top paths
        foreach ($all_index_info as $key => $val) {
            if (!in_array($key, $disabled_indices)) {
                if (!is_null($index_aliases)) {
                    if (array_key_exists($key, $index_aliases)) {
                        continue;
                    }
                }
                if (is_null($latest_completed_index)) {
                    $latest_completed_index = $key;
                }
                $completed_indices[] = $key;

                // get all top paths in index and store in latest_completed_indices
                foreach($index_toppaths[$key] as $index_toppath) {
                    if (empty($latest_completed_indices[$index_toppath])) {
                        $latest_completed_indices[$index_toppath] = $key;
                    }
                }
            }
        }

        // add any addtional fields which are not found in mappings
        if (!isset($_SESSION['indexinfo']['fields'])) {
            $fields[] = 'name.text';
            $fields[] = 'parent_path.text';
        }
        // sort fields
        asort($fields);

        // add alias to completed_indices if index not disabled
        if (!is_null($index_aliases)) {
            foreach ($index_aliases as $key => $val) {
                if (!in_array($key, $disabled_indices)) {
                    foreach ($val as $v) {
                        $completed_indices[] = $v;
                    }
                }
            }
        }

        // merge existing session index info with new index info
        if (isset($_SESSION['indexinfo'])) {
            $all_index_info = array_merge($_SESSION['indexinfo']['all_index_info'], $all_index_info);
            $completed_indices = array_merge($_SESSION['indexinfo']['completed_indices'], $completed_indices);
            $latest_completed_indices = array_merge($_SESSION['indexinfo']['latest_completed_indices'], $latest_completed_indices);
            $latest_completed_index = (!is_null($latest_completed_index)) ? $latest_completed_index : $_SESSION['indexinfo']['latest_completed_index'];
            $fields = array_merge($_SESSION['indexinfo']['fields'], $fields);
            // remove any duplicate fields
            $fields = array_unique($fields);
            $index_aliases = (!is_null($index_aliases)) ? $index_aliases : $_SESSION['indexinfo']['index_aliases'];
            $index_starttimes = array_merge($_SESSION['indexinfo']['starttimes'], $index_starttimes);
            $index_costpergb = array_merge($_SESSION['indexinfo']['costpergb'], $index_costpergb);
            $index_spaceinfo = array_merge($_SESSION['indexinfo']['spaceinfo'], $index_spaceinfo);
        }

        $_SESSION['indexinfo'] = array(
            'update_time_ms' => microtime(true),
            'all_index_info' => $all_index_info,
            'completed_indices' => $completed_indices,
            'latest_completed_indices' => $latest_completed_indices,
            'latest_completed_index' => $latest_completed_index,
            'index_aliases' => $index_aliases,
            'fields' => $fields,
            'starttimes' => $index_starttimes,
            'costpergb' => $index_costpergb,
            'spaceinfo' => $index_spaceinfo
        );
        $indexinfo_updatetime = $_SESSION['indexinfo']['update_time'] = new DateTime("now", new DateTimeZone($GLOBALS['config']->TIMEZONE));
    } else {
        $all_index_info = $_SESSION['indexinfo']['all_index_info'];
        $completed_indices = $_SESSION['indexinfo']['completed_indices'];
        $latest_completed_indices = $_SESSION['indexinfo']['latest_completed_indices'];
        $latest_completed_index = $_SESSION['indexinfo']['latest_completed_index'];
        $index_aliases = $_SESSION['indexinfo']['index_aliases'];
        $fields = $_SESSION['indexinfo']['fields'];
        $index_starttimes = $_SESSION['indexinfo']['starttimes'];
        $index_costpergb = $_SESSION['indexinfo']['costpergb'];
        $indexinfo_updatetime = $_SESSION['indexinfo']['update_time'];
        $index_spaceinfo = $_SESSION['indexinfo']['spaceinfo'];
    }

    // load the latest indices
    if ($GLOBALS['config']->LATEST_INDEX_ENABLED &&
        (getCookie('uselatestindices') == "" || getCookie('uselatestindices') == 1)
    ) {

        // set latest indices cookie
        if (getCookie('uselatestindices') == "") {
            createCookie('uselatestindices', 1);
        }

        $esIndex = "";
        $x = 0;
        foreach ($latest_completed_indices as $latest_index) {
            if (strpos($esIndex, $latest_index) === false) {
                $esIndex .= $latest_index;
                if ($x < count($latest_completed_indices) - 1) $esIndex .= ",";
            }
            $x++;
        }

        // check if indices changed and delete path cookies/session vars and reload the page
        $esIndex_cookie = getCookie('index');

        if ($esIndex_cookie != "" && $esIndex_cookie != $esIndex) {
            deleteCookie('index');
            deleteCookie('index2');
            clearPaths();
            // set usecache to false (flush chart/file tree cache)
            createCookie('usecache', 0);
            $query = $_GET;
            $query['index'] = $esIndex;
            $query_result = http_build_query($query);
            $url = $_SERVER['PHP_SELF'] . "?" . $query_result;
            // reload page
            header("location:" . $url);
            exit();
        }

        createCookie('index', $esIndex);
        $indices = explode(',', $esIndex);

    } else {
        $esIndex_cookie = getCookie('index');
        $esIndex2_cookie = getCookie('index2');

        // check for index2 in url
        if (isset($_GET['index2']) && $_GET['index2'] != "") {
            $esIndex2 = $_GET['index2'];
            createCookie('index2', $esIndex2);
        } else {
            $esIndex2 = getCookie('index2');
        }
        
        // check for index in url
        if (isset($_GET['index']) && $_GET['index'] != "") {
            $esIndex = $_GET['index'];
            createCookie('index', $esIndex);
        } else {
            $esIndex = $esIndex_cookie;
            // redirect to select indices page if esIndex is empty
            if (empty($esIndex) && !in_array(basename($_SERVER['PHP_SELF']), $selectindex_noredirect)) {
                header("location:selectindices.php?noindex");
                exit();
            }
        }

        // check if user changed index in url params and delete path cookies/session vars and reload the page
        if ((($esIndex_cookie != "" && $esIndex_cookie != $esIndex) || ($esIndex2_cookie != "" && $esIndex2_cookie != $esIndex2)) &&
            !in_array(basename($_SERVER['PHP_SELF']), $selectindex_noredirect)) {
            deleteCookie('index');
            deleteCookie('index2');
            clearPaths();
            // set usecache to false (flush chart/file tree cache)
            createCookie('usecache', 0);
            $query = $_GET;
            $query['index'] = $esIndex;
            $query['q'] = "";
            $query['path'] = "";
            $query_result = http_build_query($query);
            $url = $_SERVER['PHP_SELF'] . "?" . $query_result;
            // reload page
            header("location:" . $url);
            exit();
        }

        $indices = explode(',', $esIndex);

        notifyNewIndex();
    }
    
    checkIndices();

    setPaths();
    
    showCost();

    // set search results table hidden fields using default hidden fields from config
    if (count($GLOBALS['config']->HIDE_FIELDS) > 0) {
        foreach ($GLOBALS['config']->HIDE_FIELDS as $f) {
            $hf = 'hidefield_' . $f;
            if (getCookie($hf) == "") {
                createCookie($hf, 1);
            }
        }
    }

    // set local timezone using local time setting from config
    if ($GLOBALS['config']->LOCAL_TIMES && getCookie('localtime') == "") {
        createCookie('localtime', 1);
    }
}


// handle errors
function handleError($e, $redirect = true, $ajax = false, $throwexception = false) {
    // Log error
    error_log(" Error: " . $e . " ");
    if ($ajax) {
        header('HTTP/1.1 500 Internal Server Error');
        header('Content-Type: application/json; charset=UTF-8');
        die(json_encode(array('message' => 'Error: ' . $e)));
    }
    if ($redirect) {
        // set error cookie to expire 1 hour
        setCookie('error', $e, time()+3600);
        // redirect to error page
        if (strpos($_SERVER['REQUEST_URI'], 'tasks/') !== false) {
            header('Location: ../error.php');
        } else {
            header('Location: error.php');
        }
        exit();   
    }
    if ($throwexception) {
        // throw exception
        throw new Exception($e);
    }
}


// Set user type
function userType()
{
    global $adminuser, $taskpaneluser;

    if ($GLOBALS['config']->LOGIN_REQUIRED) {
        // check admin user is logged in
        if (in_array($_SESSION['username'], $GLOBALS['config']->ADMIN_USERS)) {
            $adminuser = TRUE;
        } elseif ($_SESSION['ldaplogin'] && $_SESSION['ldapadmin']) {
            $adminuser = TRUE;
        } elseif ($_SESSION['oktalogin'] && $_SESSION['oktaadmin']) {
            $adminuser = TRUE;
        } else {
            $adminuser = FALSE;
        }
        // check if allowed access to task panel
        if (in_array($_SESSION['username'], $GLOBALS['config']->TASK_PANEL_USERS)) {
            $taskpaneluser = TRUE;
        } elseif ($_SESSION['ldaplogin'] && $_SESSION['ldaptaskpanel']) {
            $taskpaneluser = TRUE;
        } elseif ($_SESSION['oktalogin'] && $_SESSION['oktataskpanel']) {
            $taskpaneluser = TRUE;
        } else {
            $taskpaneluser = FALSE;
        }
    }
}


// set analytics vars
function setd3Vars() {
    global $filter, $time, $timefield, $use_count, $show_files, $maxdepth, $sizefield;

    $filter = (isset($_GET['filter'])) ? (int) $_GET['filter'] : getCookie('filter'); // filesize filter
    if ($filter === "") {
        $filter = $GLOBALS['config']->FILTER;
        createCookie('filter', $filter);
    }
    $time = (isset($_GET['time'])) ? (string) $_GET['time'] : getCookie('time'); // time field filter
    if ($time === "") {
        $time = $GLOBALS['config']->TIME;
        createCookie('time', $time);
    }
    $timefield = getCookie('timefield'); // time field to use
    if ($timefield === "") {
        $timefield = $GLOBALS['config']->TIME_FIELD;
        createCookie('timefield', $timefield);
    }
    // get use_count
    $use_count = (isset($_GET['use_count'])) ? (int) $_GET['use_count'] : getCookie('use_count'); // use count
    if ($use_count === "") {
        $use_count = $GLOBALS['config']->USE_COUNT;
        createCookie('use_count', $use_count);
    }
    // get show_files
    $show_files = (isset($_GET['show_files'])) ? (int) $_GET['show_files'] : getCookie('show_files'); // show files
    if ($show_files === "") {
        $show_files = $GLOBALS['config']->SHOW_FILES;
        createCookie('show_files', $show_files);
    }
    $maxdepth = (isset($_GET['maxdepth'])) ? (int) $_GET['maxdepth'] : getCookie('maxdepth'); // maxdepth
    if ($maxdepth === "") {
        $maxdepth = $GLOBALS['config']->MAXDEPTH;
        createCookie('maxdepth', $maxdepth);
    }
    // don't check if same as size_field in config, setting to override this on settings page
    $sizefield = getCookie('sizefield'); // size field to use
    if ($sizefield === "") {
        $sizefield = $GLOBALS['config']->SIZE_FIELD;
        createCookie('sizefield', $sizefield);
    }
}


// Set show cost per gb for the selected indices
function showCost()
{
    global $showcostpergb, $index_costpergb, $indices;

    foreach ($indices as $i) {
        if (in_array($i, $index_costpergb)) {
            if ($_SESSION['license']['product_code'] !== 'ESS') {
                $showcostpergb = TRUE;
            } else {
                $showcostpergb = FALSE;
            }
            break;
        } else {
            $showcostpergb = FALSE;
        }
    }
}


// Sets imporant path and path related variables
function setPaths()
{
    global $indices, $path, $toppaths, $toppaths_index_map, $index_aliases;

    $path = (isset($_GET['path'])) ? $_GET['path'] : getCookie('path');

    // check if no path grab from session and then if still can't find grab from ES
    if (empty($path)) {
        $path = $_SESSION['rootpath'];
        if (empty($path)) {
            // grab path from es
            $path = get_es_path($indices[0], 1);
            $_SESSION['rootpath'] = $path;
            createCookie('rootpath', $path);
            createCookie('parentpath', getParentDir($path));
        }
    }
    // remove any trailing slash (unless root)
    if ($path !== "/") {
        $path = rtrim($path, '/');
    }

    $toppaths = $_SESSION['toppaths'];
    $toppaths_index_map = $_SESSION['toppaths_index_map'];
    if (empty($toppaths) || empty($toppaths_index_map)) {
        $toppaths = array();
        $toppaths_index_map = array();
        // if using any aliases, add index names in alias to indices
        if (!is_null($index_aliases)) {
            $indices_org = $indices;
            $indices_in_array = array();
            foreach ($indices as $index) {
                // check if index is an alias and get all the real index names
                foreach ($_SESSION['indices_aliases'] as $key => $val) {
                    if (array_key_exists($index, $val)) {
                        $indices_in_array[] = $key;
                    }
                }
            }
            if (!empty($indices_in_array)) {
                $indices = $indices_in_array;
            }
        }
        // grab path(s) from es
        foreach ($indices as $index) {
            $p = get_es_path($index, 100);
            if (is_array($p)) {
                foreach ($p as $q) {
                    // remove any trailing slash (unless root)
                    if ($q !== "/") {
                        $q = rtrim($q, '/');
                    }
                    if (!in_array($q, $toppaths)) {
                        $toppaths[] = $q;
                        $toppaths_index_map[$q] = $index;
                    }
                }
            } else {
                if ($p !== "/") {
                    $p = rtrim($p, '/');
                }
                if (!in_array($p, $toppaths)) {
                    $toppaths[] = $p;
                    $toppaths_index_map[$p] = $index;
                }
            }
        }
        // sort toppaths in "natural order"
        usort($toppaths, 'toppaths_name_sort');
        // set top paths session var
        $_SESSION['toppaths'] = $toppaths;
        // set top paths index map session var
        $_SESSION['toppaths_index_map'] = $toppaths_index_map;
        // set indices back to original indices
        if (!is_null($index_aliases) && !empty($indices_in_array)) {
            $indices = $indices_org;
        }
    }
    
    setRootPath($path);
}

// finds and sets root path session/cookies from path
function setRootPath($p) {
    global $path;
    
    $rootpath = getRootPath($p);
    if (!is_null($rootpath)) {
        $_SESSION['rootpath'] = $rootpath;
        createCookie('rootpath', $rootpath);
        createCookie('path', $p);
        createCookie('parentpath', getParentDir($p));
        $path = $p;
    }
}


function getRootPath($p)
{
    if (in_array($p, $_SESSION['toppaths'])) {
        return $p;
    }
    $p = dirname($p);
    if ($p == '/') return $p;
    if ($p != '' && $p != '.') {
        return getRootPath($p);
    }
    return null;
}


// remove index from globals and session vars
function removeIndex($esnode = null, $index, $uuid = null)
{
    global $mnclient, $indices, $all_index_info, $completed_indices, $latest_completed_indices;

    if (is_null($esnode)) {
        $esnode = $mnclient->getIndexNode($index);
    }
    if (is_null($uuid)) {
        $uuid = array_search($index, $_SESSION['indices_uuids']);
    }
    unset($_SESSION['indices_uuids'][$uuid]);
    unset($_SESSION['indices_doccount'][$index]);
    unset($_SESSION['indices_aliases'][$index]);
    unset($_SESSION['indexinfo']['all_index_info'][$index]);
    if ($k = array_search($index, $_SESSION['indexinfo']['completed_indices'])) {
        unset($_SESSION['indexinfo']['completed_indices'][$k]);
    }
    if ($k = array_search($index, $_SESSION['indexinfo']['latest_completed_indices'])) {
        unset($_SESSION['indexinfo']['latest_completed_indices'][$k]);
    }
    if ($k = array_search($index, $_SESSION['indexinfo']['costpergb'])) {
        unset($_SESSION['indexinfo']['costpergb'][$k]);
    }
    if ($k = array_search($index, $completed_indices)) {
        unset($completed_indices[$k]);
    }
    if ($k = array_search($index, $latest_completed_indices)) {
        unset($latest_completed_indices[$k]);
    }
    if (!is_null($indices) && $k = array_search($index, $indices)) {
        unset($indices[$k]);
    }
    if ($k = array_search($index, $all_index_info)) {
        unset($all_index_info[$k]);
    }
}


// check if selected indices still exist and haven't been re-indexed
// re-indexed will have a new uuid number
function checkIndices()
{
    global $mnclient, $indices, $completed_indices, $es_index_info;

    $indices_missing = $indices_changed = false;

    foreach ($_SESSION['indices_uuids'] as $uuid => $value) {
        $index = $value['index'];
        $esnode = $value['esnode'];
        if (in_array($index, $indices) !== false) {
            // check exists still
            $client = $mnclient->getClientByNode($esnode);
            try {
                $exists = $client->indices()->exists(array('index' => $index));
            } catch (Exception $e) {
                handleError('ES error: ' . $e->getMessage(), false, false, false);
            }
            if (!$exists) {
                removeIndex($esnode, $index, $uuid);
                handleError('Index ' . $index . ' does not exist', false, false, false);
                $indices_missing = true;
            }
            // check uuid hasn't changed (from re-index)
            elseif (isset($es_index_info[$esnode][$index]) && $uuid !== $es_index_info[$esnode][$index]['uuid']) {
                removeIndex($esnode, $index, $uuid);
                handleError('Index ' . $index . ' uuid changed', false, false, false);
                $indices_changed = true;
            }
        }
    }

    // remove inddex info from session if there are no completed indices and display error to user
    if (empty($completed_indices)) {
        unset($_SESSION['indexinfo']);
        unset($_SESSION['indices_uuids']);
        unset($_SESSION['indices_doccount']);
        unset($_SESSION['indices_aliases']);
        if ($GLOBALS['config']->INDEX_MAPPINGS_ENABLED) {
            $errmsg = "No completed indices found in Elasticsearch or indexing mappings are enabled and all indices are not visible.";
        } else {
            $errmsg = "No completed indices found in Elasticsearch. Manually run a crawl and after it finishes reload index page. You can also set up a new index task in Task Panel.";
        }
        handleError($errmsg);
    }

    // if any indices missing or changed, display error to user
    if ($indices_missing || $indices_changed) {
        deleteCookie('index');
        deleteCookie('index2');
        clearPaths();
        showCost();
        createCookie('usecache', 0);
        if (getCookie('uselatestindices') == 1) {
            header('Location: ' . $_SERVER['REQUEST_URI'] . '&reloadindices');
        } else {
            if ($indices_missing) {
                $errmsg = "Selected indices are no longer available. Please select a different index.";
            } else {
                $errmsg = "Selected indices have changed. Please select a different index.";
            }
            handleError($errmsg);
        }
    }
}


// renove path cookies and session vars
function clearPaths() {
    deleteCookie('path');
    deleteCookie('parentpath');
    if (getCookie('uselatestindices') != 1) {
        deleteCookie('rootpath');
        unset($_SESSION['rootpath']);
    }
    unset($_SESSION['toppaths']);
    unset($_SESSION['toppaths_index_map']);
}


// Notify if there is a new index
function notifyNewIndex()
{
    global $latest_completed_index;

    // check if we should notify that there is a newer index
    if ((getCookie('uselatestindices') == "" || getCookie('uselatestindices') == 0) &&
        getCookie('notifynewindex') == 1 && in_array($latest_completed_index, explode(',', getCookie('index'))) === false
    ) {
        if (getCookie('newindexnotification_hide') !== $latest_completed_index) {
            createCookie('newindexnotification', 1);
        } else {
            createCookie('newindexnotification', 0);
        }
    } else {
        createCookie('newindexnotification', 0);
    }
}


// filters indices
function filterIndex($esnode, $index, $uuid)
{
    $match = FALSE;
    foreach ($_SESSION['index_mappings'] as $user_group => $index_arr) {
        if ($_SESSION['ldaplogin']) {
            if ($_SESSION['username'] === $user_group) {
                foreach ($index_arr as $i => $v) {
                    foreach ($v['index_patterns'] as $index_pattern) {
                        if (wildcardMatch($index_pattern, $index)) {
                            $match = TRUE;
                        }
                    }
                    foreach ($v['index_patterns_exclude'] as $index_pattern) {
                        if (wildcardMatch($index_pattern, $index)) {
                            $match = FALSE;
                        }
                    }
                }
            }
            foreach ($_SESSION['ldapgroups'] as $group) {
                if ($group === $user_group || wildcardMatch($user_group, $group)) {
                    foreach ($index_arr as $i => $v) {
                        foreach ($v['index_patterns'] as $index_pattern) {
                            if (wildcardMatch($index_pattern, $index)) {
                                $match = TRUE;
                            }
                        }
                        foreach ($v['index_patterns_exclude'] as $index_pattern) {
                            if (wildcardMatch($index_pattern, $index)) {
                                $match = FALSE;
                            }
                        }
                    }
                }
            }
        } elseif ($_SESSION['oktalogin']) {
            if ($_SESSION['username'] === $user_group) {
                foreach ($index_arr as $i => $v) {
                    foreach ($v['index_patterns'] as $index_pattern) {
                        if (wildcardMatch($index_pattern, $index)) {
                            $match = TRUE;
                        }
                    }
                    foreach ($v['index_patterns_exclude'] as $index_pattern) {
                        if (wildcardMatch($index_pattern, $index)) {
                            $match = FALSE;
                        }
                    }
                }
            }
            foreach ($_SESSION['oktagroups'] as $group) {
                if ($group === $user_group || wildcardMatch($user_group, $group)) {
                    foreach ($index_arr as $i => $v) {
                        foreach ($v['index_patterns'] as $index_pattern) {
                            if (wildcardMatch($index_pattern, $index)) {
                                $match = TRUE;
                            }
                        }
                        foreach ($v['index_patterns_exclude'] as $index_pattern) {
                            if (wildcardMatch($index_pattern, $index)) {
                                $match = FALSE;
                            }
                        }
                    }
                }
            }
        } else {
            if ($_SESSION['username'] === $user_group) {
                foreach ($index_arr as $i => $v) {
                    foreach ($v['index_patterns'] as $index_pattern) {
                        if (wildcardMatch($index_pattern, $index)) {
                            $match = TRUE;
                        }
                    }
                    foreach ($v['index_patterns_exclude'] as $index_pattern) {
                        if (wildcardMatch($index_pattern, $index)) {
                            $match = FALSE;
                        }
                    }
                }
            }
        }
    }
    // remove index if match is false
    if (!$match) {
        removeIndex($esnode, $index, $uuid);
    }
    return $match;
}


function get_es_path($index, $numofpaths)
{
    /* try to get a top level path from ES index
    if there are multiple paths, return them all, 
    don't return if the path is still being indexed */
    global $mnclient, $client;

    $searchParams['body'] = [];

    // Setup search query
    $searchParams['index'] = $mnclient->getSearchIndex($index);

    $searchParams['body'] = [
        'size' => $numofpaths,
        'query' => [
            'match' => ['type' => 'indexinfo']
        ]
    ];

    // Send search query to Elasticsearch and get results
    try {
        $queryResponse = $client->search($searchParams);
    } catch (Missing404Exception $e) {
        deleteCookie('index');
        deleteCookie('index2');
        clearPaths();
        handleError("Selected indices are no longer available. Please select a different index.");
    } catch (Exception $e) {
        handleError('ES error: ' . $e->getMessage(), true);
    }

    $results = $queryResponse['hits']['hits'];

    if (sizeof($results) > 1) {
        $paths = [];
        foreach ($results as $res) {
            if (!in_array($res['_source']['path'], $paths)) {
                if ($res['_source']['end_at']) {
                    $paths[] = $res['_source']['path'];
                }
            }
        }
        return $paths;
    } else {
        $path = $results[0]['_source']['path'];
        return $path;
    }
}


// return time in ES format
function gettime($time)
{
    // default 0 days time filter
    if (empty($time) || $time === "now" || $time === 0) {
        $time = 'now/m';
    } elseif ($time === "today") {
        $time = 'now/m';
    } elseif ($time === "tomorrow") {
        $time = 'now/m+1d/d';
    } elseif ($time === "yesterday") {
        $time = 'now/m-1d/d';
    } elseif ($time === "1d") {
        $time = 'now/m-1d/d';
    } elseif ($time === "1w") {
        $time = 'now/m-1w/d';
    } elseif ($time === "2w") {
        $time = 'now/m-2w/d';
    } elseif ($time === "1m") {
        $time = 'now/m-1M/d';
    } elseif ($time === "2m") {
        $time = 'now/m-2M/d';
    } elseif ($time === "3m") {
        $time = 'now/m-3M/d';
    } elseif ($time === "6m") {
        $time = 'now/m-6M/d';
    } elseif ($time === "1y") {
        $time = 'now/m-1y/d';
    } elseif ($time === "2y") {
        $time = 'now/m-2y/d';
    } elseif ($time === "3y") {
        $time = 'now/m-3y/d';
    } elseif ($time === "5y") {
        $time = 'now/m-5y/d';
    } elseif ($time === "10y") {
        $time = 'now/m-10y/d';
    }
    return $time;
}

// update url param with new value and return url
function build_url($param, $val)
{
    parse_str($_SERVER['QUERY_STRING'], $queries);
    // defaults
    $queries['index'] = isset($_GET['index']) ? $_GET['index'] : getCookie('index');
    $queries['index2'] = isset($_GET['index2']) ? $_GET['index2'] : getCookie('index2');
    $queries['path'] = isset($_GET['path']) ? $_GET['path'] : getCookie('path');
    // update q param (es query) if on search results page
    if (basename($_SERVER['PHP_SELF']) == 'search.php' && $param == 'path') {
        $queries['q'] = 'parent_path:' . escape_chars($val);
    } else {
        $queries['filter'] = isset($_GET['filter']) ? $_GET['filter'] : getCookie('filter');
        $queries['time'] = isset($_GET['time']) ? $_GET['time'] : getCookie('time');
        $queries['use_count'] = isset($_GET['use_count']) ? $_GET['use_count'] : getCookie('use_count');
        $queries['show_files'] = isset($_GET['show_files']) ? $_GET['show_files'] : getCookie('show_files');
    }
    // set new param
    $queries[$param] = $val;
    $q = http_build_query($queries, '', '&', PHP_QUERY_RFC3986);
    $url = $_SERVER['PHP_SELF'] . "?" . $q;
    return $url;
}

// human readable file size format function
function formatBytes($bytes, $precision = 1)
{
    if ($bytes == 0) {
        return "0 Bytes";
    }
    if (getCookie('filesizebase10') == '1') {
        $basen = 1000;
    } else {
        $basen = 1024;
    }
    $precision_cookie = getCookie('filesizedec');
    if ($precision_cookie != '') {
        $precision = $precision_cookie;
    }
    $base = log($bytes) / log($basen);
    $suffix = array("Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")[floor($base)];

    return round(pow($basen, $base - floor($base)), $precision) . " " . $suffix;
}

// convert human readable file size format to bytes
function convertToBytes($num, $unit)
{
    if ($num == 0) return 0;
    if ($unit == "") return $num;
    if ($unit == "bytes") {
        return $num;
    } elseif ($unit == "KB") {
        return $num * 1024;
    } elseif ($unit == "MB") {
        return $num * 1024 * 1024;
    } elseif ($unit == "GB") {
        return $num * 1024 * 1024 * 1024;
    }
}


// cookie functions
// set default expiry time to 1 year
function createCookie($cname, $cvalue, $days = 365)
{
    $expire = time() + ($days * 24 * 60 * 60);
    setcookie($cname, $cvalue, $expire, "/");
}


function getCookie($cname)
{
    $c = (isset($_COOKIE[$cname])) ? $_COOKIE[$cname] : '';
    return $c;
}


function createCookieFromArray($cname, $cvalue, $days = 365)
{
    $expire = time() + ($days * 24 * 60 * 60);
    setcookie($cname, json_encode($cvalue), $expire, "/");
}


function getCookieToArray($cname)
{
    $c = (isset($_COOKIE[$cname])) ? json_decode($_COOKIE[$cname], true) : '';
    return $c;
}


function deleteCookie($cname)
{
    setcookie($cname, "", time() - 3600);
}


// saved search query functions
function saveSearchQuery($req)
{
    if (!isset($_REQUEST['userinput']) || !$_REQUEST['userinput']) return;
    
    ($req === "") ? $req = "type:(file OR directory)" : "";
    if (getCookie('savedsearches') != "") {
        $json = getCookie('savedsearches');
        $savedsearches = json_decode(rawurldecode($json), true);
        if (sizeof($savedsearches) >= 10) {
            array_shift($savedsearches);
        }
        if (!in_array($req, $savedsearches)) {
            $savedsearches[] = $req;
        }
    } else {
        $savedsearches = array();
        $savedsearches[] = $req;
    }
    $json = rawurlencode(json_encode($savedsearches));
    createCookie('savedsearches', $json);
}


function getSavedSearchQuery()
{
    if (!isset($_SESSION['savedsearches'])) {
        return false;
    }
    $json = $_SESSION['savedsearches'];
    $savedsearches = json_decode($json, true);
    $savedsearches = array_reverse($savedsearches);
    $savedsearches = array_slice($savedsearches, 0, 10);
    return $savedsearches;
}


function changePercent($a, $b)
{
    return (($a - $b) / $b) * 100;
}


function getParentDir($p)
{
    if (strlen($p) > strlen($_SESSION['rootpath'])) {
        return dirname($p);
    } else {
        return $_SESSION['rootpath'];
    }
}


function secondsToTime($seconds)
{
    $seconds = (int) $seconds;
    $dtF = new \DateTime('@0');
    $dtT = new \DateTime("@$seconds");
    if ($seconds < 60) {
        $time = $dtF->diff($dtT)->format('%Ss');
    } elseif ($seconds < 3600) {
        $time = $dtF->diff($dtT)->format('%Im:%Ss');
    } elseif ($seconds < 86400) {
        $time = $dtF->diff($dtT)->format('%Hh:%Im:%Ss');
    } else {
        $time = $dtF->diff($dtT)->format('%ad:%Hh:%Im:%Ss');
    }
    return $time;
}

// convert utc iso timestamp to local time
function utcTimeToLocal($date)
{
    if ($date == null) {
        return "-";
    }
    if (getCookie('localtime') == "" || getCookie('localtime') == "0") {
        return $date;
    }
    $l10nDate = new DateTime($date, new DateTimeZone('UTC'));
    $l10nDate->setTimeZone(new DateTimeZone($GLOBALS['config']->TIMEZONE));
    return $l10nDate->format('Y-m-d H:i:s');
}

// get and change url variable for sorting search results table
function sortURL($sort)
{
    $query = $_GET;
    $sortorder = ['asc', 'desc'];
    $sortorder_icons = ['fas fa-sort-up', 'fas fa-sort-down'];

    $arrows = "";
    foreach ($sortorder as $key => $value) {
        # set class for sort arrow
        if ($_GET['sort'] == $sort && $_GET['sortorder'] == $value) {
            $class = 'sortarrow-' . $value . '-active';
        } elseif ($_GET['sort2'] == $sort && $_GET['sortorder2'] == $value) {
            $class = 'sortarrow2-' . $value . '-active';
        } elseif (!isset($_GET['sort']) && getCookie('sort') == $sort && getCookie('sortorder') == $value) {
            $class = 'sortarrow-' . $value . '-active';
        } elseif (!isset($_GET['sort2']) && getCookie('sort2') == $sort && getCookie('sortorder2') == $value) {
            $class = 'sortarrow2-' . $value . '-active';
        } else {
            $class = '';
        }
        # build link for arrow
        # sort 1 set, set sort 2
        if ((isset($_GET['sort']) || getCookie('sort')) && (!isset($_GET['sort2']) && !getCookie('sort2')) && ($_GET['sort'] != $sort && getCookie('sort') != $sort)) {
            $query['sort2'] = $sort;
            $query['sortorder2'] = $value;
            $query_result = http_build_query($query);
            $arrows .= "<a href=\"" . $_SERVER['PHP_SELF'] . "?" . $query_result . "\" onclick=\"setCookie('sort2', '" . $sort . "'); setCookie('sortorder2', '" . $value . "');\"><i class=\"" . $sortorder_icons[$key] . " sortarrow-" . $value . " " . $class . "\"></i></a>";
        } elseif ((isset($_GET['sort2']) || getCookie('sort2')) && (!isset($_GET['sort']) && !getCookie('sort')) && ($_GET['sort2'] != $sort && getCookie('sort2') != $sort)) {  # sort 2 set, set sort 1
            $query['sort'] = $sort;
            $query['sortorder'] = $value;
            $query_result = http_build_query($query);
            $arrows .= "<a href=\"" . $_SERVER['PHP_SELF'] . "?" . $query_result . "\" onclick=\"setCookie('sort', '" . $sort . "'); setCookie('sortorder', '" . $value . "');\"><i class=\"" . $sortorder_icons[$key] . " sortarrow-" . $value . " " . $class . "\"></i></a>";
        } elseif ((isset($_GET['sort']) || getCookie('sort')) && ($_GET['sort'] == $sort || getCookie('sort') == $sort) && ($_GET['sortorder'] != $value && getCookie('sortorder') != $value)) {
            $query['sort'] = $sort;
            $query['sortorder'] = $value;
            $query_result = http_build_query($query);
            $arrows .= "<a href=\"" . $_SERVER['PHP_SELF'] . "?" . $query_result . "\" onclick=\"setCookie('sort', '" . $sort . "'); setCookie('sortorder', '" . $value . "');\"><i class=\"" . $sortorder_icons[$key] . " sortarrow-" . $value . " " . $class . "\"></i></a>";
        } elseif ((isset($_GET['sort']) || getCookie('sort')) && ($_GET['sort'] == $sort || getCookie('sort') == $sort) && ($_GET['sortorder'] == $value || getCookie('sortorder') == $value)) {
            $query['sort'] = null;
            $query['sortorder'] = null;
            $query_result = http_build_query($query);
            $arrows .= "<a href=\"" . $_SERVER['PHP_SELF'] . "?" . $query_result . "\" onclick=\"deleteCookie('sort'); deleteCookie('sortorder');\"><i class=\"" . $sortorder_icons[$key] . " sortarrow-" . $value . " " . $class . "\"></i></a>";
        } elseif ((isset($_GET['sort2']) || getCookie('sort2')) && ($_GET['sort2'] == $sort || getCookie('sort2') == $sort) && ($_GET['sortorder2'] != $value && getCookie('sortorder2') != $value)) {
            $query['sort2'] = $sort;
            $query['sortorder2'] = $value;
            $query_result = http_build_query($query);
            $arrows .= "<a href=\"" . $_SERVER['PHP_SELF'] . "?" . $query_result . "\" onclick=\"setCookie('sort2', '" . $sort . "'); setCookie('sortorder2', '" . $value . "');\"><i class=\"" . $sortorder_icons[$key] . " sortarrow-" . $value . " " . $class . "\"></i></a>";
        } elseif ((isset($_GET['sort2']) || getCookie('sort2')) && ($_GET['sort2'] == $sort || getCookie('sort2') == $sort) && ($_GET['sortorder2'] == $value || getCookie('sortorder2') == $value)) {
            $query['sort2'] = null;
            $query['sortorder2'] = null;
            $query_result = http_build_query($query);
            $arrows .= "<a href=\"" . $_SERVER['PHP_SELF'] . "?" . $query_result . "\" onclick=\"deleteCookie('sort2'); deleteCookie('sortorder2');\"><i class=\"" . $sortorder_icons[$key] . " sortarrow-" . $value . " " . $class . "\"></i></a>";
        } else {
            $query['sort'] = $sort;
            $query['sortorder'] = $value;
            $query_result = http_build_query($query);
            $arrows .= "<a href=\"" . $_SERVER['PHP_SELF'] . "?" . $query_result . "\" onclick=\"setCookie('sort', '" . $sort . "'); setCookie('sortorder', '" . $value . "');\"><i class=\"" . $sortorder_icons[$key] . " sortarrow-" . $value . " " . $class . "\"></i></a>";
        }
    }

    return "<span class=\"sortarrow-container\">" . $arrows . "</span>";
}

// escape special characters
function escape_chars($text)
{
    $chr = '+-=&|<>!(){}[]^"~*?:\'/ ';
    return addcslashes($text, $chr);
}

// open file and return file pointer
function openFile($file, $mode) {
    try {
        if (!file_exists($file)) {
            handleError("File " . $file . " not found.", false, false, true);
        }
        $fp = fopen($file, $mode);
        if (!$fp) {
            handleError("File ".$file." open failed.", false, false, true);
        }
    } catch (Exception $e) {
        handleError("Error opening " . $file . " " . $e->getMessage(), false, false, true);
    }
    return $fp;
}

// write data to file
function writeToFile($fp, $file, $data) {
    try {
        fwrite($fp, $data);
    } catch (Exception $e) {
        handleError("Error writing to " . $file . " " . $e->getMessage(), false, false, true);
    }
}

// get custom tags from customtags.txt
function get_custom_tags()
{
    $fp = openFile("customtags.txt", "r");
    $t = [];
    // grab each line (tag)
    while (!feof($fp)) {
        $l = trim(fgets($fp));
        if ($l === "") {
            continue;
        }
        // hex color for tag separated by pipe |
        $t[] = explode('|', $l);
    }
    fclose($fp);
    return $t;
}

// get reports queries from reports.txt
function get_reports()
{
    return get_txtfile_data("reports.txt");
}

// get smart searhches queries from smartsearches.txt
function get_smartsearches()
{
    return get_txtfile_data("smartsearches.txt");
}

// get cost analysis queries from costanalysis.txt
function get_costanalysis()
{
    return get_txtfile_data("costanalysis.txt");
}

// gets text file data from file
function get_txtfile_data($file)
{
    $fp = openFile($file, "r");
    $ss = [];
    // grab each line (cost analysis string)
    while (!feof($fp)) {
        $l = trim(fgets($fp));
        if ($l === "") {
            continue;
        }
        // es search query for cost analysis separated by pipe |
        $ss[] = explode('|', $l);
    }
    fclose($fp);
    return $ss;
}

// add custom tag to customtags.txt
function add_custom_tag($t)
{
    $tag = trim(explode('|', $t)[0]);
    $color = trim(explode('|', $t)[1]);
    if ($color == "") {
        // default hex color for tags
        $color = "#CCC";
    }
    $file = "customtags.txt";
    $fp = openFile($file, "a");
    $data = $tag . '|' . $color . PHP_EOL;
    writeToFile($fp, $file, $data);
    fclose($fp);
}

// get custom tag color from customtags.txt
function get_custom_tag_color($t)
{
    global $customtagscolors;

    if (array_key_exists($t, $customtagscolors)) {
        return $customtagscolors[$t];
    }
    $c = "#ccc";
    $fp = openFile("customtags.txt", "r");
    // grab each line (tag)
    while (!feof($fp)) {
        $l = trim(fgets($fp));
        if ($l === "") {
            continue;
        }
        // hex color for tag separated by pipe |
        $tag = explode('|', $l)[0];
        $color = explode('|', $l)[1];
        if ($color == "") {
            // default hex color for tags
            $color = "#CCC";
        }
        if ($t == $tag) {
            $c = $color;
            break;
        }
    }
    fclose($fp);
    $customtagscolors[$t] = $c;
    return $c;
}

// get index mappings
function get_indexmappings()
{
    if (!$GLOBALS['config']->INDEX_MAPPINGS_ENABLED) {
        return;
    }
    if ($GLOBALS['config']->INDEX_MAPPINGS_USE_FILE) {
        $file = 'indexmappings.json';
        try {
            if (!file_exists($file)) {
                handleError("File " . $file . " not found.");
            }
            try {
                $indexmappings_string = file_get_contents($file);
            } catch (Exception $e) {
                handleError("File ".$file." open failed. " . $e->getMessage());
            }
        } catch (Exception $e) {
            handleError("Error opening " . $file . " " . $e->getMessage());
        }
        $indexmappings_arr = json_decode($indexmappings_string, true);
        $indexmappings = $indexmappings_arr['index_mappings'];
    } else {
        $indexmappings = $GLOBALS['config']->INDEX_MAPPINGS;
    }
    $_SESSION['index_mappings'] = $indexmappings;
}

// get index2 file info for comparison with index
function get_index2_fileinfo($client, $index, $parent_path, $name)
{
    global $mnclient;
    $searchParams = [];
    $searchParams['index'] = $mnclient->getSearchIndex($index);
    $parent_path = escape_chars($parent_path);
    $name = escape_chars($name);
    $searchParams['body'] = [
        'size' => 1,
        '_source' => ['size', 'size_du', 'file_count', 'dir_count', 'type'],
        'query' => [
            'query_string' => [
                'query' => 'name:' . $name . ' AND parent_path:' . $parent_path  . ' AND type:(directory OR file)'
            ]
        ]
    ];
    $queryResponse = $client->search($searchParams);
    if (empty($queryResponse['hits']['hits'][0]['_source'])) {
        return [0, 0, 0, 0, 0];
    }
    $size = $queryResponse['hits']['hits'][0]['_source']['size'];
    $size_du = $queryResponse['hits']['hits'][0]['_source']['size_du'];
    if ($queryResponse['hits']['hits'][0]['_source']['type'] == 'directory') {
        $file_count = $queryResponse['hits']['hits'][0]['_source']['file_count'];
        $dir_count = $queryResponse['hits']['hits'][0]['_source']['dir_count'];
        $items = $file_count + $dir_count;
        $arr = [$size, $size_du, $items, $file_count, $dir_count];
    } else {
        $arr = [$size, $size_du];
    }
    return $arr;
}

// sort search results and set cookies for search pages
function sortSearchResults($request, $searchParams)
{
    if (!isset($request['sort']) && !isset($request['sort2']) && !getCookie("sort") && !getCookie("sort2")) {
        if (getCookie('unsorted') == 1) {
            $searchParams['body']['sort'] = [];
        } else {
            // set default search sort order
            $searchParams['body']['sort'] = [
                'parent_path' => [
                    'order' => 'asc'
                ], 
                'name' => [
                    'order' => 'asc'
                ]
            ];
            createCookie('sort', 'parent_path');
            createCookie('sortorder', 'asc');
            createCookie('sort2', 'name');
            createCookie('sortorder2', 'asc');
        }
    } else {
        $searchParams['body']['sort'] = [];
        $sortarr = ['sort', 'sort2'];
        $sortorderarr = ['sortorder', 'sortorder2'];
        foreach ($sortarr as $key => $value) {
            if (isset($request[$value]) && !$request[$sortorderarr[$key]]) {
                $searchParams['body']['sort'] = $request[$value];
                createCookie($value, $request[$value]);
            } elseif (isset($request[$value]) && $request[$sortorderarr[$key]]) {
                array_push($searchParams['body']['sort'], [$request[$value] => ['order' => $request[$sortorderarr[$key]]]]);
                createCookie($value, $request[$value]);
                createCookie($sortorderarr[$key], $request[$sortorderarr[$key]]);
            } elseif (getCookie($value) && !getCookie($sortorderarr[$key])) {
                $searchParams['body']['sort'] = getCookie($value);
            } elseif (getCookie($value) && getCookie($sortorderarr[$key])) {
                array_push($searchParams['body']['sort'], [getCookie($value) => ['order' => getCookie($sortorderarr[$key])]]);
            }
        }
    }
    return $searchParams;
}

// predict search request and handle smartsearch requests
function predict_search($q)
{
    global $customtags, $smartsearches;

    // remove any extra white space and check for escape character and space at end to not trim off trailing space
    if (substr($q, -2) == '\ ') {
        $q = ltrim($q);
    } else {
        $q = trim($q);
    }

    $lucene = false;

    // check for escape character to use lucene quuery
    if (strpos($q, '\\') === 0) {
        // remove escape character \
        $request = ltrim($q, '\\');
        $lucene = true;
    // check for path input
    } elseif (strpos($q, '/') === 0 && strpos($q, 'parent_path') === false) {
        // trim any trailing slash unless root /
        if ($q !== "/") {
            $q = rtrim($q, '/');
        }
        // check for escaped paths
        if (strpos($q, '\/') !== false) {
            $request = $q;
        } else {
            $request = escape_chars($q);
        }
        // check for / path
        if ($q == '/') {
            $path = '/';
            setRootPath($path);
            $request = 'parent_path:\/ AND NOT name:""';
        // check for wildcard at end of path
        } elseif (preg_match('/^.*\\*$/', $request)) {
            $pathnowild = rtrim($request, '\*');
            $path = str_replace('\\', '', $pathnowild);
            setRootPath($path);
            $request = 'parent_path:' . $pathnowild . '*';
        } elseif (preg_match('/(^.*\.\w{3,4}(\.\w{2}){0,1}$)|(^.*\/\..*$)/', $request)) { // file
            $pp = rtrim(dirname($request), '\/');
            if ($pp === "") $pp = '""';
            $path = rtrim(dirname($q), '/');
            setRootPath($path);
            $request = 'parent_path:' . $pp . ' AND name:' . rtrim(basename($request), '\/');
        } else { // directory
            $pp = rtrim(dirname($request), '\/');
            if ($pp === "") $pp = '""';
            $path = str_replace('\\', '', $request);
            setRootPath($path);
            $request = '(parent_path:' . $pp  . ' AND name:' . rtrim(basename($request), '\/') . ') OR parent_path:' . $request;
        }
    } elseif (strpos($q, '!') === 0) {  # ! smart search keyword
        if ($q === '!') {
            echo '<span class="text-info"><i class="glyphicon glyphicon-share-alt"></i> Enter in a smart search name like <strong>!tmp</strong> or <strong>!doc</strong> or <strong>!img</strong>.</span>';
            echo '<br /><span class="text-info">Smart searches:</span><br />';
            foreach ($smartsearches as $arr) {
                echo '<a href="search.php?p=1&submitted=true&q=' . urlencode($arr[1]) . '" class="btn btn-primary btn-sm">' . $arr[0] . '</a>&nbsp;';
            }
            // disable search submit
            echo '<script type="text/javascript">
            disableSearchSubmit();
            </script>';
            die();
        } elseif (preg_match('/^\!(\w+)/', $q) !== false) {
            // check if requested smart search is in smartsearches array
            $inarray = false;
            foreach ($smartsearches as $arr) {
                if (in_array($q, $arr)) {
                    $inarray = true;
                    $smartsearch_query = $arr[1];
                    break;
                }
            }
            if ($inarray) {
                $request = $smartsearch_query;
            } else {
                echo '<span class="text-warning"><i class="glyphicon glyphicon-exclamation-sign"></i> No matching smart search name.</span>';
                echo '<br /><span class="text-info">Smart searches:</span><br />';
                foreach ($smartsearches as $arr) {
                    echo '<a href="search.php?p=1&submitted=true&q=' . urlencode($arr[1]) . '" class="btn btn-primary btn-sm">' . $arr[0] . '</a>&nbsp;';
                }
                // disable search submit
                echo '<script type="text/javascript">
                disableSearchSubmit();
                </script>';
                die();
            }
        }
    } elseif (strpos($q, '#') === 0 && $_SESSION['license']['product_code'] !== 'ESS') {  // # custom tags keyword
        if ($q === '#') {
            echo '<span class="text-info"><i class="glyphicon glyphicon-tag"></i> Enter in a tag name like <strong>#delete</strong> or <strong>#archive</strong> or <strong>#keep</strong>.</span>';
            echo '<br /><span class="text-info">Tags:</span><br />';
            foreach ($customtags as $arr) {
                $urlenc = urlencode("tags:\"$arr[0]\"");
                echo '<a href="search.php?p=1&submitted=true&q=' . $urlenc . '" class="btn btn-primary btn-sm"><i class="fas fa-tag" style="color:' . $arr[1] . '"></i> ' . $arr[0] . '</a>&nbsp;';
            }
            // disable search submit
            echo '<script type="text/javascript">
            disableSearchSubmit();
            </script>';
            die();
        } elseif (preg_match('/^\#(\w+)/', $q) !== false) {
            // check if requested tags is in customtags array
            $inarray = false;
            foreach ($customtags as $arr) {
                if (in_array(str_replace('#', '', $q), $arr)) {
                    $inarray = true;
                    $customtags_query = "tags:\"$arr[0]\"";
                    break;
                }
            }
            if ($inarray) {
                $request = $customtags_query;
            } else {
                echo '<span class="text-warning"><i class="glyphicon glyphicon-exclamation-sign"></i> No matching tag name.</span>';
                echo '<br /><span class="text-info">Tags:</span><br />';
                foreach ($customtags as $arr) {
                    $urlenc = urlencode("tags:\"$arr[0]\"");
                    echo '<a href="search.php?p=1&submitted=true&q=' . $urlenc . '" class="btn btn-primary btn-sm"><i class="fas fa-tag" style="color:' . $arr[1] . '"></i> ' . $arr[0] . '</a>&nbsp;';
                }
                // disable search submit
                echo '<script type="text/javascript">
                disableSearchSubmit();
                </script>';
                die();
            }
        }
    // NOT es field query such as name:filename
    } elseif (preg_match('/(\w+):/i', $q) == false && !empty($q)) {
        $request = '';
        $keywords = explode(' ', $q);
        if (sizeof($keywords) === 1) {
            $request = $keywords[0];
        } else {
            $n = sizeof($keywords);
            $x = 0;
            foreach ($keywords as $keyword) {
                # replace any #tagname with tags field
                if (preg_match('/\#(\w+)/', $keyword)) {
                    $keyword = 'tags:"' . ltrim($keyword, '#') . '"';
                }
                $request .= $keyword;
                if ($x < $n - 1) $request .= ' ';
                $x++;
            }
        }
    } else {
        $request = $q;
    }

    if (!$lucene) {
        // replace any and with AND and or with OR and not with NOT, except got lucene search
        $request = preg_replace('/ and /', ' AND ', $request);
        $request = preg_replace('/ or /', ' OR ', $request);
        $request = preg_replace('/ not /', ' NOT ', $request);
    }

    return $request;
}


// curl function to get ES data
function curl_es($host, $url, $request = null, $return_json = true)
{
    global $es_responsetime;

    // use first es node
    $hostname = $host['hosts'][0];
    $port = $host['port'];
    $user = $host['user'];
    $pass = $host['pass'];
    $scheme = ($host['https']) ? "https" : "http";
    $sslverify = $GLOBALS['config']->ES_SSLVERIFICATION;

    // Get cURL resource
    $curl = curl_init();
    // Set curl options
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($curl, CURLOPT_TIMEOUT, 30);
    if (!$sslverify) {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYSTATUS, false);
    }
    if ($request === "DELETE") {
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'DELETE');
    } elseif ($request === "POST") {
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
    }
    $curl_url = $scheme . '://' . $hostname . ':' . $port . $url;
    curl_setopt($curl, CURLOPT_URL, $curl_url);
    // Add user/pass if using ES auth
    if (!empty($user) && !empty($pass)) {
        curl_setopt($curl, CURLOPT_USERPWD, "$user:$pass");
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    }
    // Send the request & save response to $curlresp
    $curlresp = curl_exec($curl);
    // Get status code of curl
    $status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $hostwport = $hostname . ":" . $port;
    // Handle any curl errors
    if (curl_errno($curl)) {
        if ($curlerror = curl_error($curl)) {
            $curlerror = " Error: " . $curlerror;
        } else {
            $curlerror = "";
        }
        $err = "Unable to connect to Elasticsearch host " . $hostwport . "." . $curlerror;
        handleError($err);
    } elseif ($status_code != 200) {
        $err = "Error connecting to Elasticsearch host " . $hostwport . ". Status code: " . $status_code;
        handleError($err);
    }
    // Get response time
    $info = curl_getinfo($curl);
    $es_responsetime[$hostwport] = $info['total_time'];
    // Close request to clear up some resources
    curl_close($curl);
    if ($return_json) {
        $curlresp = json_decode($curlresp, true);
    }

    return $curlresp;
}

function wildcardMatch($pattern, $subject)
{
    $pattern = strtr($pattern, array(
        '*' => '.*?',
        '?' => '.',
    ));
    return preg_match("/$pattern/", $subject);
}

// calculate file rating
function calcFileRating($file)
{
    $date1 = date_create(date('Y-m-dTH:i:s'));
    $date2 = date_create($file['mtime']);
    $diff = date_diff($date1, $date2);
    $mtime_daysago = $diff->format('%a');
    if ($mtime_daysago >= 730) {
        $file_rating = 1;
    } elseif ($mtime_daysago < 730 && $mtime_daysago >= 365) {
        $file_rating = .75;
    } elseif ($mtime_daysago < 365 && $mtime_daysago >= 180) {
        $file_rating = .5;
    } elseif ($mtime_daysago < 180 && $mtime_daysago >= 90) {
        $file_rating = .25;
    } elseif ($mtime_daysago < 90 && $mtime_daysago >= 30) {
        $file_rating = .1;
    } else {
        $file_rating = 0;
    }
    return $file_rating;
}

// filter paths for index mappings
function filterIndexMappingPaths($searchParams)
{
    // filter paths based on user/group index mappings
    if ($GLOBALS['config']->INDEX_MAPPINGS_ENABLED) {
        foreach ($_SESSION['index_mappings'] as $user_group => $index_arr) {
            if ($_SESSION['ldaplogin']) {
                if ($_SESSION['username'] === $user_group) {
                    foreach ($index_arr as $i => $v) {
                        if (isset($v['excluded_dirs']) && !empty($v['excluded_dirs'])) {
                            foreach ($v['excluded_dirs'] as $blacklist_path) {
                                $pp = escape_chars(dirname($blacklist_path));
                                $dirname = basename($blacklist_path);
                                $pathwildcard = escape_chars($blacklist_path) . "*";
                                $searchParams['body']['query']['query_string']['query'] .= ' AND NOT (parent_path:' . $pp . ' AND name:"' . $dirname . '") AND NOT parent_path:' . $pathwildcard;
                            }
                        }
                        if (isset($v['excluded_query']) && !empty($v['excluded_query'])) {
                            foreach ($v['excluded_query'] as $blacklist_query) {
                                $searchParams['body']['query']['query_string']['query'] .= ' AND NOT ' . $blacklist_query;
                            }
                        }
                    }
                    continue;
                }
                foreach ($_SESSION['ldapgroups'] as $group) {
                    if ($group === $user_group || wildcardMatch($user_group, $group)) {
                        foreach ($index_arr as $i => $v) {
                            if (isset($v['excluded_dirs']) && !empty($v['excluded_dirs'])) {
                                foreach ($v['excluded_dirs'] as $blacklist_path) {
                                    $pp = escape_chars(dirname($blacklist_path));
                                    $dirname = basename($blacklist_path);
                                    $pathwildcard = escape_chars($blacklist_path) . "*";
                                    $searchParams['body']['query']['query_string']['query'] .= ' AND NOT (parent_path:' . $pp . ' AND name:"' . $dirname . '") AND NOT parent_path:' . $pathwildcard;
                                }
                            }
                            if (isset($v['excluded_query']) && !empty($v['excluded_query'])) {
                                foreach ($v['excluded_query'] as $blacklist_query) {
                                    $searchParams['body']['query']['query_string']['query'] .= ' AND NOT ' . $blacklist_query;
                                }
                            }
                        }
                    }
                }
            } elseif ($_SESSION['oktalogin']) {
                if ($_SESSION['username'] === $user_group) {
                    foreach ($index_arr as $i => $v) {
                        if (isset($v['excluded_dirs']) && !empty($v['excluded_dirs'])) {
                            foreach ($v['excluded_dirs'] as $blacklist_path) {
                                $pp = escape_chars(dirname($blacklist_path));
                                $dirname = basename($blacklist_path);
                                $pathwildcard = escape_chars($blacklist_path) . "*";
                                $searchParams['body']['query']['query_string']['query'] .= ' AND NOT (parent_path:' . $pp . ' AND name:"' . $dirname . '") AND NOT parent_path:' . $pathwildcard;
                            }
                        }
                        if (isset($v['excluded_query']) && !empty($v['excluded_query'])) {
                            foreach ($v['excluded_query'] as $blacklist_query) {
                                $searchParams['body']['query']['query_string']['query'] .= ' AND NOT ' . $blacklist_query;
                            }
                        }
                    }
                    continue;
                }
                foreach ($_SESSION['oktagroups'] as $group) {
                    if ($group === $user_group || wildcardMatch($user_group, $group)) {
                        foreach ($index_arr as $i => $v) {
                            if (isset($v['excluded_dirs']) && !empty($v['excluded_dirs'])) {
                                foreach ($v['excluded_dirs'] as $blacklist_path) {
                                    $pp = escape_chars(dirname($blacklist_path));
                                    $dirname = basename($blacklist_path);
                                    $pathwildcard = escape_chars($blacklist_path) . "*";
                                    $searchParams['body']['query']['query_string']['query'] .= ' AND NOT (parent_path:' . $pp . ' AND name:"' . $dirname . '") AND NOT parent_path:' . $pathwildcard;
                                }
                            }
                            if (isset($v['excluded_query']) && !empty($v['excluded_query'])) {
                                foreach ($v['excluded_query'] as $blacklist_query) {
                                    $searchParams['body']['query']['query_string']['query'] .= ' AND NOT ' . $blacklist_query;
                                }
                            }
                        }
                    }
                }
            } else {
                if ($_SESSION['username'] === $user_group) {
                    foreach ($index_arr as $i => $v) {
                        if (isset($v['excluded_dirs']) && !empty($v['excluded_dirs'])) {
                            foreach ($v['excluded_dirs'] as $blacklist_path) {
                                $pp = escape_chars(dirname($blacklist_path));
                                $dirname = basename($blacklist_path);
                                $pathwildcard = escape_chars($blacklist_path) . "*";
                                $searchParams['body']['query']['query_string']['query'] .= ' AND NOT (parent_path:' . $pp . ' AND name:"' . $dirname . '") AND NOT parent_path:' . $pathwildcard;
                            }
                        }
                        if (isset($v['excluded_query']) && !empty($v['excluded_query'])) {
                            foreach ($v['excluded_query'] as $blacklist_query) {
                                $searchParams['body']['query']['query_string']['query'] .= ' AND NOT ' . $blacklist_query;
                            }
                        }
                    }
                }
            }
        }
    }
    return $searchParams;
}

// filter AD/ldap groups
function filterLDAPGroups($searchParams)
{
    // filter based on AD/ldap group membership
    // exclude any docs with an inode 0, such as docs indexed from s3 alt scanner
    if ($_SESSION['ldaplogin'] && $GLOBALS['config']->LDAP_FILTERING_ENABLED) {
        foreach ($_SESSION['ldapgroups'] as $key => $group) {
            if (in_array($group, $GLOBALS['config']->LDAP_GROUPS_EXCLUDED)) {
                return $searchParams;
            }
        }
        $groups = implode(" OR ", $_SESSION['ldapgroups']);
        if ($GLOBALS['config']->UNIXPERMS_FILTERING_ENABLED) {
            $searchParams['body']['query']['query_string']['query'] .= " AND (owner:". $_SESSION['username'] . " OR group:(" . $groups . ") OR unix_perms:/..[57]/ OR ino:0)";
        } else {
            $searchParams['body']['query']['query_string']['query'] .= " AND (owner:". $_SESSION['username'] . " OR group:(" . $groups . ") OR ino:0)";
        }
    }
    return $searchParams;
}

// removes index mappings filters from query string
function removeFiltersFromQuery($query)
{
    // filter paths based on user/group index mappings
    if ($GLOBALS['config']->INDEX_MAPPINGS_ENABLED) {
        foreach ($_SESSION['index_mappings'] as $user_group => $index_arr) {
            if ($_SESSION['ldaplogin']) {
                if ($_SESSION['username'] === $user_group) {
                    foreach ($index_arr as $i => $v) {
                        if (isset($v['excluded_dirs']) && !empty($v['excluded_dirs'])) {
                            foreach ($v['excluded_dirs'] as $blacklist_path) {
                                $pp = escape_chars(dirname($blacklist_path));
                                $dirname = basename($blacklist_path);
                                $search = " AND NOT (parent_path:" . $pp . ' AND name:"' . $dirname . '")';
                                $query = str_replace($search, "", $query);
                            }
                        }
                        if (isset($v['excluded_query']) && !empty($v['excluded_query'])) {
                            foreach ($v['excluded_query'] as $blacklist_query) {
                                $search = " AND NOT " . $blacklist_query;
                                $query = str_replace($search, "", $query);
                            }
                        }
                    }
                    continue;
                }
                foreach ($_SESSION['ldapgroups'] as $group) {
                    if ($group === $user_group || wildcardMatch($user_group, $group)) {
                        foreach ($index_arr as $i => $v) {
                            if (isset($v['excluded_dirs']) && !empty($v['excluded_dirs'])) {
                                foreach ($v['excluded_dirs'] as $blacklist_path) {
                                    $pp = escape_chars(dirname($blacklist_path));
                                    $dirname = basename($blacklist_path);
                                    $search = " AND NOT (parent_path:" . $pp . ' AND name:"' . $dirname . '")';
                                    $query = str_replace($search, "", $query);
                                }
                            }
                            if (isset($v['excluded_query']) && !empty($v['excluded_query'])) {
                                foreach ($v['excluded_query'] as $blacklist_query) {
                                    $search = " AND NOT " . $blacklist_query;
                                    $query = str_replace($search, "", $query);
                                }
                            }
                        }
                    }
                }
            } elseif ($_SESSION['oktalogin']) {
                if ($_SESSION['username'] === $user_group) {
                    foreach ($index_arr as $i => $v) {
                        if (isset($v['excluded_dirs']) && !empty($v['excluded_dirs'])) {
                            foreach ($v['excluded_dirs'] as $blacklist_path) {
                                $pp = escape_chars(dirname($blacklist_path));
                                $dirname = basename($blacklist_path);
                                $search = " AND NOT (parent_path:" . $pp . ' AND name:"' . $dirname . '")';
                                $query = str_replace($search, "", $query);
                            }
                        }
                        if (isset($v['excluded_query']) && !empty($v['excluded_query'])) {
                            foreach ($v['excluded_query'] as $blacklist_query) {
                                $search = " AND NOT " . $blacklist_query;
                                $query = str_replace($search, "", $query);
                            }
                        }
                    }
                    continue;
                }
                foreach ($_SESSION['oktagroups'] as $group) {
                    if ($group === $user_group || wildcardMatch($user_group, $group)) {
                        foreach ($index_arr as $i => $v) {
                            if (isset($v['excluded_dirs']) && !empty($v['excluded_dirs'])) {
                                foreach ($v['excluded_dirs'] as $blacklist_path) {
                                    $pp = escape_chars(dirname($blacklist_path));
                                    $dirname = basename($blacklist_path);
                                    $search = " AND NOT (parent_path:" . $pp . ' AND name:"' . $dirname . '")';
                                    $query = str_replace($search, "", $query);
                                }
                            }
                            if (isset($v['excluded_query']) && !empty($v['excluded_query'])) {
                                foreach ($v['excluded_query'] as $blacklist_query) {
                                    $search = " AND NOT " . $blacklist_query;
                                    $query = str_replace($search, "", $query);
                                }
                            }
                        }
                    }
                }
            } else {
                if ($_SESSION['username'] === $user_group) {
                    foreach ($index_arr as $i => $v) {
                        if (isset($v['excluded_dirs']) && !empty($v['excluded_dirs'])) {
                            foreach ($v['excluded_dirs'] as $blacklist_path) {
                                $pp = escape_chars(dirname($blacklist_path));
                                $dirname = basename($blacklist_path);
                                $search = " AND NOT (parent_path:" . $pp . ' AND name:"' . $dirname . '")';
                                $query = str_replace($search, "", $query);
                            }
                        }
                        if (isset($v['excluded_query']) && !empty($v['excluded_query'])) {
                            foreach ($v['excluded_query'] as $blacklist_query) {
                                $search = " AND NOT " . $blacklist_query;
                                $query = str_replace($search, "", $query);
                            }
                        }
                    }
                }
            }
        }
    }
    return $query;
}

// Filter chart results
function filterChartResults($searchParams)
{
    // check if filtercharts is checked in filters page
    if (getCookie('filtercharts') == 1) {
        return filterSearchResults($searchParams);
    }
    return $searchParams;
}

// Filter search results
function filterSearchResults($searchParams)
{
    if (isset($_GET['path'])) {
        $path = $_GET['path'];
        $pathinurl = true;
    } else {
        $path = getCookie('path');
        $pathinurl = false;
    }

    $savedfilters = getCookieToArray("searchfilters");

    // check if current dir only nav toggle is active
    if (getCookie('searchcurrentdironly') == 1) {
        if ($pathinurl) {
            $searchParams['body']['query']['query_string']['query'] .= " AND parent_path:" . escape_chars($path) . '*';
        } else {
            $searchParams['body']['query']['query_string']['query'] .= " AND (parent_path:" . escape_chars($path) . " OR parent_path:" . escape_chars($path) . '*)';
        }
    }

    // return if there are no saved filters
    if (!$savedfilters) return $searchParams;

    if ($savedfilters['file_size_bytes_low']) {
        switch ($savedfilters['file_size_bytes_low_unit']) {
            case "Bytes":
                $size_bytes = $savedfilters['file_size_bytes_low'];
                break;
            case "KB":
                $size_bytes = $savedfilters['file_size_bytes_low'] * 1024;
                break;
            case "MB":
                $size_bytes = $savedfilters['file_size_bytes_low'] * 1024 * 1024;
                break;
            case "GB":
                $size_bytes = $savedfilters['file_size_bytes_low'] * 1024 * 1024 * 1024;
                break;
            case "TB":
                $size_bytes = $savedfilters['file_size_bytes_low'] * 1024 * 1024 * 1024 * 1024;
                break;
        }
        $searchParams['body']['query']['query_string']['query'] .= " AND size:>=" . $size_bytes;
    }

    if ($savedfilters['file_size_bytes_high']) {
        switch ($savedfilters['file_size_bytes_high_unit']) {
            case "Bytes":
                $size_bytes = $savedfilters['file_size_bytes_high'];
                break;
            case "KB":
                $size_bytes = $savedfilters['file_size_bytes_high'] * 1024;
                break;
            case "MB":
                $size_bytes = $savedfilters['file_size_bytes_high'] * 1024 * 1024;
                break;
            case "GB":
                $size_bytes = $savedfilters['file_size_bytes_high'] * 1024 * 1024 * 1024;
                break;
            case "TB":
                $size_bytes = $savedfilters['file_size_bytes_high'] * 1024 * 1024 * 1024 * 1024;
                break;
        }
        $searchParams['body']['query']['query_string']['query'] .= " AND size:<=" . $size_bytes;
    }

    if ($savedfilters['last_mod_time_low'] || $savedfilters['last_mod_time_high']) {
        $mtime_low = ($savedfilters['last_mod_time_low']) ? $savedfilters['last_mod_time_low'] : "*";
        $mtime_high = ($savedfilters['last_mod_time_high']) ? $savedfilters['last_mod_time_high'] : "now/m";
        $searchParams['body']['query']['query_string']['query'] .= " AND mtime:[" . $mtime_low . " TO " . $mtime_high . "]";
    }

    if ($savedfilters['last_accessed_time_low'] || $savedfilters['last_accessed_time_high']) {
        $atime_low = ($savedfilters['last_accessed_time_low']) ? $savedfilters['last_accessed_time_low'] : "*";
        $atime_high = ($savedfilters['last_accessed_time_high']) ? $savedfilters['last_accessed_time_high'] : "now/m";
        $searchParams['body']['query']['query_string']['query'] .= " AND atime:[" . $atime_low . " TO " . $atime_high . "]";
    }

    if ($savedfilters['last_changed_time_low'] || $savedfilters['last_changed_time_high']) {
        $ctime_low = ($savedfilters['last_changed_time_low']) ? $savedfilters['last_changed_time_low'] : "*";
        $ctime_high = ($savedfilters['last_changed_time_high']) ? $savedfilters['last_changed_time_high'] : "now/m";
        $searchParams['body']['query']['query_string']['query'] .= " AND ctime:[" . $ctime_low . " TO " . $ctime_high . "]";
    }

    if ($savedfilters['hardlinks_low']) {
        $searchParams['body']['query']['query_string']['query'] .= " AND nlink:>= " . $savedfilters['hardlinks_low'];
    }

    if ($savedfilters['hardlinks_high']) {
        $searchParams['body']['query']['query_string']['query'] .= " AND nlink:<= " . $savedfilters['hardlinks_high'];
    }

    if ($savedfilters['owner']) {
        if ($savedfilters['owner_operator'] == 'is') {
            $searchParams['body']['query']['query_string']['query'] .= " AND owner:" . $savedfilters['owner'];
        } else {
            $searchParams['body']['query']['query_string']['query'] .= " AND NOT owner:" . $savedfilters['owner'];
        }
    }

    if ($savedfilters['group']) {
        if ($savedfilters['group_operator'] == 'is') {
            $searchParams['body']['query']['query_string']['query'] .= " AND group:" . $savedfilters['owner'];
        } else {
            $searchParams['body']['query']['query_string']['query'] .= " AND NOT group:" . $savedfilters['owner'];
        }
    }

    if ($savedfilters['extensions']) {
        $extension_str = implode(" OR ", $savedfilters['extensions']);
        if ($savedfilters['extensions_operator'] == 'is') {
            $searchParams['body']['query']['query_string']['query'] .= " AND extension:(" . $extension_str . ")";
        } else {
            $searchParams['body']['query']['query_string']['query'] .= " AND NOT extension:(" . $extension_str . ")";
        }
    }

    if ($savedfilters['extension']) {
        if ($savedfilters['extension_operator'] == 'is') {
            $searchParams['body']['query']['query_string']['query'] .= " AND extension:" . $savedfilters['extension'];
        } else {
            $searchParams['body']['query']['query_string']['query'] .= " AND NOT extension:" . $savedfilters['extension'];
        }
    }

    if ($savedfilters['filetype']) {
        $extensions = array();
        foreach ($savedfilters['filetype'] as $filetype) {
            foreach ($GLOBALS['config']->FILE_TYPES[$filetype] as $ext) {
                $extensions[] = $ext;
            }
        }
        $extension_str = implode(" OR ", $extensions);
        if ($savedfilters['filetype_operator'] == 'is') {
            $searchParams['body']['query']['query_string']['query'] .= " AND extension:(" . $extension_str . ")";
        } else {
            $searchParams['body']['query']['query_string']['query'] .= " AND NOT extension:(" . $extension_str . ")";
        }
    }

    if ($savedfilters['tags']) {
        if (in_array("untagged", $savedfilters['tags'])) {
            if ($savedfilters['tags_operator'] == 'is') {
                $searchParams['body']['query']['query_string']['query'] .= " AND NOT tags:*";
            } else {
                $searchParams['body']['query']['query_string']['query'] .= " AND tags:*";
            }
        } else {
            $tags_str = "";
            $x = sizeof($savedfilters['tags']);
            $n = 1;
            foreach ($savedfilters['tags'] as $tag) {
                $tags_str .= "\"$tag\"";
                if ($n !== $x) $tags_str .= " OR ";
                $n++;
            }
            if ($savedfilters['tags_operator'] == 'is') {
                $searchParams['body']['query']['query_string']['query'] .= " AND tags:(" . $tags_str . ")";
            } else {
                $searchParams['body']['query']['query_string']['query'] .= " AND NOT tags:(" . $tags_str . ")";
            }
        }
    }

    if ($savedfilters['taginput']) {
        if ($savedfilters['taginput_operator'] == 'is') {
            $searchParams['body']['query']['query_string']['query'] .= " AND tags:" . $savedfilters['taginput'];
        } else {
            $searchParams['body']['query']['query_string']['query'] .= " AND NOT tags:" . $savedfilters['taginput'];
        }
    }

    if ($savedfilters['otherfields'] && $savedfilters['otherfields_input']) {
        switch ($savedfilters['otherfields_operator']) {
            case 'contains':
                $searchParams['body']['query']['query_string']['query'] .= " AND " . $savedfilters['otherfields'] . ":*" . $savedfilters['otherfields_input'] . "*";
                break;
            case 'notcontains':
                $searchParams['body']['query']['query_string']['query'] .= " AND NOT " . $savedfilters['otherfields'] . ":*" . $savedfilters['otherfields_input'] . "*";
                break;
            case 'is':
                $searchParams['body']['query']['query_string']['query'] .= " AND " . $savedfilters['otherfields'] . ":" . $savedfilters['otherfields_input'];
                break;
            case 'isnot':
                $searchParams['body']['query']['query_string']['query'] .= " AND NOT " . $savedfilters['otherfields'] . ":" . $savedfilters['otherfields_input'];
                break;
            case '>':
                $searchParams['body']['query']['query_string']['query'] .= " AND " . $savedfilters['otherfields'] . ":>" . $savedfilters['otherfields_input'];
                break;
            case '>=':
                $searchParams['body']['query']['query_string']['query'] .= " AND " . $savedfilters['otherfields'] . ":>=" . $savedfilters['otherfields_input'];
                break;
            case '<':
                $searchParams['body']['query']['query_string']['query'] .= " AND " . $savedfilters['otherfields'] . ":<" . $savedfilters['otherfields_input'];
                break;
            case '<=':
                $searchParams['body']['query']['query_string']['query'] .= " AND " . $savedfilters['otherfields'] . ":<=" . $savedfilters['otherfields_input'];
                break;
            case 'regexp':
                $searchParams['body']['query']['query_string']['query'] .= " AND " . $savedfilters['otherfields'] . ":/" . $savedfilters['otherfields_input'] . "/";
                break;
        }
    }

    if ($savedfilters['nofilterdirs'] == "on") {
        $searchParams['body']['query']['query_string']['query'] = "(" . $searchParams['body']['query']['query_string']['query'] . ") OR (parent_path:" . escape_chars($path) . " AND type:directory)";
    }

    return $searchParams;
}

// sort top paths by name
function toppaths_name_sort($a, $b)
{
    // get file name only
    $a = basename($a);
    $b = basename($b);
    // remove any . or _ from start of name
    $a = ltrim($a, '._');
    $b = ltrim($b, '._');
    return strcasecmp($a, $b);
}

// sort top paths by label
function toppaths_label_sort($a, $b)
{
    global $config;
    // check for label for top path in config
    if (isset($config->TOPPATH_LABELS[$a])) {
        $a = $config->TOPPATH_LABELS[$a];
    } else {
        $a = basename($a);
    }
    if (isset($config->TOPPATH_LABELS[$b])) {
        $b = $config->TOPPATH_LABELS[$b];
    } else {
        $b = basename($b);
    }
    // remove any . or _ from start of name
    $a = ltrim($a, '._');
    $b = ltrim($b, '._');
    return strcasecmp($a, $b);
}

// run background process
function runBckgrndProc($cmd)
{
    $outputfile = 'bgproc.log';
    // windows
    if (substr(php_uname(), 0, 7) == "Windows") {
        pclose(popen('start /B ' . $cmd . ' >> ' . $outputfile, 'r'));
    // linux, mac
    } else {
        exec('nohup '.$cmd.' >> '.$outputfile.' 2>&1 &');
    }
}

// reset search sort order and reload page
function resetSort($reason)
{
    createCookie('sort', 'parent_path');
    createCookie('sortorder', 'asc');
    createCookie('sort2', 'name');
    createCookie('sortorder2', 'asc');
    $_SESSION['resetsortreason'] = $reason;
    $query = $_GET;
    $query['sort'] = 'parent_path';
    $query['sortorder'] = 'asc';
    $query_result = http_build_query($query);
    header('Location: ' . $_SERVER['PHP_SELF'] . '?' . $query_result);
    exit;
}
