<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
example file action to load index and directory path into Kibana
*/


// override debug output in fileactions include file
$fileactions_debug = FALSE;

include 'includes/fileactions.php';
include 'includes/fileactions_header.php';


// Kibana host url
$kibanahost = "http://localhost:5601";

// in this example we are loading an index and directory path in Kibana
// you can set fileactions_debug to TRUE above for debug info to print out fileinfo array

foreach ($fileinfo as $file) {
    // skip any files selected
    if ($file['type'] != 'directory') {
        echo "Not a directory";
        continue;
    }

    $fullpath = $file['fullpath'];
    // uncomment below and set to translate paths
    //$path_translations = array(
    //    '/^\//' => '/mnt/'
    //);
    //$fullpath = translate_path($fullpath, $path_translations);

    $index = $file['index'];

    // Kibana Lucene query
    $query = "parent_path:" . urlencode(escape_chars($fullpath)) . "*";

    // Kibana index id in url
    $kibana_index_id = "93055fc0-84b6-11ec-a632-bddd56ca7398";
    // Kibana discover url
    //$kibanaurl = "/app/discover#/?_g=(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:now-15m,to:now))&_a=(columns:!(),filters:!(('\$state':(store:appState),meta:(alias:!n,disabled:!f,index:'" . $kibana_index_id . "',key:_index,negate:!f,params:(query:" . $index . "),type:phrase),query:(match_phrase:(_index:" . $index . "))),('\$state':(store:appState),meta:(alias:!n,disabled:!f,index:'" . $kibana_index_id . "',key:type,negate:!f,params:!(file,directory),type:phrases),query:(bool:(minimum_should_match:1,should:!((match_phrase:(type:file)),(match_phrase:(type:directory))))))),index:'" . $kibana_index_id . "',interval:auto,query:(language:lucene,query:'" . $query . "'),sort:!())";
    // Kibana dashboard id in url
    $kibaha_dashboard_id = "de6638f0-8799-11ec-a632-bddd56ca7398";
    // Kibana dashboard url
    $kibanaurl = "/app/dashboards#/view/" . $kibaha_dashboard_id . "?_g=(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:now-1M,to:now))&_a=(columns:!(),filters:!(('\$state':(store:appState),meta:(alias:!n,disabled:!f,index:'" . $kibana_index_id . "',key:_index,negate:!f,params:(query:" . $index . "),type:phrase),query:(match_phrase:(_index:" . $index . "))),('\$state':(store:appState),meta:(alias:!n,disabled:!f,index:'" . $kibana_index_id . "',key:type,negate:!f,params:!(file,directory),type:phrases),query:(bool:(minimum_should_match:1,should:!((match_phrase:(type:file)),(match_phrase:(type:directory))))))),index:'" . $kibana_index_id . "',interval:auto,query:(language:lucene,query:'" . $query . "'),sort:!())";

    $kibanafullurl = $kibanahost . $kibanaurl;

    // open new browser tab/window for Glim
    echo '
    <script type="text/javascript">
    window.open("' . $kibanafullurl . '", \'_blank\');
    </script>
    <div style="padding:5px">Loading ' . $kibanafullurl . ' in new window...<br>
    If it does not load, click <a href="' . $kibanafullurl . '" target="_blank">here</a>.</div>
    ';
}


include 'includes/fileactions_footer.php';