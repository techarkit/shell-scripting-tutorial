<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../vendor/autoload.php';
require "../../src/diskover/Auth.php";
require "../../src/diskover/Diskover.php";
require "tasks_inc.php";

// read task history log json file
$history_json = readTasksFile("tasklog.json");
$history_arr = json_decode($history_json, true);
// reverse array to have newest times first
$history_sorted = array_reverse($history_arr);

// max log results to show
$results = (isset($_GET['results'])) ? $_GET['results'] : 25;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>diskover &mdash; Task History</title>
    <link rel="stylesheet" href="../css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="../css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="../css/diskover-tasks.css" media="screen" />
    <link rel="icon" type="image/png" href="../images/diskoverfavico.png" />
</head>

<body>
    <?php include "tasks_nav.php"; ?>

    <div class="container-fluid" id="mainwindow" style="margin-top:70px">
        <h1 class="page-header">Task History</h1>
        <?php if (empty($history_sorted)) { ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="alert alert-dismissible alert-info">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <i class="glyphicon glyphicon-exclamation-sign"></i> No task history found, task log empty.
                    </div>
                </div>
            </div>
        <?php } else { ?>
            <div class="row">
                <div class="col-lg-12">
                    <table class="table table-striped table-hover table-condensed">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Task Name</th>
                                <th>Task Type</th>
                                <th>Worker</th>
                                <th>Start Time</th>
                                <th>Finish Time</th>
                                <th>Task Time</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $x = 1;
                            foreach ($history_sorted as $key => $val) {
                                if ($val['status'] === 'finished') {
                                    $status_icon = '<i class="fas fa-check-circle" style="color:#59B370"></i> ';
                                } elseif ($val['status'] === 'failed') {
                                    $status_icon = '<i class="fas fa-times-circle" style="color:#EF3B33"></i> ';
                                } elseif ($val['status'] === 'warning') {
                                    $val['status'] = 'finished (warnings)';
                                    $status_icon = '<i class="fas fa-check-circle" style="color:#59B370"></i> <i class="fas fa-exclamation-circle" style="color:#FF9800"></i> ';
                                } else {
                                    $status_icon = '';
                                }
                            ?>
                                <tr>
                                    <td><?php echo utcTimeToLocal($val['date']) ?></td>
                                    <td><?php echo $val['task_name'] ?></td>
                                    <td><?php echo $val['task_type'] ?></td>
                                    <td><?php echo $val['worker'] ?></td>
                                    <td><?php echo utcTimeToLocal($val['start_time']) ?></td>
                                    <td><?php echo utcTimeToLocal($val['finish_time']) ?></td>
                                    <td><?php echo secondsToTime($val['task_time']) ?></td>
                                    <td><?php echo $status_icon . $val['status'] ?></td>
                                </tr>
                            <?php
                                $x += 1;
                                if ($x > $results) {
                                    break;
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                    <p class="pull-right">showing <?php echo $results ?> of <?php echo count($history_sorted) ?> log entries <?php if (count($history_sorted) > $results) { ?><a href="tasks_history.php?results=<?php echo $results + 25 ?>">show more</a><?php } ?> (last updated <script>
                            document.write(new Date().toLocaleString());
                        </script> <a href="tasks_history.php?results=<?php echo $results ?>">update</a>)</p>
                        <p><a href="#" onclick="confirmClearLog()" class="btn btn-default btn-sm"><i class="fas fa-eraser"></i> Clear task log</a></p>
                </div>
            </div>

        <?php } ?>
    </div>

    <script language="javascript" src="../js/jquery.min.js"></script>
    <script language="javascript" src="../js/bootstrap.min.js"></script>
    <script language="javascript" src="../js/diskover.js"></script>

</body>

</html>