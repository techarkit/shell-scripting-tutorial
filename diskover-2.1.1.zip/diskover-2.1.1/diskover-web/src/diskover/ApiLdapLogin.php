<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

// diskover-web ldap/ad api login handling

namespace diskover;

class ApiLdapLogin
{
    public $user;
    public $ldapadmin;
    public $ldapgroups;

    public function checkApiLdapLogin()
    {
        require 'config_inc.php';

        $username = $_SERVER['PHP_AUTH_USER'];
        $password = $_SERVER['PHP_AUTH_PW'];

        // Bind to ldap/ad.
        // check if ldap extension is loaded in php
        if (!extension_loaded('ldap')) {
            header('WWW-Authenticate: Basic realm="diskover REST API"');
            header('HTTP/1.0 500 Internal Server Error');
            echo 'Error: ldap extension not loaded in PHP.';
            exit;
        }

        // connect to ldap/ad server
        $ldap = ldap_connect($config->LDAP_HOST, $config->LDAP_PORT);
        if (!$ldap) {
            header('WWW-Authenticate: Basic realm="diskover REST API"');
            header('HTTP/1.0 500 Internal Server Error');
            echo 'Error: Could not connect to LDAP/AD server.';
            exit;
        }

        ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);
        ldap_set_option($ldap, LDAP_OPT_NETWORK_TIMEOUT, 10);

        $ldapbasedn = $config->LDAP_BASEDN;
        if ($config->LDAP_USERSDN == "") {
            $ldapusersdn = $ldapbasedn;
        } else {
            $ldapusersdn = $config->LDAP_USERSDN . "," . $ldapbasedn;
        }

        if ($config->LDAP_ALT_BIND) {
            $ldaprdn = 'uid=' . $username . ',' . $ldapusersdn;
            $filter = "(&(cn=*)(memberUid=$username))";
        } elseif ($config->LDAP_ALT_BIND2) {
            $ldaprdn = 'uid=' . $username . ',' . $ldapusersdn;
            $filter = "(&(uid=$username)(objectClass=posixAccount))";
        } else {
            $ldaprdn = $username . '@' . $config->LDAP_DOMAIN;
            $filter = "(sAMAccountName=" . $username . ")";
        }
        $bind = @ldap_bind($ldap, $ldaprdn, $password);

        if (!$bind) {
            header('WWW-Authenticate: Basic realm="diskover REST API"');
            header('HTTP/1.0 401 Unauthorized');
            echo 'Access denied! LDAP Error: ' . ldap_error($ldap) . ' ' . $ldaprdn;
            exit;
        }

        if ($config->LDAP_GROUPSDN == "") {
            $ldapgroupsdn = $ldapbasedn;
        } else {
            $ldapgroupsdn = $config->LDAP_GROUPSDN . "," . $ldapbasedn;
        }
        // search ldap and get all groups the user is a member of
        if ($config->LDAP_NESTED_GROUPS) {
            // get user dn needed for nested group filter
            $results = ldap_search($ldap, $ldapgroupsdn, $filter);
            $first = ldap_first_entry($ldap, $results);
            $userdn = ldap_get_dn($ldap, $first);
            $filter_nested = "(&(objectClass=group)(member:1.2.840.113556.1.4.1941:=$userdn))";
            $results = ldap_search($ldap, $ldapgroupsdn, $filter_nested, array("cn"));
        } else {
            $results = ldap_search($ldap, $ldapgroupsdn, $filter, array("memberof"));
        }
        $entries = ldap_get_entries($ldap, $results);
        ldap_close($ldap);

        // add group names dn to groups array
        if ($config->LDAP_ALT_BIND || $config->LDAP_NESTED_GROUPS) {
            $groups = array();
            foreach ($entries as $entry) {
                $groups[] = $entry['dn'];
            }
            $groups = array_filter($groups);
        } else {
            $groups = $entries[0]['memberof'];
        }

        // add group names to groupnames array
        $groupnames = array();
        foreach ($groups as $group) {
            $grpname = explode(",", $group, 2);
            $grpname = explode("=", $grpname[0]);
            $groupnames[] = $grpname[1];
        }
        $groupnames = array_filter($groupnames);

        // check if one of the groups that the user belongs to is in one of the authorized groups
        $authorized = false;
        $admin = false;
        foreach ($groupnames as $group) {
            if (in_array($group, $config->LDAP_ADMIN_GROUPS)) {
                $authorized = true;
                $admin = true;
                break;
            }
            if (in_array($group, $config->LDAP_USER_GROUPS)) {
                $authorized = true;
            }
        }

        if ($authorized) {
            // Valid user!
            $this->user = $username;
            $this->ldapadmin = $admin;
            $this->ldapgroups = $groupnames;
        } else {
            header('WWW-Authenticate: Basic realm="diskover REST API"');
            header('HTTP/1.0 404 Unauthorized');
            echo 'Access Denied! Your username is not in a diskover api LDAP group.';
            exit;
        }
    }
}
