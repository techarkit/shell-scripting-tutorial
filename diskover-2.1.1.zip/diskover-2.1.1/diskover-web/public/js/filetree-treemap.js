/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
 * d3 filetree for diskover-web
 */

$(document).ready(function () {

    $('#changepath').click(function () {
        console.log('changing paths');
        var newpath = encodeURIComponent($('#pathinput').val());
        setCookie('path', newpath);
        location.href = "treemap.php?index=" + index + "&index2=" + index2 + "&path=" + newpath + "&filter=" + filter + "&time=" + time + '&maxdepth=' + maxdepth + "&use_count=" + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
        return false;
    });

    /* ------- SIZE/COUNT BUTTONS -------*/

    d3.select("#size").on("click", function () {
        use_count = 0;
        setCookie('use_count', 0);
        usecache = 0;
        setCookie('usecache', 0)
        location.href = "treemap.php?index=" + index + "&index2=" + index2 + "&path=" + encodeURIComponent(path) + "&filter=" + filter + "&time=" + time + '&maxdepth=' + maxdepth + "&use_count=" + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
    });

    d3.select("#count").on("click", function () {
        use_count = 1;
        setCookie('use_count', 1);
        usecache = 0;
        setCookie('usecache', 0)
        location.href = "treemap.php?index=" + index + "&index2=" + index2 + "&path=" + encodeURIComponent(path) + "&filter=" + filter + "&time=" + time + '&maxdepth=' + maxdepth + "&use_count=" + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
    });

    /* ------- SHOW FILES CHECKBOX -------*/

    d3.select("#showfiles").on("change", function () {
        var sf = document.getElementById('showfiles').checked;
        (sf) ? show_files = 1: show_files = 0;
        setCookie('show_files', show_files)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = "treemap.php?index=" + index + "&index2=" + index2 + "&path=" + encodeURIComponent(path) + "&filter=" + filter + "&time=" + time + '&maxdepth=' + maxdepth + "&use_count=" + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
    });

    /* ------- MAXDEPTH BUTTONS -------*/

    d3.select("#depth1").on("click", function () {
        maxdepth = 1;
        setCookie('maxdepth', 1)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = 'treemap.php?index=' + index + '&index2=' + index2 + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + '&usecache=' + usecache;
    });
    d3.select("#depth2").on("click", function () {
        maxdepth = 2;
        setCookie('maxdepth', 2)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = 'treemap.php?index=' + index + '&index2=' + index2 + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + '&usecache=' + usecache;
    });
    d3.select("#depth3").on("click", function () {
        maxdepth = 3;
        setCookie('maxdepth', 3)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = 'treemap.php?index=' + index + '&index2=' + index2 + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + '&usecache=' + usecache;
    });
    d3.select("#depth4").on("click", function () {
        maxdepth = 4;
        setCookie('maxdepth', 4)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = 'treemap.php?index=' + index + '&index2=' + index2 + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + '&usecache=' + usecache;
    });
    d3.select("#depth5").on("click", function () {
        maxdepth = 5;
        setCookie('maxdepth', 5)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = 'treemap.php?index=' + index + '&index2=' + index2 + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + '&usecache=' + usecache;
    });

    d3.select("#depth" + maxdepth).classed("active", true);
    for (i = 1; i <= 5; i++) {
        if (i != maxdepth) {
            d3.select("#depth" + i).classed("active", false);
        }
    }

    d3.select("#minsizefilter").on("click", function () {
        usecache = 0;
        setCookie('usecache', 0);
    });

    d3.select("#timefilter").on("click", function () {
        usecache = 0;
        setCookie('usecache', 0);
    });

    getJSON();

    // set cookies
    setCookie('path', encodeURIComponent(path));
    setCookie('filter', filter);
    setCookie('time', time);
    setCookie('hide_thresh', hide_thresh);
    setCookie('use_count', use_count);
    setCookie('show_files', show_files);

});


function showHidden(root) {
    // data is loaded so let's show hidden elements on the page
    // update path field
    document.getElementById('pathinput').value = root.name;
    // show path input
    document.getElementById('path-container').style.display = 'inline-block';
    // show chart buttons div
    document.getElementById('chart-buttons').style.display = 'inline-block';
    // show filetree header div
    document.getElementById('tree-header').style.display = 'block';
    // show filetree div
    document.getElementById('tree-wrapper').style.display = 'block';
    // show chart div
    document.getElementById('treemap-wrapper').style.display = 'block';
}

function getChildJSON(d) {
    // get json data from Elasticsearch using php data grabber
    //console.log("getting children from Elasticsearch: " + d.name);

    // config references
    chartConfig = {
        target: 'mainwindow',
        data_url: 'd3_data.php?path=' + encodeURIComponent(d.name) + '&filter=' + filter + '&time=' + time + '&use_count=' + use_count + '&show_files=' + show_files + '&usecache=' + usecache
    };

    // loader settings
    opts = {
        lines: 12, // The number of lines to draw
        length: 6, // The length of each line
        width: 3, // The line thickness
        radius: 7, // The radius of the inner circle
        color: '#EE3124', // #rgb or #rrggbb or array of colors
        speed: 1.9, // Rounds per second
        trail: 40, // Afterglow percentage
        className: 'spinner', // The CSS class to assign to the spinner
    };

    var target = document.getElementById(chartConfig.target);
    // trigger loader
    var spinner = new Spinner(opts).spin(target);
    //console.log(chartConfig.data_url)

    // load json data and trigger callback
    d3.json(chartConfig.data_url, function (error, data) {
        if (error) {
            jsonError(error);
        } else if (data.count === 0 && data.size === 0) {
            spinner.stop();
            console.warn('No docs found in Elasticsearch');
            document.getElementById('warning').style.display = 'block';
            return false;
        }

        if (data.children.length > 0) {
            // update children in root
            d._children = [];
            d._children = data.children;
        }

        // stop spin.js loader
        spinner.stop();

    });

}

function getJSON() {
    console.time('loadtime')
    // get json data from Elasticsearch using php data grabber
    console.log("grabbing json data from Elasticsearch");

    // config references
    chartConfig = {
        target: 'tree-container',
        data_url: 'd3_data.php?path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&use_count=' + use_count + '&show_files=' + show_files + "&usecache=" + usecache
    };

    // loader settings
    opts = {
        lines: 12, // The number of lines to draw
        length: 6, // The length of each line
        width: 3, // The line thickness
        radius: 7, // The radius of the inner circle
        color: '#EE3124', // #rgb or #rrggbb or array of colors
        speed: 1.9, // Rounds per second
        trail: 40, // Afterglow percentage
        className: 'spinner', // The CSS class to assign to the spinner
    };

    var target = document.getElementById(chartConfig.target);
    // trigger loader
    var spinner = new Spinner(opts).spin(target);
    console.log(chartConfig.data_url)
    // load json data from Elasticsearch
    d3.json(chartConfig.data_url, function (error, data) {
        if (error) {
            jsonError(error);
        } else if (data.count === 0 && data.size === 0) {
            spinner.stop();
            console.warn('No docs found in Elasticsearch');
            document.getElementById('warning').style.display = 'block';
            return false;
        }

        root = data;

        // stop spin.js loader
        spinner.stop();

        console.timeEnd('loadtime');

        // load d3 visuals
        loadVisualizations();

    });
}

function loadVisualizations() {

    // show hidden elements on page
    showHidden(root);

    // load file tree
    updateTree(root, root);

}


function toggleChildren(d) {
    if (d.children) {
        d._children = d.children;
        d.children = null;
    } else if (d._children) {
        d.children = d._children;
        d._children = null;
    }
}

function click(d) {
    //console.log(d)
    if (d.name == root.name) {
        return null;
    }
    if (d.count > 1 && !d.children && !d._children) {
        // check if there are any children in Elasticsearch
        getChildJSON(d);
    } else if (d._children) {
        toggleChildren(d);
        updateTree(root, d);
        setTimeout(function () {
            changeTreeMap(d)
        }, 250);
    } else if (d.children) {
        toggleChildren(d);
        updateTree(root, d);
        setTimeout(function () {
            changeTreeMap(d.parent)
        }, 250);
    } else if (!d.count) {
        // display file in search results
        window.open('search.php?submitted=true&p=1&q=name:' + encodeURIComponent(d.name.split('/').pop()) + ' AND parent_path:' + encodeURIComponent(escapeHTML(d.parent.name)) + '&doctype=file', '_blank');
    }
}

function updateTree(data, parent) {
    // update path input
    if (parent.children) {
        document.getElementById('pathinput').value = parent.name;
    } else if (parent._children) {
        document.getElementById('pathinput').value = parent.parent.name;
    }

    var nodes = tree.nodes(data),
        treeduration = 125;

    var nodeEls = ul.selectAll("li.node").data(nodes, function (d) {
        d.id = d.id || ++id;
        return d.id;
    });

    //entered nodes
    var entered = nodeEls.enter().append("li").classed("node", true)
        .style("top", parent.y + "px")
        .style("opacity", 0)
        .style("height", tree.nodeHeight() + "px");

    //add arrows if it is a folder
    entered.append("span").attr("class", function (d) {
            var icon = d.children ? " glyphicon-chevron-down" :
            ((d.type == "directory" && show_files) || d.count_subdirs > 1) ? "glyphicon-chevron-right" : "";
            if (icon == "" && d.type == "directory") {
                return "downarrow-spacer";
            }
            return "downarrow glyphicon " + icon;
        })
        .style('cursor', 'pointer')
        .on("click", function (d) {
            click(d);
        })
        .on("mouseover", function (d) {
            if (d.count > 1 && !d.children && !d._children) {
                // check if there are any children in Elasticsearch
                t = setTimeout(function () {
                    getChildJSON(d);
                }, 150);
            }
        })
        .on("mouseout", function (d) {
            clearTimeout(t);
        });

    //add icons for folder for file
    entered.append("span").attr("class", function (d) {
            var foldericon = "fa-folder";
            var icon = (d.count > 0 || d.type === 'directory') ? foldericon : "fa-file";
            return "fas " + icon;
        })
        .style('cursor', 'pointer')
        .on("click", function (d) {
            click(d);
        })
        .on("mouseover", function (d) {
            if (d.count > 1 && !d.children && !d._children) {
                // check if there are any children in Elasticsearch
                t = setTimeout(function () {
                    getChildJSON(d);
                }, 150);
            }
        })
        .on("mouseout", function (d) {
            clearTimeout(t);
        });

    //add text for filename
    entered.append("span").attr("class", "filename")
        .html(function (d) {
            return d.depth === 0 ? d.name : d.name.split('/').pop();
        })
        .on("click", function (d) {
            click(d);
        })
        .on("mouseover", function (d) {
            d3.select(this).classed("selected", true);
            if (d.count > 1 && !d.children && !d._children) {
                // check if there are any children in Elasticsearch
                t = setTimeout(function () {
                    getChildJSON(d);
                }, 150);
            }
        })
        .on("mouseout", function (d) {
            d3.selectAll(".selected").classed("selected", false);
            clearTimeout(t);
        });

    // add percent bar
    entered.append("span").attr("class", "percent-bg")
    entered.append("span").attr("class", function (d) {
            var value = (use_count) ? d.count : d.size;
            var parent_value = (use_count) ? (d.parent) ? d.parent.count : root.count : (d.parent) ? d.parent.size : root.size;
            var percent = (value / parent_value * 100).toFixed(0);
            if (percent >= 90) {
                var barclass = "percent-bar-red";
            } else if (percent >= 75) {
                var barclass = "percent-bar-orange";
            } else if (percent >= 50) {
                var barclass = "percent-bar-yellow";
            } else {
                var barclass = "percent-bar-gray";
            }
            return barclass;
        })
        .style("width", function (d) {
            var value = (use_count) ? (d.count > 0) ? d.count : 1 : d.size;
            var parent_value = (use_count) ? (d.parent) ? d.parent.count : root.count : (d.parent) ? d.parent.size : root.size;
            var percent = (value / parent_value * 100).toFixed(1);
            var barwidth = 150 * (percent / 100);
            return barwidth + "px";
        });

    // add percent text
    entered.append("span").attr("class", "percent-text")
        .html(function (d) {
            var value = (use_count) ? (d.count > 0) ? d.count : 1 : d.size;
            var parent_value = (use_count) ? (d.parent) ? d.parent.count : root.count : (d.parent) ? d.parent.size : root.size;
            var percent = (value / parent_value * 100).toFixed(1);
            return percent + "%";
        });

    //add filesize
    entered.append("span").attr("class", function (d) {
            var value = (use_count) ? d.count : d.size;
            var parent_value = (use_count) ? (d.parent) ? d.parent.count : root.count : (d.parent) ? d.parent.size : root.size;
            var percent = (value / parent_value * 100).toFixed(0);
            if (percent >= 90) {
                var fileclass = "filesize-red";
            } else if (percent >= 75) {
                var fileclass = "filesize-orange";
            } else if (percent >= 50) {
                var fileclass = "filesize-yellow";
            } else {
                var fileclass = "filesize-gray";
            }
            return fileclass;
        })
        .html(function (d) {
            return format(d.size);
        });

    // add file and directory counts
    entered.append("span").attr("class", "totalcount")
        .html(function (d) {
            return (d.type === 'directory') ? numberWithCommas(d.count) : "";
        });

    entered.append("span").attr("class", "filecount")
        .html(function (d) {
            return (d.type === 'directory') ? numberWithCommas(d.count_files) : "";
        });

    entered.append("span").attr("class", "subdircount")
        .html(function (d) {
            return (d.type === 'directory') ? numberWithCommas(d.count_subdirs) : "";
        });

    // add last modified text
    entered.append("span").attr("class", "modified-date")
        .html(function (d) {
            return d.modified;
        });

    //add icons for search button amd copy path button
    entered.append("span").attr("class", "filetree-btns-container")
        .html(function (d) {
            var ret = '';
            if (d.count > 0) {
                ret += '<a target="_blank" href="search.php?submitted=true&amp;p=1&amp;index='+index+'&amp;index2='+index2+'&amp;q=parent_path:' + encodeURIComponent(escapeHTML(d.name)) + ' AND size:>=' + filter + ' AND ' + timefield + ':[' + getTime() + ']&amp;path=' + encodeURIComponent(d.name) + '"><label title="search" class="btn btn-default btn-xs filetree-btns"><i class="glyphicon glyphicon-search"></i></label></a>';
            }
            ret += ' <a href="#" onclick="copyToClipboardText(\'' + d.name + '\'); return false;"><label title="copy path" class="btn btn-default btn-xs filetree-btns"><i class="glyphicon glyphicon-copy"></i></label></a>';
            return ret;
        });

    //update caret arrow direction
    nodeEls.select("span.downarrow").attr("class", function (d) {
        var icon = d.children ? " glyphicon-chevron-down" :
            d._children || d.count > 0 ? "glyphicon-chevron-right" : "";
        return "downarrow glyphicon " + icon;
    });
    //update position with transition
    nodeEls.transition().duration(treeduration)
        .style("top", function (d) {
            return (d.y - tree.nodeHeight()) + "px";
        })
        .style("left", function (d) {
            return d.x + "px";
        })
        .style("opacity", 1);
    nodeEls.exit().remove();
}

var root,
    id = 0;

var tree = d3.layout.treelist()
    .childIndent(20)
    .nodeHeight(20);

var ul = d3.select("#tree-container").append("ul").classed("treelist", "true");