<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/* diskover REST API
 */

require '../vendor/autoload.php';
require '../src/diskover/config_inc.php';

use Elasticsearch\Common\Exceptions\Missing404Exception;
use diskover\ApiLogin;
use diskover\ApiLdapLogin;

// api version
$API_VER = "2.0.8";

// authenticate user
if ($config->API_AUTH_ENABLED) {
    // HTTP basic auth
    if (!isset($_SERVER['PHP_AUTH_USER'])) {
        header('WWW-Authenticate: Basic realm="diskover REST API"');
        header('HTTP/1.0 401 Unauthorized');
        echo 'Access denied. You did not enter a username and password.';
        exit;
    }
    // verify api username and password
    $ldaplogin = false;
    $auth = new ApiLogin();
    if (!$auth->checkApiLogin()) {
        if ($config->API_AUTH_LDAP_ENABLED) {
            // LDAP/AD auth
            // verify ldap/ad username and password and api group membership
            $auth = new ApiLdapLogin();
            $auth->checkApiLdapLogin();
            $ldapadmin = $auth->ldapadmin;
            $ldapgroups = $auth->ldapgroups;
            $username = $auth->user;
            $ldaplogin = true;
        } else {
            header('WWW-Authenticate: Basic realm="diskover REST API"');
            header('HTTP/1.0 401 Unauthorized');
            echo 'Access denied! Incorrect username or password.';
            exit;
        }
    }
}

require "../src/diskover/Diskover.php";

// set session vars
if ($config->API_AUTH_ENABLED) {
    if ($ldaplogin) {
        $_SESSION['ldaplogin'] = true;
        if ($ldapadmin) {
            $_SESSION['ldapadmin'] = true;
        } else {
            $_SESSION['ldapadmin'] = false;
        }
        $_SESSION['ldapgroups'] = $ldapgroups;
    } else {
        $_SESSION['ldaplogin'] = false;
    }
    $_SESSION['username'] = $username;
}

// get the HTTP method, path and body of the request
$method = $_SERVER['REQUEST_METHOD'];
$request = explode('/', trim($_SERVER['PATH_INFO'], '/'));
$input = json_decode(file_get_contents('php://input'), true);

// get the URL query of the request
$url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$query = parse_url($url, PHP_URL_QUERY);

// split path request into endpoint array
$endpoint = [];
foreach ($request as $r) {
    $endpoint[] = $r;
}

// call endpoint based on HTTP method
switch ($method) {
    case 'GET':
        get($endpoint, $query);
        break;
    case 'PUT':
        put($endpoint, $input);
        break;
    case 'POST':
        echo json_response(400, 'method not supported');
        die();
    case 'DELETE':
        echo json_response(400, 'method not supported');
        die();
}

function json_response($code = 200, $message = null, $pretty = false)
{
    // clear the old headers
    header_remove();
    // set the actual code
    http_response_code($code);
    // set the header to make sure cache is forced
    header("Cache-Control: no-transform,public,max-age=300,s-maxage=900");
    // treat this as json
    header('Content-Type: application/json');
    $status = array(
        200 => '200 OK',
        400 => '400 Bad Request',
        422 => 'Unprocessable Entity',
        500 => '500 Internal Server Error'
    );
    // ok, validation error, or failure
    header('Status: ' . $status[$code]);
    // pretty print ?
    $pretty_print = ($pretty) ? JSON_PRETTY_PRINT : null;
    // return the encoded json
    return json_encode(array(
        'status' => $code < 300, // success or not?
        'message' => $message
    ), $pretty_print);
}

function put($endpoint, $input)
{
    global $client, $mnclient, $ldaplogin, $ldapadmin;

    // deny access for non-admin ldap user
    if ($ldaplogin && !$ldapadmin) {
        header('WWW-Authenticate: Basic realm="diskover REST API"');
        header('HTTP/1.0 401 Unauthorized');
        echo 'Access Denied! diskover LDAP admin group membership required for PUT.';
        exit;
    }

    switch ($endpoint) {
        // tag directory docs(s) and items in directory
        case $endpoint[1] == 'tagdirs':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                $dirs = $input['dirs'];
                $tags = $input['tags'];
                $recursive = $input['recursive'];
                $tagfiles = $input['tagfiles'];
                $numitems = 0;
                foreach ($dirs as $parent_path) {
                    // first let's get the directory doc id
                    $searchParams = [];
                    // which index to search
                    $searchParams['index'] = $endpoint[0];
                    // which client to use
                    try {
                        $client = $mnclient->getClientByIndex($endpoint[0]);
                    } catch (Exception $ex) {
                        echo json_response(500, 'es error ' . $ex->getMessage());
                        die();
                    }
                    if (is_null($client)) {
                        echo json_response(404, 'es index not found');
                        die();
                    }
                    $results = [];
                    $queryResponse = [];

                    $searchParams['size'] = 1;

                    // esccape special characters
                    $pp = addcslashes(dirname($parent_path), '<>+-&|!(){}[]^"~*?:/= @\'$.#\\');
                    $f = addcslashes(basename($parent_path), '<>+-&|!(){}[]^"~*?:/= @\'$.#\\');

                    $searchParams['body'] = [
                        '_source' => ['tags'],
                        'query' => [
                            'query_string' => [
                                'query' => 'parent_path:' . $pp . ' AND name:' . $f . ' AND type:"directory"'
                            ]
                        ]
                    ];

                    try {
                        // Send search query to Elasticsearch
                        $queryResponse = $client->search($searchParams);
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }

                    // check if directory found
                    if (!$queryResponse['hits']['hits']) {
                        continue;
                    }

                    // store the directory doc data
                    $directory_hit = $queryResponse['hits']['hits'][0];

                    // add directory doc data to results
                    $results[] = $directory_hit;

                    // now let's get all the doc id's in the directory

                    if ($recursive === "true" || $tagfiles === "true") {
                        $queryResponse = [];

                        // Scroll parameter alive time
                        $searchParams['scroll'] = "30s";

                        // scroll size
                        $searchParams['size'] = 1000;

                        $pp = addcslashes($parent_path, '+-&|!(){}[]^"~*?:\/ ');

                        if ($recursive === "true") {
                            $type = ($tagfiles === "true") ? '(file OR directory)' : 'directory';
                            $searchParams['body'] = [
                                '_source' => ['tags'],
                                'query' => [
                                    'query_string' => [
                                        'query' => 'parent_path:' . $pp . '* AND type:' . $type,
                                        'analyze_wildcard' => 'true'
                                    ]
                                ]
                            ];
                        } elseif ($tagfiles === "true") {
                            $searchParams['body'] = [
                                '_source' => ['tags'],
                                'query' => [
                                    'query_string' => [
                                        'query' => 'parent_path:' . $pp . ' AND type:"file"',
                                        'analyze_wildcard' => 'true'
                                    ]
                                ]
                            ];
                        }

                        try {
                            // Send search query to Elasticsearch
                            $queryResponse = $client->search($searchParams);
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }

                        // set total hits
                        $total = $queryResponse['hits']['total']['value'];

                        $i = 1;
                        // Loop through all the pages of results
                        while ($i <= ceil($total / $searchParams['size'])) {
                            // add files in directory to results array
                            foreach ($queryResponse['hits']['hits'] as $hit) {
                                $results[] = $hit;
                            }

                            $scroll_id = $queryResponse['_scroll_id'];

                            $queryResponse = $client->scroll([
                                "body" => [
                                    "scroll_id" => $scroll_id,
                                    "scroll" => "30s"
                                ]
                            ]);

                            $i += 1;
                        }
                    }

                    // loop through all the items in results and update tag(s)

                    foreach ($results as $r) {
                        $searchParams = [];
                        $queryResponse = [];

                        // get id and index of file
                        $id = $r['_id'];
                        $index = $r['_index'];

                        $searchParams = array();
                        $searchParams['id'] = $id;
                        $searchParams['index'] = $index;

                        try {
                            $queryResponse = $client->get($searchParams);
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }

                        if (isset($tags) && count($tags) > 0) {
                            foreach ($tags as $tag) {
                                if ($r['_source']['tags']) {
                                    // clear same tag
                                    if (array_search($tag, $r['_source']['tags']) !== false) {
                                        $key = array_search($tag, $r['_source']['tags']);
                                        unset($queryResponse['_source']['tags'][$key]);
                                    }
                                    // add tag
                                    else {
                                        $queryResponse['_source']['tags'][] = $tag;
                                    }
                                    // add tag
                                } else {
                                    $queryResponse['_source']['tags'][] = $tag;
                                }
                            }
                            $queryResponse['_source']['tags'] = array_values($queryResponse['_source']['tags']);
                        }
                        // clear all tags
                        else {
                            $queryResponse['_source']['tags'] = [];
                        }

                        $searchParams['body']['doc'] = $queryResponse['_source'];

                        try {
                            $queryResponse = $client->update($searchParams);
                            $numitems += 1;
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }
                    }
                }
                // send json response
                echo json_response(200, $numitems . ' directory docs updated');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

            // tag files
        case $endpoint[1] == 'tagfiles':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                $files = $input['files'];
                $tags = $input['tags'];
                $numfiles = 0;

                // update existing tag field with new value
                foreach ($files as $f) {
                    $searchParams = [];
                    // which index to search
                    $searchParams['index'] = $endpoint[0];
                    // which client to use
                    try {
                        $client = $mnclient->getClientByIndex($endpoint[0]);
                    } catch (Exception $ex) {
                        echo json_response(500, 'es error ' . $ex->getMessage());
                        die();
                    }
                    if (is_null($client)) {
                        echo json_response(404, 'es index not found');
                        die();
                    }
                    $queryResponse = [];
                    $parent_path = dirname($f);
                    $name = basename($f);

                    $searchParams['body'] = [
                        '_source' => ['tags'],
                        'query' => [
                            'query_string' => [
                                'query' => 'parent_path:"' . $parent_path . '" AND name:"' . $name . '" AND type:"file"'
                            ]
                        ]
                    ];

                    try {
                        // Send search query to Elasticsearch
                        $queryResponse = $client->search($searchParams);
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }

                    // check if any files found
                    if (!$queryResponse['hits']['hits']) {
                        continue;
                    }

                    // get id and index of file
                    $id = $queryResponse['hits']['hits'][0]['_id'];
                    $index = $queryResponse['hits']['hits'][0]['_index'];

                    $searchParams = array();
                    $searchParams['id'] = $id;
                    $searchParams['index'] = $index;

                    try {
                        $queryResponse = $client->get($searchParams);
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }

                    if (isset($tags) && count($tags) > 0) {
                        foreach ($tags as $tag) {
                            if ($queryResponse['_source']['tags']) {
                                // clear same tag
                                if (array_search($tag, $queryResponse['_source']['tags']) !== false) {
                                    $key = array_search($tag, $queryResponse['_source']['tags']);
                                    unset($queryResponse['_source']['tags'][$key]);
                                }
                                // add tag
                                else {
                                    $queryResponse['_source']['tags'][] = $tag;
                                }
                                // add tag
                            } else {
                                $queryResponse['_source']['tags'][] = $tag;
                            }
                        }
                        $queryResponse['_source']['tags'] = array_values($queryResponse['_source']['tags']);
                    }
                    // clear all tags
                    else {
                        $queryResponse['_source']['tags'] = [];
                    }

                    $searchParams['body']['doc'] = $queryResponse['_source'];

                    try {
                        $queryResponse = $client->update($searchParams);
                        $numfiles += 1;
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }
                }
                // send json response
                echo json_response(200, $numfiles . ' file docs updated');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;


            // =============== TASKS API START ===============

        case $endpoint[0] == 'updatetask':
            try {
                $time_utc = gmdate("Y-m-d\TH:i:s");
                $task_id = $input['id'];
                $worker = $input['worker'];
                $status = $input['status'];
                $start_time = $input['start_time'];
                $finish_time = $input['finish_time'];
                $success_finish_time = $input['success_finish_time'];
                $run_now = $input['run_now'];
                $stop_task = $input['stop_task'];
                $stop_task_force = $input['stop_task_force'];

                $filename = 'tasks/tasks.json';

                if (!is_writable($filename)) {
                    echo json_response(400, 'api error ' . $filename . ' does not exist or is not writable');
                    die();
                }

                // get the contents of the file and json decode it
                // lock the file before getting contents
                $file = fopen($filename, 'r');
    	        flock($file, LOCK_SH);
                $tasks_json = file_get_contents($filename);
                // unlock the file after getting contents
                flock($file, LOCK_UN);
                $tasks_arr = json_decode($tasks_json, true);

                // update tasks_arr for json file update
                foreach ($tasks_arr['tasks'] as $key => $entry) {
                    if ($entry['id'] == $task_id) {
                        $tasks_arr['tasks'][$key]['last_worker'] = $worker;
                        if (!empty($start_time)) {
                            $tasks_arr['tasks'][$key]['last_start_time'] = $start_time;
                            $tasks_arr['tasks'][$key]['last_finish_time'] = null;
                        }
                        if (!empty($finish_time)) {
                            $tasks_arr['tasks'][$key]['last_finish_time'] = $finish_time;
                        }
                        if (!empty($success_finish_time)) {
                            $tasks_arr['tasks'][$key]['last_success_finish_time'] = $success_finish_time;
                        }
                        $tasks_arr['tasks'][$key]['run_now'] = $run_now;
                        $tasks_arr['tasks'][$key]['last_update_time'] = $time_utc;
                        $tasks_arr['tasks'][$key]['last_status'] = $status;
                        $tasks_arr['tasks'][$key]['stop_task'] = $stop_task;
                        $tasks_arr['tasks'][$key]['stop_task_force'] = $stop_task_force;
                        break;
                    }
                }

                $updated_tasks_json = json_encode($tasks_arr, JSON_PRETTY_PRINT);
                // write new contents
                file_put_contents($filename, $updated_tasks_json, LOCK_EX);

                // send json response
                echo json_response(200, 'task updated');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[0] == 'updateworker':
            try {
                $time_utc = gmdate("Y-m-d\TH:i:s");
                $name = $input['name'];
                $hostname = $input['hostname'];
                $user = $input['user'];
                $pid = $input['pid'];
                $state = $input['state'];
                $current_tasks = $input['current_tasks'];
                $successful_task_count = $input['successful_task_count'];
                $failed_task_count = $input['failed_task_count'];
                $total_working_time = $input['total_working_time'];
                $total_running_time = $input['total_running_time'];
                $load_avg = $input['load_avg'];
                $worker_pools = $input['worker_pools'];
                $diskover_ver = $input['diskover_ver'];
                $diskoverd_ver = $input['diskoverd_ver'];

                $filename = 'tasks/workers.json';

                if (!is_writable($filename)) {
                    echo json_response(400, 'api error ' . $filename . ' does not exist or is not writable');
                    die();
                }

                // get the contents of the file and json decode it
                // lock the file before getting contents
                $file = fopen($filename, 'r');
    	        flock($file, LOCK_SH);
                $workers_json = file_get_contents($filename);
                // unlock the file after getting contents
                flock($file, LOCK_UN);
                $workers_arr = json_decode($workers_json, true);

                // update workers_arr for json file update
                $worker_found = false;
                foreach ($workers_arr['workers'] as $key => $entry) {
                    if ($entry['name'] == $name) {
                        $worker_found = true;
                        $workers_arr['workers'][$key]['hostname'] = $hostname;
                        $workers_arr['workers'][$key]['pid'] = $pid;
                        $workers_arr['workers'][$key]['user'] = $user;
                        $workers_arr['workers'][$key]['state'] = $state;
                        $workers_arr['workers'][$key]['current_tasks'] = $current_tasks;
                        $workers_arr['workers'][$key]['last_heartbeat'] = $time_utc;
                        if (!is_null($successful_task_count)) $workers_arr['workers'][$key]['successful_task_count'] = $successful_task_count;
                        if (!is_null($failed_task_count)) $workers_arr['workers'][$key]['failed_task_count'] = $failed_task_count;
                        if (!is_null($total_working_time)) $workers_arr['workers'][$key]['total_working_time'] = $total_working_time;
                        if (!is_null($total_running_time)) $workers_arr['workers'][$key]['total_running_time'] = $total_running_time;
                        if (!is_null($load_avg)) $workers_arr['workers'][$key]['load_avg'] = $load_avg;
                        if (!is_null($worker_pools)) $workers_arr['workers'][$key]['worker_pools'] = $worker_pools;
                        if (!is_null($diskover_ver)) $workers_arr['workers'][$key]['diskover_ver'] = $diskover_ver;
                        if (!is_null($diskoverd_ver)) $workers_arr['workers'][$key]['diskoverd_ver'] = $diskoverd_ver;
                        break;
                    }
                }

                // add new worker if not found
                if (!$worker_found) {
                    $worker_arr = array();
                    $worker_arr['name'] = $name;
                    $worker_arr['hostname'] = $hostname;
                    $worker_arr['pid'] = $pid;
                    $worker_arr['user'] = $user;
                    $worker_arr['state'] = $state;
                    $worker_arr['disabled'] = false;
                    $worker_arr['current_tasks'] = $current_tasks;
                    $worker_arr['last_heartbeat'] = $time_utc;
                    $worker_arr['birth_date'] = $time_utc;
                    $worker_arr['successful_task_count'] = 0;
                    $worker_arr['failed_task_count'] = 0;
                    $worker_arr['total_working_time'] = 0;
                    $worker_arr['load_avg'] = $load_avg;
                    $worker_arr['worker_pools'] = $worker_pools;
                    $worker_arr['diskover_ver'] = $diskover_ver;
                    $worker_arr['diskoverd_ver'] = $diskoverd_ver;
                    $workers_arr['workers'][] = $worker_arr;
                }

                $updated_workers_json = json_encode($workers_arr, JSON_PRETTY_PRINT);
                file_put_contents($filename, $updated_workers_json, LOCK_EX);

                // send json response
                echo json_response(200, 'worker updated');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[0] == 'heartbeat':
            try {
                $time_utc = gmdate("Y-m-d\TH:i:s");
                $name = $input['name'];

                $filename = 'tasks/workers.json';

                if (!is_writable($filename)) {
                    echo json_response(400, 'api error ' . $filename . ' does not exist or is not writable');
                    die();
                }

                // get the contents of the file and json decode it
                // lock the file before getting contents
                $file = fopen($filename, 'r');
    	        flock($file, LOCK_SH);
                $workers_json = file_get_contents($filename);
                // unlock the file after getting contents
                flock($file, LOCK_UN);
                $workers_arr = json_decode($workers_json, true);

                // update json file
                foreach ($workers_arr['workers'] as $key => $entry) {
                    if ($entry['name'] == $name) {
                        $workers_arr['workers'][$key]['last_heartbeat'] = $time_utc;
                        break;
                    }
                }

                $updated_workers_json = json_encode($workers_arr, JSON_PRETTY_PRINT);
                file_put_contents($filename, $updated_workers_json, LOCK_EX);

                // send json response
                echo json_response(200, 'heartbeat received');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[0] == 'tasklog':
            try {
                $time_utc = gmdate("Y-m-d\TH:i:s");
                $task_id = $input['task_id'];
                $task_name = $input['task_name'];
                $task_type = $input['task_type'];
                $worker = $input['worker'];
                $start_time = $input['start_time'];
                $finish_time = $input['finish_time'];
                $task_time = $input['task_time'];
                $status = $input['status'];

                $filename = 'tasks/tasklog.json';

                if (!is_writable($filename)) {
                    echo json_response(400, 'api error ' . $filename . ' does not exist or is not writable');
                    die();
                }

                // get the contents of the file and json decode it
                // lock the file before getting contents
                $file = fopen($filename, 'r');
    	        flock($file, LOCK_SH);
                $tasklog_json = file_get_contents($filename);
                // unlock the file after getting contents
                flock($file, LOCK_UN);
                $tasklog_arr = json_decode($tasklog_json, true);

                // update json file
                $tasklog_arr[] = [
                    'date' => $time_utc,
                    'task_name' => $task_name,
                    'task_type' => $task_type,
                    'worker' => $worker,
                    'start_time' => $start_time,
                    'finish_time' => $finish_time,
                    'task_time' => $task_time,
                    'status' => $status
                ];

                $updated_tasklog_json = json_encode($tasklog_arr, JSON_PRETTY_PRINT);
                file_put_contents($filename, $updated_tasklog_json, LOCK_EX);

                // send json response
                echo json_response(200, 'task log entry added');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

            // =============== TASKS API END ===============

        default:
            echo json_response(400, 'unknown api endpoint');
    }
}

function get($endpoint, $query)
{
    global $mnclient, $client, $ldaplogin, $ldapadmin;

    // parse query string into vars
    parse_str($query, $output);

    // deny access for certain endpoints for non-admin ldap user
    if ($ldaplogin && !$ldapadmin) {
        $allowed_endpoints = array('search');
        if (!in_array($endpoint[1], $allowed_endpoints)) {
            header('WWW-Authenticate: Basic realm="diskover REST API"');
            header('HTTP/1.0 403 Forbidden');
            echo "API endpoint \"$endpoint[1]\" not allowed for non-admin LDAP user. Allowed endpoints: " . implode(', ', $allowed_endpoints);
            exit;
        } 
    }

    switch ($endpoint) {

        case $endpoint[1] == 'tagcount':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search
                // which type within the index to search
                $type = (isset($output['type'])) ? $output['type'] : '(file OR directory)';
                $tagCountRes = 0;
                if (isset($output['tag'])) {
                    if ($output['tag']) {
                        $searchParams['body'] = [
                            'size' => 0,
                            'query' => [
                                'query_string' => [
                                    'query' => 'tags:"' . $output['tag'] . '" AND type:' . $type
                                ]
                            ]
                        ];
                    } else {
                        echo json_response(400, 'missing tag');
                        die();
                    }

                    // Get search results from Elasticsearch for tag
                    try {
                        // Send search query to Elasticsearch
                        $queryResponse = $client->search($searchParams);
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }

                    // Get total for tag
                    $tagCount = $queryResponse['hits']['total']['value'];
                    $tagCountRes = $$tagCount;
                } else {
                    // Grab all the custom tags from file and add to tagCounts
                    $customtags = get_custom_tags();
                    $tagCountsCustom = [];
                    foreach ($customtags as $tag) {
                        $tagCountsCustom[$tag[0]] = 0;
                    }

                    foreach ($tagCountsCustom as $tag => $value) {
                        $searchParams['body'] = [
                            'size' => 0,
                            'query' => [
                                'query_string' => [
                                    'query' => 'tags:"' . $tag . '" AND type:' . $type
                                ]
                            ]
                        ];

                        try {
                            // Send search query to Elasticsearch
                            $queryResponse = $client->search($searchParams);
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }

                        // Get total for tag
                        $tagCountsCustom[$tag] = $queryResponse['hits']['total']['value'];
                    }
                    $tagCountRes = $tagCountsCustom;
                }

                // send json response
                echo json_response(200, array('data' => $tagCountRes));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[1] == 'tagsize':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search
                // which type within the index to search
                $type = (isset($output['type'])) ? $output['type'] : '(file OR directory)';
                $tagSizesRes = 0;
                if (isset($output['tag'])) {
                    if ($output['tag']) {
                        $searchParams['body'] = [
                            'size' => 0,
                            'query' => [
                                'query_string' => [
                                    'query' => 'tags:"' . $output['tag'] . '" AND type:' . $type
                                ]
                            ],
                            'aggs' => [
                                'total_size' => [
                                    'sum' => [
                                        'field' => 'size'
                                    ]
                                ]
                            ]
                        ];
                    } else {
                        echo json_response(400, 'missing tag');
                        die();
                    }

                    // Get search results from Elasticsearch for tag
                    $tagSize = 0;

                    try {
                        // Send search query to Elasticsearch
                        $queryResponse = $client->search($searchParams);
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }

                    // Get total for tag
                    $tagSize = $queryResponse['aggregations']['total_size']['value'];
                    $tagSizesRes = $tagSize;
                } else {
                    // Grab all the custom tags from file and add to tagSizesCustom
                    $customtags = get_custom_tags();
                    $tagSizesCustom = [];
                    foreach ($customtags as $tag) {
                        $tagSizesCustom[$tag[0]] = 0;
                    }

                    foreach ($tagSizesCustom as $tag => $value) {
                        $searchParams['body'] = [
                            'size' => 0,
                            'query' => [
                                'query_string' => [
                                    'query' => 'tags:"' . $tag . '" AND type:' . $type
                                ]
                            ],
                            'aggs' => [
                                'total_size' => [
                                    'sum' => [
                                        'field' => 'size'
                                    ]
                                ]
                            ]
                        ];

                        try {
                            // Send search query to Elasticsearch
                            $queryResponse = $client->search($searchParams);
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }

                        // Get total size of all files with tag
                        $tagSizesCustom[$tag] = $queryResponse['aggregations']['total_size']['value'];
                    }
                    $tagSizesRes = $tagSizesCustom;
                }

                // send json response
                echo json_response(200, array('data' => $tagSizesRes));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[1] == 'tags':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search
                // which type within the index to search
                $type = (isset($output['type'])) ? $output['type'] : '(file OR directory)';
                // Scroll parameter alive time
                $searchParams['scroll'] = "30s";

                // scroll size
                $searchParams['size'] = (isset($output['size']) ? $output['size'] : 1000);

                // page number of results to print
                $page = (isset($output['page']) ? $output['page'] : 1);

                if (empty($output['tag'])) {
                    $searchParams['body'] = [
                        'query' => [
                            'query_string' => [
                                'query' => 'NOT tags:* AND type:' . $type
                            ]
                        ]
                    ];
                } else {
                    $searchParams['body'] = [
                        'query' => [
                            'query_string' => [
                                'query' => 'tags:"' . $output['tag'] . '" AND type:' . $type
                            ]
                        ]
                    ];
                }

                // Send search query to Elasticsearch and get scroll id and first page of results
                try {
                    // Send search query to Elasticsearch
                    $queryResponse = $client->search($searchParams);
                } catch (Missing404Exception $e) {
                    echo json_response(404, 'es index not found ' . $e->getMessage());
                } catch (Exception $e) {
                    echo json_response(500, 'es error ' . $e->getMessage());
                    die();
                }

                // set total hits
                $total = $queryResponse['hits']['total']['value'];

                $i = 1;
                $results = [];
                // Loop through all the pages of results
                while ($i <= ceil($total / $searchParams['size'])) {
                    // check if we have the results for the page we are on
                    if ($i == $page) {
                        // Get files for tag
                        $results[$i] = $queryResponse['hits']['hits'];
                        // end loop
                        break;
                    }

                    $scroll_id = $queryResponse['_scroll_id'];

                    // Execute a Scroll request and repeat
                    $queryResponse = $client->scroll([
                        "body" => [
                            "scroll_id" => $scroll_id,
                            "scroll" => "30s"
                        ]
                    ]);

                    $i += 1;
                }

                // send json response
                if ($results[$page]) {
                    echo json_response(200, array('totalhits' => $total, 'data' => $results[$page]));
                } else {
                    echo json_response(200, array('totalhits' => $total, 'data' => []));
                }
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex->getMessage());
            }
            break;

        case $endpoint[0] == 'list':
            try {
                $clients = $mnclient->getClients();
                $diskover_indices_all = array();
                foreach ($clients as $client) {
                    try {
                        $diskover_indices = $client->cat()->indices(array('index' => 'diskover-*'));
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }
                    for ($i = 0; $i < count($diskover_indices); $i++) {
                        // Get search results from Elasticsearch for index/space info
                        $results = [];
                        $searchParams = [];
                        // Setup search query
                        $searchParams['index'] = $diskover_indices[$i]['index'];
                        $searchParams['body'] = [
                            'size' => 100,
                            'query' => [
                                'match' => ['type' => 'indexinfo']
                            ]
                        ];
                        try {
                            $queryResponse = $client->search($searchParams);
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }

                        $paths = [];

                        foreach ($queryResponse['hits']['hits'] as $hit) {
                            if (!in_array($hit['_source']['path'], $paths)) {
                                $paths[] = $hit['_source']['path'];
                            }
                            $x = array_search($hit['_source']['path'], $paths);
                            if (isset($hit['_source']['path'])) {
                                $diskover_indices[$i][$x]['path'] = $hit['_source']['path'];
                            }
                            if (isset($hit['_source']['file_count'])) {
                                $diskover_indices[$i][$x]['totalfiles'] = $hit['_source']['file_count'];
                            }
                            if (isset($hit['_source']['dir_count'])) {
                                $diskover_indices[$i][$x]['totaldirs'] = $hit['_source']['dir_count'];
                            }
                            if (isset($hit['_source']['file_size'])) {
                                $diskover_indices[$i][$x]['totalSize'] = $hit['_source']['file_size'];
                            }
                            if (isset($hit['_source']['file_size_du'])) {
                                $diskover_indices[$i][$x]['totalSizeDu'] = $hit['_source']['file_size_du'];
                            }
                            if (isset($hit['_source']['start_at'])) {
                                $diskover_indices[$i][$x]['crawlStartTime'] = $hit['_source']['start_at'];
                            }
                            if (isset($hit['_source']['end_at'])) {
                                $diskover_indices[$i][$x]['crawlEndTime'] = $hit['_source']['end_at'];
                            }
                            if (isset($hit['_source']['crawl_time'])) {
                                $diskover_indices[$i][$x]['elapsedCrawlTime'] = round($hit['_source']['crawl_time'], 6);
                            }
                        }

                        // get total hardlink count and size for each path in index
                        $x = 0;
                        foreach ($paths as $p) {
                            $searchParams['body'] = [
                                'size' => 0,
                                'track_total_hits' => true,
                                'aggs' => [
                                    'total_size' => [
                                        'sum' => [
                                            'field' => 'size'
                                        ]
                                    ]
                                ],
                                'query' => [
                                    'query_string' => [
                                        'query' => 'parent_path:' . escape_chars($p) . '* AND nlink:>1 AND type:"file"',
                                        'analyze_wildcard' => 'true'
                                    ]
                                ]
                            ];
                            try {
                                // Send search query to Elasticsearch
                                $queryResponse = $client->search($searchParams);
                            } catch (Missing404Exception $e) {
                                echo json_response(404, 'es index not found ' . $e->getMessage());
                            } catch (Exception $e) {
                                echo json_response(500, 'es error ' . $e->getMessage());
                                die();
                            }

                            $diskover_indices[$i][$x]['totalHardlinkFiles'] = $queryResponse['hits']['total']['value'];
                            $diskover_indices[$i][$x]['totalHardlinkSize'] = $queryResponse['aggregations']['total_size']['value'];
                            $x += 1;
                        }
                    }
                    $diskover_indices_all = array_merge($diskover_indices_all, $diskover_indices);
                }
                // send json response
                echo json_response(200, array('data' => $diskover_indices_all));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[1] == 'diskspace':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                $diskover_indices = [];
                $searchParams = [];
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search
                // Get search results from Elasticsearch for disk space info
                $searchParams['body'] = [
                    'size' => 100,
                    'query' => [
                        'match' => ['type' => 'spaceinfo']
                    ]
                ];
                try {
                    $queryResponse = $client->search($searchParams);
                } catch (Missing404Exception $e) {
                    echo json_response(404, 'es index not found ' . $e->getMessage());
                } catch (Exception $e) {
                    echo json_response(500, 'es error ' . $e->getMessage());
                    die();
                }

                $paths = [];

                foreach ($queryResponse['hits']['hits'] as $hit) {
                    if (!in_array($hit['_source']['path'], $paths)) {
                        $paths[] = $hit['_source']['path'];
                    }
                    $x = array_search($hit['_source']['path'], $paths);
                    if (isset($hit['_source']['path'])) {
                        $diskover_indices[$x]['path'] = $hit['_source']['path'];
                    }
                    if (isset($hit['_source']['total'])) {
                        $diskover_indices[$x]['totalSize'] = $hit['_source']['total'];
                    }
                    if (isset($hit['_source']['used'])) {
                        $diskover_indices[$x]['usedSize'] = $hit['_source']['used'];
                    }
                    if (isset($hit['_source']['free'])) {
                        $diskover_indices[$x]['freeSize'] = $hit['_source']['free'];
                    }
                    if (isset($hit['_source']['free_percent'])) {
                        $diskover_indices[$x]['freePercent'] = $hit['_source']['free_percent'];
                    }
                    if (isset($hit['_source']['available'])) {
                        $diskover_indices[$x]['availableSize'] = $hit['_source']['available'];
                    }
                    if (isset($hit['_source']['available_percent'])) {
                        $diskover_indices[$x]['availablePercent'] = $hit['_source']['available_percent'];
                    }
                }

                // send json response
                echo json_response(200, array('data' => $diskover_indices));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[1] == 'search':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search
                // Scroll parameter alive time
                $searchParams['scroll'] = "30s";

                // scroll size
                $searchParams['size'] = (isset($output['size']) ? $output['size'] : 1000);

                // page number of results to print
                $page = (isset($output['page']) ? $output['page'] : 1);

                $searchParams['body'] = [
                    'query' => [
                        'query_string' => [
                            'query' => $output['query'],
                            'analyze_wildcard' => 'true'
                        ]
                    ]
                ];

                // apply any filters to search for non-admin ldap user
                if ($ldaplogin && !$ldapadmin) {
                    $searchParams = filterIndexMappingPaths($searchParams);
                    $searchParams = filterLDAPGroups($searchParams);
                }

                // Send search query to Elasticsearch and get scroll id and first page of results
                try {
                    // Send search query to Elasticsearch
                    $queryResponse = $client->search($searchParams);
                } catch (Missing404Exception $e) {
                    echo json_response(404, 'es index not found ' . $e->getMessage());
                } catch (Exception $e) {
                    echo json_response(500, 'es error ' . $e->getMessage());
                    die();
                }

                // set total hits
                $total = $queryResponse['hits']['total']['value'];

                $i = 1;
                $results = [];
                // Loop through all the pages of results and store in results array
                while ($i <= ceil($total / $searchParams['size'])) {
                    // check if we have the results for the page we are on
                    if ($i == $page) {
                        // Get results for page
                        $results[$i] = $queryResponse['hits']['hits'];
                        // end loop
                        break;
                    }

                    $scroll_id = $queryResponse['_scroll_id'];

                    $queryResponse = $client->scroll([
                        "body" => [
                            "scroll_id" => $scroll_id,
                            "scroll" => "30s"
                        ]
                    ]);

                    $i += 1;
                }

                // send json response
                if ($results[$page]) {
                    echo json_response(200, array('totalhits' => $total, 'data' => $results[$page]));
                } else {
                    echo json_response(200, array('totalhits' => $total, 'data' => []));
                }
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[1] == 'toppaths':
            # get all top paths in an index
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search

                $searchParams['size'] = 100;

                $searchParams['body'] = [
                    '_source' => ['path'],
                    'query' => [
                        'match' => [
                            'type' => 'indexinfo'
                        ]
                    ]
                ];

                try {
                    // Send search query to Elasticsearch
                    $queryResponse = $client->search($searchParams);
                } catch (Missing404Exception $e) {
                    echo json_response(404, 'es index not found ' . $e->getMessage());
                } catch (Exception $e) {
                    echo json_response(500, 'es error ' . $e->getMessage());
                    die();
                }

                $results = $queryResponse['hits']['hits'];
                $toppaths = array();
                foreach ($results as $res) {
                    $toppaths[] = $res['_source']['path'];
                }
                $toppaths = array_unique($toppaths);

                // send json response
                echo json_response(200, array('data' => $toppaths));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[0] == 'latest':
            # get latest index from top path
            if (isset($output['toppath'])) {
                $toppath = $output['toppath'];
            } else {
                echo json_response(400, 'missing toppath');
                die();
            }
            try {
                // refresh indices
                try {
                    $mnclient->refreshIndices();
                } catch (Missing404Exception $e) {
                    echo json_response(404, 'es index not found ' . $e->getMessage());
                } catch (Exception $e) {
                    echo json_response(500, 'es error ' . $e->getMessage());
                    die();
                }
                // get all diskover indices info
                $diskover_indices = $mnclient->getIndicesInfoCurl();
                // add all top paths in indices to index_toppaths
                $index_toppaths = [];
                $disabled_indices = [];
                $indices_sorted = [];

                foreach ($diskover_indices as $esnode => $esindices) {
                    foreach ($esindices as $key => $val) {
                        // Get search results from Elasticsearch for indexinfo docs
                        $results = [];
                        $searchParams = [];
                        // Setup search query
                        $searchParams['index'] = $key;
                        $searchParams['body'] = [
                            'size' => 100,
                            'query' => [
                                'match' => ['type' => 'indexinfo']
                            ],
                            'sort' => ['start_at' => 'asc']
                        ];
                        try {
                            $queryResponse = $client->search($searchParams);
                        } catch (Missing404Exception $e) {
                            //echo json_response(404, 'es index not found ' . $e->getMessage());
                            continue;
                        } catch (Exception $e) {
                            //echo json_response(500, 'es error ' . $e->getMessage());
                            continue;
                        }

                        $startcount = 0;
                        $endcount = 0;
                        foreach ($queryResponse['hits']['hits'] as $hit) {
                            if (array_key_exists('start_at', $hit['_source'])) {
                                $startcount += 1;
                            }
                            if (array_key_exists('end_at', $hit['_source'])) {
                                $endcount += 1;
                            }
                            if (
                                array_key_exists($key, $index_toppaths) &&
                                !in_array($hit['_source']['path'], $index_toppaths[$key])
                            ) {
                                $index_toppaths[$key][] = $hit['_source']['path'];
                            } else {
                                $index_toppaths[$key] = array($hit['_source']['path']);
                            }
                        }
                        // add to disabled_indices list if still being indexed
                        if ($endcount < $startcount) {
                            $disabled_indices[] = $key;
                        }

                        // add to indices_sorted using creation_date as key
                        $indices_sorted[$diskover_indices[$esnode][$key]['creation_date']] = [
                            'index' => $key,
                            'esnode' => $esnode
                        ];
                    }
                }

                // sort completed indices by creation_date
                krsort($indices_sorted);

                // get latest index
                $latest_index = null;
                foreach ($indices_sorted as $key => $val) {
                    if (!in_array($val['index'], $disabled_indices)) {
                        // get all top paths in index and check for toppath match
                        foreach($index_toppaths[$val['index']] as $index_toppath) {
                            if ($index_toppath == $toppath) {
                                $latest_index = $val['index'];
                                break 2;
                            }
                        }
                    }
                }

                // send json response
                echo json_response(200, array('data' => $latest_index));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

            // =============== TASKS API START ===============

        case $endpoint[0] == 'tasks':
            try {
                // read json file and get tasks
                $tasks_json = file_get_contents("tasks/tasks.json");
                $tasks_arr = json_decode($tasks_json, true);

                // send json response
                if ($tasks_arr) {
                    echo json_response(200, array('data' => $tasks_arr));
                } else {
                    echo json_response(200, array('data' => []));
                }
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[0] == 'workerinfo':
            try {
                $name = $output['worker'];
                // read json file and get tasks
                $workers_json = file_get_contents("tasks/workers.json");
                $workers_arr = json_decode($workers_json, true);

                $worker_info = array();
                foreach ($workers_arr['workers'] as $key => $entry) {
                    if ($entry['name'] == $name) {
                        $worker_info = $workers_arr['workers'][$key];
                        break;
                    }
                }

                // send json response
                if ($worker_info) {
                    echo json_response(200, array('data' => $worker_info));
                } else {
                    echo json_response(200, array('data' => []));
                }
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

            // =============== TASKS API END ===============

        default:
            $data = [
                'version' => 'diskover REST API v' . $GLOBALS["API_VER"],
                'message' => 'endpoint not found'
            ];
            echo json_response(200, $data, true);
    }
}
