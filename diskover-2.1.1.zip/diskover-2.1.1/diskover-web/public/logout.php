<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

session_start();

require '../vendor/autoload.php';
require "../src/diskover/config_inc.php";

if ($config->OKTA_LOGINS) {
    $id_token = $_SESSION['okta_id_token'];
}

// Remove session vars
session_unset();
session_destroy();
// Delete cookies
setcookie('path');
setcookie('rootpath');
setcookie('parentpath');
setcookie('toppaths');
setcookie('toppaths_index_map');
setcookie('error');

if ($config->OKTA_LOGINS) {
    require "../src/diskover/Okta.php";

    logout($id_token);
    exit;
}

// Redirect to the login page
$loginpage = (strpos($_SERVER['REQUEST_URI'], 'tasks/') !== false || 
    strpos($_SERVER['REQUEST_URI'], 'fileactions/') !== false) ? "../login.php" : "login.php";
if (isset($_GET['inactive'])) {
    header("location: " . $loginpage . "?inactive");
} else {
    header("location: " . $loginpage);
}
exit;

?>