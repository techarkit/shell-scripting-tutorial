<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../vendor/autoload.php';
require "../../src/diskover/Auth.php";
require "../../src/diskover/Diskover.php";
require "tasks_inc.php";

// read tasks json file
$tasks_json = readTasksFile("tasks.json");
$tasks_arr = json_decode($tasks_json, true);
$tasks_sorted = $tasks_arr['tasks'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>diskover &mdash; Task List</title>
    <link rel="stylesheet" href="../css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="../css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="../css/diskover-tasks.css" media="screen" />
    <link rel="stylesheet" href="../css/dataTables.bootstrap.min.css" media="screen" />
    <link rel="icon" type="image/png" href="../images/diskoverfavico.png" />
</head>

<body>
    <?php include "tasks_nav.php"; ?>

    <div class="container-fluid" id="mainwindow" style="margin-top:70px">
        <h1 class="page-header">Task List</h1>
        <div class="row">
            <div class="col-lg-12">
                <div class="btn-group">
                    <a href="tasks_task_index.php?action=new" class="btn btn-default"><i class="far fa-plus-square"></i> New Index Task</a>
                    <a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="tasks_task_custom.php?action=new">New Custom Task</a></li>
                    </ul>
                </div>
                <p class="pull-right"><?php echo count($tasks_sorted) . " tasks found (last updated <script>document.write(new Date().toLocaleString());</script> <a href=\"index.php\">update</a>)"; ?></p>
            </div>
        </div><br>
        <?php if (empty($tasks_sorted)) { ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="alert alert-dismissible alert-info">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <i class="glyphicon glyphicon-exclamation-sign"></i> No tasks found.
                    </div>
                </div>
            </div>
        <?php } else { ?>
            <div class="row">
                <div class="col-lg-12">
                    <table class="table table-striped table-hover table-condensed" id="tasks-table" data-order='[[ 5, "desc" ]]' style="width:100%">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Task Type</th>
                                <th>Schedule <i title="min hour dayofmonth month dayofweek" class="fas fa-question-circle text-muted"></i></th>
                                <th>Last Start</th>
                                <th>Last Finish</th>
                                <th>Task Time</th>
                                <th>Last Success</th>
                                <th>Last Update</th>
                                <th>Last Status</th>
                                <th>Disabled</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($tasks_sorted as $key => $val) {
                                $schedule = $val['run_min'] . " " . $val['run_hour'] . " " . $val['run_day_month'] .
                                    " " . $val['run_month'] . " " . $val['run_day_week'];
                            ?>
                                <tr>
                                    <td width="110">
                                        <div class="btn-group">
                                            <a href="tasks_info.php?id=<?php echo $val['id'] ?>" class="btn btn-default btn-sm"><i class="fas fa-info-circle"></i> Info</a>
                                            <a href="#" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></a>
                                            <ul class="dropdown-menu">
                                                <li><a href="tasks_task_<?php echo $val['type'] ?>.php?action=edit&id=<?php echo $val['id'] ?>"><i class="far fa-edit"></i> Edit task</a></li>
                                                <li><a href="#" onclick="confirmTask('disable', '<?php echo $val['id'] ?>', '<?php echo $val['disabled'] ?>', '<?php echo $val['last_status'] ?>')"><i class="fas fa-ban"></i> Disable</a></li>
                                                <li><a href="#" onclick="confirmTask('enable', '<?php echo $val['id'] ?>', '<?php echo $val['disabled'] ?>', '<?php echo $val['last_status'] ?>')"><i class="fas fa-check-circle"></i> Enable</a></li>
                                                <li><a href="#" onclick="confirmTask('remove', '<?php echo $val['id'] ?>', '<?php echo $val['disabled'] ?>', '<?php echo $val['last_status'] ?>')"><i class="fas fa-times-circle"></i> Remove</a></li>
                                                <li><a href="#" onclick="confirmTask('resetstatus', '<?php echo $val['id'] ?>', '<?php echo $val['disabled'] ?>', '<?php echo $val['last_status'] ?>')"><i class="fas fa-redo"></i> Reset Status</a></li>
                                                <li><a href="#" onclick="confirmTask('runnow', '<?php echo $val['id'] ?>', '<?php echo $val['disabled'] ?>', '<?php echo $val['last_status'] ?>')"><i class="far fa-play-circle"></i> Run Now</a></li>
                                                <li><a href="#" onclick="confirmTask('stoptask', '<?php echo $val['id'] ?>', '<?php echo $val['disabled'] ?>', '<?php echo $val['last_status'] ?>')"><i class="far fa-stop-circle"></i> Stop</a></li>
                                                <li><a href="#" onclick="confirmTask('stoptaskforce', '<?php echo $val['id'] ?>', '<?php echo $val['disabled'] ?>', '<?php echo $val['last_status'] ?>')"><i class="far fa-stop-circle"></i> Stop (forced)</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                    <td><a href="tasks_info.php?id=<?php echo $val['id'] ?>"><?php echo $val['name'] ?></a></td>
                                    <td><?php echo $val['description'] ?></td>
                                    <td><?php echo $val['type'] ?></td>
                                    <td><?php echo $schedule ?></td>
                                    <td><?php echo utcTimeToLocal($val['last_start_time']) ?></td>
                                    <td><?php echo utcTimeToLocal($val['last_finish_time']) ?></td>
                                    <td><?php
                                        $date = new DateTime($val['last_start_time']);
                                        $date2 = new DateTime($val['last_finish_time']);
                                        $diffInSeconds = $date2->getTimestamp() - $date->getTimestamp();
                                        echo secondsToTime($diffInSeconds);
                                        ?></td>
                                    <td><?php echo utcTimeToLocal($val['last_success_finish_time']) ?></td>
                                    <td><?php echo utcTimeToLocal($val['last_update_time']) ?></td>
                                    <td><?php
                                        if ($val['last_status'] === 'waiting' || $val['last_status'] === 'stopping') {
                                            $status_icon = '<i class="fa fa-spinner" style="color:#FAAE11"></i> ';
                                        } elseif ($val['last_status'] === 'running' || $val['last_status'] === 'starting') {
                                            $status_icon = '<i class="fas fa-play-circle" style="color:#FFFFFF"></i> ';
                                        } elseif ($val['last_status'] === 'finished') {
                                            $status_icon = '<i class="fas fa-check-circle" style="color:#59B370"></i> ';
                                        } elseif ($val['last_status'] === 'failed') {
                                            $status_icon = '<i class="fas fa-times-circle" style="color:#EF3B33"></i> ';
                                        } elseif ($val['last_status'] === 'warning') {
                                            $val['last_status'] = 'finished (warnings)';
                                            $status_icon = '<i class="fas fa-check-circle" style="color:#59B370"></i> <i class="fas fa-exclamation-circle" style="color:#FF9800"></i> ';
                                        } else {
                                            $status_icon = "";
                                        }
                                        echo (!empty($val['last_status'])) ? $status_icon . $val['last_status'] :  '-'  ?></td>
                                    <td><?php echo ($val['disabled']) ? 'Yes' : 'No' ?></td>
                                </tr>
                            <?php }
                            ?>
                        </tbody>
                    </table>
                    <p class="pull-right"><?php echo count($tasks_sorted) . " tasks found (last updated <script>document.write(new Date().toLocaleString());</script> <a href=\"index.php\">update</a>)"; ?></p>
                </div>
            </div>

        <?php } ?>
    </div>

    <script language="javascript" src="../js/jquery.min.js"></script>
    <script language="javascript" src="../js/bootstrap.min.js"></script>
    <script language="javascript" src="../js/diskover.js"></script>
    <script language="javascript" src="../js/jquery.dataTables.min.js"></script>
    <script language="javascript" src="../js/dataTables.bootstrap.min.js"></script>
    <script language="javascript" src="../js/time-elapsed-dhms.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            // make data table
            $("#tasks-table").DataTable({
                "stateSave": true,
                "lengthMenu": [10, 25, 50, 75, 100],
                "pageLength": 25,
                "columnDefs": [
                    {
                        "type": "time-elapsed-dhms",
                        targets: [7]
                    },
                    {
                        "orderable": false,
                        targets: [0]
                    }
                ]
            });
        });
    </script>

</body>

</html>