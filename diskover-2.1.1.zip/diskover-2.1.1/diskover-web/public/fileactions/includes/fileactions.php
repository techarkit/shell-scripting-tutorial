<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../vendor/autoload.php';
use Elasticsearch\Common\Exceptions\Missing404Exception;
require "../../src/diskover/Auth.php";
require "../../src/diskover/Diskover.php";

error_reporting(E_ALL ^ E_NOTICE);

// license check
// DO NOT ALTER, REMOVE THIS CODE OR COMMENT IT OUT.
// REMOVING THE LICENSE CHECK VIOLATES THE LICENSE AGREEMENT AND IS AN ILLEGAL OFFENCE.
$lic->file_action_check();
// end license check

// log file actions to log file and web server log
$logfileactions = TRUE;

// default debug output
if (!isset($fileactions_debug)) $fileactions_debug = TRUE;

$fileactionpage = basename($_SERVER['PHP_SELF']);

$fileactionresult = null;

// check if authorized to run
if (!checkAuth($fileactionpage)) {
    $fileactionresult = 0;
    logFileAction();
    die('Not authorized to run this file action.');
}

$fileinfo = array();

// check for path in url params
if (isset($_GET['path'])) {
    if (empty($_GET['path'])) {
        die('Path url param empty.');
    }
    $fileinfo[] = array(
        'fullpath' => htmlspecialchars($_GET['path']),
        'type' => 'directory'
    );
} else {
    // get file action button doc id/index or selected doc ids and doc indices from cookies (from search results page)
    // check for form POST if plugin form was submitted and get doc info from cookies
    if (isset($_GET['docid'])) {
        $docids = $_GET['docid'];
        createCookie('fileactionid', $docids);
    } elseif (!empty($_POST) && getCookie('fileactionid') != "") {
        $docids = getCookie('fileactionid');
        deleteCookie('fileactionid');
    } else {
        $docids = getCookie('checkedids');
        createCookie('fileactionid', $docids);
    }
    if (isset($_GET['docindex'])) {
        $docindices = $_GET['docindex'];
        createCookie('fileactionindex', $docindices);
    } elseif (!empty($_POST) && getCookie('fileactionindex') != "") {
        $docindices = getCookie('fileactionindex');
        deleteCookie('fileactionindex');
    } else {
        $docindices = getCookie('checkedindices');
        createCookie('fileactionindex', $docindices);
    }

    if (empty($docids) || empty($docindices)) {
        die('No file or directory selected');
    }

    $docids_arr = explode(',', $docids);
    $docindices_arr = explode(',', $docindices);

    // get file info for each doc
    foreach ($docids_arr as $key => $docid) {
        try {
            $searchParams = [];
            $searchParams['index'] = $docindices_arr[$key];
            $searchParams['body'] = [
                'query' => [
                    'ids' => [
                        'values' => [ $docid ]
                    ]
                ]
            ];
            //printDebug($searchParams);
            $queryResponse = $client->search($searchParams);
        } catch (Missing404Exception $e) {
            handleError("Selected indices are no longer available. Please select a different index.");
        } catch (Exception $e) {
            handleError('ES error: ' . $e->getMessage(), false, false);
        }

        if (empty($queryResponse['hits']['hits'])) {
            continue;
        }
        
        $fileinfo[] = array(
            'docid' => $queryResponse['hits']['hits'][0]['_id'],
            'index' => $queryResponse['hits']['hits'][0]['_index'],
            'index_nocluster' => $mnclient->getIndexNoCluster($docindices_arr[$key]),
            'fullpath' => $queryResponse['hits']['hits'][0]['_source']['parent_path'] . '/' . $queryResponse['hits']['hits'][0]['_source']['name'],
            'source' => $queryResponse['hits']['hits'][0]['_source'],
            'type' => $queryResponse['hits']['hits'][0]['_source']['type']
        );
    }
}

printDebug($fileinfo);


function printDebug($msg) {
    global $fileactions_debug;

    if ($fileactions_debug) {
        echo '
        <div class="container-fluid debug-output">
        Debug: <pre>' . var_export($msg, true) . '</pre>
        </div>
        ';
    }
}

// checks if a user is authorized to run the file action
function checkAuth($fileactionpage) {
    global $fileactions_debug;
    $authorized = FALSE;
    $fileactionUsers = array();
    $fileactionGroups = array();

    foreach ($GLOBALS['config']->FILE_ACTIONS as $key => $value) {
        if (strtok($value['webpage'], "?") === $fileactionpage) {
            $fileactionUsers = $value['allowed_users'];
            $fileactionGroups = $value['allowed_ldap_groups'];
        }
    }

    if ($_SESSION['ldaplogin']) {
        foreach ($_SESSION['ldapgroups'] as $group) {
            if (in_array($group, $fileactionGroups)) {
                $authorized = TRUE;
                break;
            }
        }
    } else {
        if (in_array($_SESSION['username'], $fileactionUsers)) {
            $authorized = TRUE;
        }
    }

    if ($fileactions_debug && !$authorized && $_SESSION['ldaplogin']) {
        echo "LDAP groups: <pre>" . var_export($_SESSION['ldapgroups'], true) . "</pre>\n";
        echo "LDAP groups permitted: <pre>" . var_export($fileactionGroups, true) . "</pre>\n";
    }

    return $authorized;
}

// log a file action
function logFileAction()
{
    global $logfileactions, $fileactionpage, $fileinfo, $fileactionresult;

    if (!$logfileactions) return;

    // log to web server log
    $log  = "User: ".$_SERVER['REMOTE_ADDR'].", File Action: ".$fileactionpage.
        ", File Info: ".json_encode($fileinfo).", Attempt: ".($fileactionresult===1?'Success':'Failed').
        ", User: ".$_SESSION['username'];

    error_log($log);
    
    // log to file
    $log  = "User: ".$_SERVER['REMOTE_ADDR'].' - '.date("F j, Y, g:i a").PHP_EOL.
        "File Action: ".$fileactionpage.PHP_EOL.
        "File Info ".json_encode($fileinfo).PHP_EOL.
        "Attempt: ".($fileactionresult===1?'Success':'Failed').PHP_EOL.
        "User: ".$_SESSION['username'].PHP_EOL.
        "-------------------------".PHP_EOL;

    file_put_contents('./logs/fileactions_'.date("j.n.Y").'.log', $log, FILE_APPEND);
}

// set any path translations to find path if it's different in index from the real path
// from index path translations
// returns translated path
function translate_path($path, $path_translations = array()) {
    // return path if nothing to translate
    if (empty($path_translations)) return $path;
    
    foreach ($path_translations as $pattern => $replacement) {
        if (preg_match($pattern, $path)) {
            $path = preg_replace($pattern, $replacement, $path);
            break;
        }
    }
    return $path;
}

// convert linux paths to windows
function linux_to_windows($path, $translate_win = array()) {
    // add drive letter or unc path
    foreach ($translate_win as $toppath => $drive_unc) {
        if (strpos($path, $toppath) !== false) {
            $path = $drive_unc . $path;
            break;
        }
    }
    // replace all / with \
    $path = str_replace( '/', '\\', $path );
    return $path;
}